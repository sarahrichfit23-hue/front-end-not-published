import { useState } from 'react';
import { Upload, FileJson } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { toast } from 'sonner';

interface PackUploaderProps {
  onFileSelect: (file: File, data: any) => void;
}

export function PackUploader({ onFileSelect }: PackUploaderProps) {
  const [dragActive, setDragActive] = useState(false);

  const handleFile = async (file: File) => {
    if (!file.name.endsWith('.json')) {
      toast.error('Please upload a JSON file');
      return;
    }

    try {
      const text = await file.text();
      const data = JSON.parse(text);
      onFileSelect(file, data);
      toast.success('File loaded successfully');
    } catch (error) {
      toast.error('Invalid JSON file');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files?.[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <Card
      className={`p-8 border-2 border-dashed transition-colors ${
        dragActive ? 'border-primary bg-primary/5' : 'border-muted-foreground/25'
      }`}
      onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
      onDragLeave={() => setDragActive(false)}
      onDrop={handleDrop}
    >
      <div className="flex flex-col items-center gap-4 text-center">
        <FileJson className="h-12 w-12 text-muted-foreground" />
        <div>
          <h3 className="font-semibold mb-1">Upload Content Pack</h3>
          <p className="text-sm text-muted-foreground">
            Drag & drop or click to select a JSON file
          </p>
        </div>
        <Label htmlFor="file-upload" className="cursor-pointer">
          <Button type="button" variant="outline" asChild>
            <span>
              <Upload className="h-4 w-4 mr-2" />
              Select File
            </span>
          </Button>
          <Input
            id="file-upload"
            type="file"
            accept=".json"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          />
        </Label>
      </div>
    </Card>
  );
}
