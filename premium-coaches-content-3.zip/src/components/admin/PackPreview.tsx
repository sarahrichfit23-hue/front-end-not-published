import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

interface PackPreviewProps {
  data: any;
}

export function PackPreview({ data }: PackPreviewProps) {
  return (
    <Card className="p-6">
      <h3 className="font-semibold mb-4">Pack Preview</h3>
      <div className="space-y-4">
        <div>
          <span className="text-sm text-muted-foreground">Month:</span>
          <p className="font-medium">{data.month || 'N/A'}</p>
        </div>
        <div>
          <span className="text-sm text-muted-foreground">Theme:</span>
          <p className="font-medium">{data.theme || 'N/A'}</p>
        </div>
        <div>
          <span className="text-sm text-muted-foreground">Content Items:</span>
          <div className="flex flex-wrap gap-2 mt-2">
            {data.posts && <Badge variant="secondary">{data.posts.length} Posts</Badge>}
            {data.stories && <Badge variant="secondary">{data.stories.length} Stories</Badge>}
            {data.reels && <Badge variant="secondary">{data.reels.length} Reels</Badge>}
            {data.emails && <Badge variant="secondary">{data.emails.length} Emails</Badge>}
          </div>
        </div>
        <div>
          <span className="text-sm text-muted-foreground mb-2 block">Raw JSON:</span>
          <ScrollArea className="h-[300px] w-full rounded border">
            <pre className="p-4 text-xs">
              {JSON.stringify(data, null, 2)}
            </pre>
          </ScrollArea>
        </div>
      </div>
    </Card>
  );
}
