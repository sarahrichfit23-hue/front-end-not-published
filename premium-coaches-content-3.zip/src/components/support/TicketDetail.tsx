import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Send, Clock, Star, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';

interface Message {
  id: string;
  message: string;
  created_at: string;
  user_id: string;
  is_internal_note: boolean;
}

export function TicketDetail({ ticket, onBack }: { ticket: any; onBack: () => void }) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState(ticket.status);
  const [priority, setPriority] = useState(ticket.priority);
  const [rating, setRating] = useState(ticket.satisfaction_rating || 0);

  useEffect(() => {
    fetchMessages();
  }, [ticket.id]);

  const fetchMessages = async () => {
    try {
      const { data, error } = await supabase
        .from('ticket_messages')
        .select('*')
        .eq('ticket_id', ticket.id)
        .order('created_at', { ascending: true });

      if (error) throw error;
      setMessages(data || []);
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('ticket_messages')
        .insert({
          ticket_id: ticket.id,
          user_id: user.id,
          message: newMessage
        });

      if (error) throw error;

      setNewMessage('');
      fetchMessages();
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateTicket = async (field: string, value: string) => {
    try {
      const updates: any = { [field]: value };
      if (field === 'status' && value === 'resolved') {
        updates.resolved_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from('support_tickets')
        .update(updates)
        .eq('id', ticket.id);

      if (error) throw error;
    } catch (error) {
      console.error('Error updating ticket:', error);
    }
  };

  const submitRating = async (value: number) => {
    setRating(value);
    try {
      const { error } = await supabase
        .from('support_tickets')
        .update({ satisfaction_rating: value })
        .eq('id', ticket.id);

      if (error) throw error;
    } catch (error) {
      console.error('Error submitting rating:', error);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Tickets
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>{ticket.subject}</CardTitle>
              <p className="text-sm text-gray-500 mt-1">{ticket.ticket_number}</p>
            </div>
            <div className="flex gap-2">
              <Badge>{ticket.category}</Badge>
              <Badge variant={priority === 'urgent' ? 'destructive' : 'secondary'}>
                {priority}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="messages">
            <TabsList>
              <TabsTrigger value="messages">Messages</TabsTrigger>
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="activity">Activity</TabsTrigger>
            </TabsList>

            <TabsContent value="messages" className="space-y-4">
              <div className="space-y-4 max-h-96 overflow-y-auto">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600">{ticket.description}</p>
                  <p className="text-xs text-gray-400 mt-2">
                    {format(new Date(ticket.created_at), 'MMM d, yyyy h:mm a')}
                  </p>
                </div>

                {messages.map((message) => (
                  <div key={message.id} className="p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm">{message.message}</p>
                    <p className="text-xs text-gray-400 mt-2">
                      {format(new Date(message.created_at), 'MMM d, yyyy h:mm a')}
                    </p>
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <Textarea
                  placeholder="Type your message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  className="flex-1"
                />
                <Button onClick={sendMessage} disabled={loading}>
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="details" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Status</label>
                  <Select 
                    value={status} 
                    onValueChange={(value) => {
                      setStatus(value);
                      updateTicket('status', value);
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="open">Open</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="waiting_customer">Waiting Customer</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium">Priority</label>
                  <Select 
                    value={priority} 
                    onValueChange={(value) => {
                      setPriority(value);
                      updateTicket('priority', value);
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {ticket.sla_deadline && (
                <div className="p-4 bg-yellow-50 rounded-lg flex items-center gap-2">
                  <Clock className="h-4 w-4 text-yellow-600" />
                  <div>
                    <p className="text-sm font-medium">SLA Deadline</p>
                    <p className="text-xs text-gray-600">
                      {format(new Date(ticket.sla_deadline), 'MMM d, yyyy h:mm a')}
                    </p>
                  </div>
                </div>
              )}

              {status === 'resolved' && (
                <div className="p-4 bg-blue-50 rounded-lg">
                  <p className="text-sm font-medium mb-2">Rate your experience</p>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((value) => (
                      <button
                        key={value}
                        onClick={() => submitRating(value)}
                        className="p-1"
                      >
                        <Star
                          className={`h-6 w-6 ${
                            value <= rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="activity">
              <div className="text-center text-gray-500 py-8">
                Activity log coming soon
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}