import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MessageCircle, Send, X, Bot, User, Paperclip } from 'lucide-react';

interface ChatMessage {
  id: string;
  message: string;
  is_bot: boolean;
  created_at: string;
  sender_id?: string;
}

export function LiveChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && !sessionId) {
      createChatSession();
    }
  }, [isOpen]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const createChatSession = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('chat_sessions')
        .insert({
          user_id: user.id,
          status: 'waiting'
        })
        .select()
        .single();

      if (error) throw error;
      setSessionId(data.id);

      // Send initial bot message
      const welcomeMessage = {
        id: crypto.randomUUID(),
        message: "Hello! I'm here to help. How can I assist you today?",
        is_bot: true,
        created_at: new Date().toISOString()
      };
      setMessages([welcomeMessage]);
    } catch (error) {
      console.error('Error creating chat session:', error);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !sessionId) return;

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      message: newMessage,
      is_bot: false,
      created_at: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setNewMessage('');
    setLoading(true);
    setIsTyping(true);

    try {
      // Save user message
      const { data: { user } } = await supabase.auth.getUser();
      await supabase
        .from('chat_messages')
        .insert({
          session_id: sessionId,
          sender_id: user?.id,
          message: userMessage.message,
          is_bot: false
        });

      // Get bot response
      const { data, error } = await supabase.functions.invoke('ai-support-bot', {
        body: { 
          message: userMessage.message,
          sessionId,
          context: messages.slice(-5)
        }
      });

      if (error) throw error;

      const botMessage: ChatMessage = {
        id: crypto.randomUUID(),
        message: data.response,
        is_bot: true,
        created_at: new Date().toISOString()
      };

      setMessages(prev => [...prev, botMessage]);

      if (data.shouldEscalate) {
        setTimeout(() => {
          const escalateMessage: ChatMessage = {
            id: crypto.randomUUID(),
            message: "I've notified a human agent who will join this chat shortly.",
            is_bot: true,
            created_at: new Date().toISOString()
          };
          setMessages(prev => [...prev, escalateMessage]);
        }, 1000);
      }
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage: ChatMessage = {
        id: crypto.randomUUID(),
        message: "I'm having trouble connecting. Please try again or create a support ticket.",
        is_bot: true,
        created_at: new Date().toISOString()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
      setIsTyping(false);
    }
  };

  const endChat = async () => {
    if (sessionId) {
      await supabase
        .from('chat_sessions')
        .update({ 
          status: 'ended',
          ended_at: new Date().toISOString()
        })
        .eq('id', sessionId);
    }
    setIsOpen(false);
    setSessionId(null);
    setMessages([]);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 bg-blue-600 text-white rounded-full p-4 shadow-lg hover:bg-blue-700 transition-colors z-50"
      >
        <MessageCircle className="h-6 w-6" />
      </button>
    );
  }

  return (
    <Card className="fixed bottom-4 right-4 w-96 h-[500px] shadow-xl z-50">
      <CardHeader className="flex flex-row items-center justify-between p-4 border-b">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          <CardTitle className="text-lg">Support Chat</CardTitle>
        </div>
        <Button variant="ghost" size="sm" onClick={endChat}>
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent className="p-0 flex flex-col h-[calc(100%-60px)]">
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.is_bot ? 'justify-start' : 'justify-end'}`}
              >
                <div className={`flex gap-2 max-w-[80%] ${msg.is_bot ? '' : 'flex-row-reverse'}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    msg.is_bot ? 'bg-gray-200' : 'bg-blue-600'
                  }`}>
                    {msg.is_bot ? (
                      <Bot className="h-4 w-4 text-gray-600" />
                    ) : (
                      <User className="h-4 w-4 text-white" />
                    )}
                  </div>
                  <div className={`rounded-lg p-3 ${
                    msg.is_bot ? 'bg-gray-100' : 'bg-blue-600 text-white'
                  }`}>
                    <p className="text-sm">{msg.message}</p>
                    <p className={`text-xs mt-1 ${
                      msg.is_bot ? 'text-gray-400' : 'text-blue-100'
                    }`}>
                      {new Date(msg.created_at).toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-gray-100 rounded-lg p-3">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100" />
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200" />
                  </div>
                </div>
              </div>
            )}
            <div ref={scrollRef} />
          </div>
        </ScrollArea>
        <div className="p-4 border-t">
          <div className="flex gap-2">
            <Button variant="ghost" size="sm">
              <Paperclip className="h-4 w-4" />
            </Button>
            <Input
              placeholder="Type your message..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
              className="flex-1"
            />
            <Button onClick={sendMessage} disabled={loading} size="sm">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}