import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, BookOpen, HelpCircle, ThumbsUp, ThumbsDown, Eye } from 'lucide-react';

interface Article {
  id: string;
  title: string;
  content: string;
  category: string;
  views: number;
  helpful_count: number;
  tags: string[];
}

interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: string;
  helpful_count: number;
}

export function KnowledgeBase() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchContent();
  }, []);

  const fetchContent = async () => {
    try {
      const [articlesRes, faqsRes] = await Promise.all([
        supabase
          .from('knowledge_articles')
          .select('*')
          .eq('status', 'published')
          .order('views', { ascending: false }),
        supabase
          .from('faqs')
          .select('*')
          .order('order_index')
      ]);

      setArticles(articlesRes.data || []);
      setFaqs(faqsRes.data || []);
    } catch (error) {
      console.error('Error fetching content:', error);
    } finally {
      setLoading(false);
    }
  };

  const trackView = async (articleId: string) => {
    await supabase
      .from('knowledge_articles')
      .update({ views: articles.find(a => a.id === articleId)?.views || 0 + 1 })
      .eq('id', articleId);
  };

  const markHelpful = async (type: 'article' | 'faq', id: string, helpful: boolean) => {
    const table = type === 'article' ? 'knowledge_articles' : 'faqs';
    const field = helpful ? 'helpful_count' : 'not_helpful_count';
    
    const current = type === 'article' 
      ? articles.find(a => a.id === id)
      : faqs.find(f => f.id === id);
    
    if (current) {
      await supabase
        .from(table)
        .update({ [field]: (current as any)[field] || 0 + 1 })
        .eq('id', id);
    }
  };

  const filteredArticles = articles.filter(article =>
    (selectedCategory === 'all' || article.category === selectedCategory) &&
    (searchQuery === '' || 
     article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
     article.content.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const filteredFAQs = faqs.filter(faq =>
    (selectedCategory === 'all' || faq.category === selectedCategory) &&
    (searchQuery === '' || 
     faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
     faq.answer.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const categories = ['all', 'getting-started', 'billing', 'features', 'troubleshooting', 'api'];

  if (loading) {
    return <div className="flex justify-center p-8">Loading knowledge base...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold">How can we help you?</h1>
        <div className="max-w-2xl mx-auto relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <Input
            placeholder="Search for articles or questions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 h-12 text-lg"
          />
        </div>
      </div>

      <div className="flex justify-center gap-2 flex-wrap">
        {categories.map((cat) => (
          <Badge
            key={cat}
            variant={selectedCategory === cat ? 'default' : 'outline'}
            className="cursor-pointer px-4 py-2"
            onClick={() => setSelectedCategory(cat)}
          >
            {cat === 'all' ? 'All Categories' : cat.charAt(0).toUpperCase() + cat.slice(1).replace('-', ' ')}
          </Badge>
        ))}
      </div>

      <Tabs defaultValue="articles" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="articles">
            <BookOpen className="h-4 w-4 mr-2" />
            Articles
          </TabsTrigger>
          <TabsTrigger value="faqs">
            <HelpCircle className="h-4 w-4 mr-2" />
            FAQs
          </TabsTrigger>
        </TabsList>

        <TabsContent value="articles" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredArticles.map((article) => (
              <Card key={article.id} className="hover:shadow-lg transition-shadow cursor-pointer"
                    onClick={() => trackView(article.id)}>
                <CardHeader>
                  <CardTitle className="text-lg">{article.title}</CardTitle>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <Eye className="h-3 w-3" />
                    <span>{article.views} views</span>
                    <ThumbsUp className="h-3 w-3 ml-2" />
                    <span>{article.helpful_count}</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 line-clamp-3">{article.content}</p>
                  <div className="flex gap-1 mt-3">
                    {article.tags.slice(0, 3).map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="faqs" className="space-y-4">
          <div className="space-y-4">
            {filteredFAQs.map((faq) => (
              <Card key={faq.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-base">{faq.question}</CardTitle>
                    <Badge variant="outline">{faq.category}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">{faq.answer}</p>
                  <div className="flex items-center gap-4 mt-4">
                    <span className="text-sm text-gray-500">Was this helpful?</span>
                    <button
                      onClick={() => markHelpful('faq', faq.id, true)}
                      className="flex items-center gap-1 text-sm text-gray-600 hover:text-green-600"
                    >
                      <ThumbsUp className="h-4 w-4" />
                      Yes
                    </button>
                    <button
                      onClick={() => markHelpful('faq', faq.id, false)}
                      className="flex items-center gap-1 text-sm text-gray-600 hover:text-red-600"
                    >
                      <ThumbsDown className="h-4 w-4" />
                      No
                    </button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {filteredArticles.length === 0 && filteredFAQs.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No results found. Try a different search term.</p>
        </div>
      )}
    </div>
  );
}