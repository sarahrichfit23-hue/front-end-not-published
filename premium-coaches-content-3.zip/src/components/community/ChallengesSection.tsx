import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { Trophy, Calendar, Users, Target, Plus, CheckCircle } from 'lucide-react';
import { format, differenceInDays } from 'date-fns';

interface Challenge {
  id: string;
  title: string;
  description: string;
  start_date: string;
  end_date: string;
  prize: string;
  rules: string[];
  created_at: string;
  participant_count?: number;
  is_participating?: boolean;
  my_progress?: number;
}

const ChallengesSection = ({ user }: { user: any }) => {
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [showCreateChallenge, setShowCreateChallenge] = useState(false);
  const [newChallenge, setNewChallenge] = useState({
    title: '',
    description: '',
    start_date: '',
    end_date: '',
    prize: '',
    rules: ''
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchChallenges();
  }, [user]);

  const fetchChallenges = async () => {
    const { data: challengesData } = await supabase
      .from('challenges')
      .select(`
        *,
        challenge_participants (id, user_id, progress, completed)
      `)
      .order('created_at', { ascending: false });

    if (challengesData) {
      const challengesWithInfo = challengesData.map((challenge) => {
        const participants = challenge.challenge_participants || [];
        const userParticipation = user ? participants.find(p => p.user_id === user.id) : null;
        
        return {
          ...challenge,
          participant_count: participants.length,
          is_participating: !!userParticipation,
          my_progress: userParticipation?.progress || 0
        };
      });
      setChallenges(challengesWithInfo);
    }
  };

  const handleCreateChallenge = async () => {
    if (!user) {
      toast({ title: 'Please login to create a challenge', variant: 'destructive' });
      return;
    }

    const { error } = await supabase
      .from('challenges')
      .insert({
        title: newChallenge.title,
        description: newChallenge.description,
        start_date: newChallenge.start_date,
        end_date: newChallenge.end_date,
        prize: newChallenge.prize,
        rules: newChallenge.rules.split('\n').filter(Boolean),
        created_by: user.id
      });

    if (error) {
      toast({ title: 'Error creating challenge', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Challenge created successfully!' });
      setShowCreateChallenge(false);
      setNewChallenge({
        title: '',
        description: '',
        start_date: '',
        end_date: '',
        prize: '',
        rules: ''
      });
      fetchChallenges();
    }
  };

  const handleJoinChallenge = async (challengeId: string) => {
    if (!user) {
      toast({ title: 'Please login to join challenges', variant: 'destructive' });
      return;
    }

    const { error } = await supabase
      .from('challenge_participants')
      .insert({
        challenge_id: challengeId,
        user_id: user.id,
        progress: 0,
        completed: false
      });

    if (error) {
      toast({ title: 'Error joining challenge', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Successfully joined the challenge!' });
      fetchChallenges();
    }
  };

  const handleUpdateProgress = async (challengeId: string, newProgress: number) => {
    if (!user) return;

    const { error } = await supabase
      .from('challenge_participants')
      .update({ 
        progress: newProgress,
        completed: newProgress >= 100
      })
      .eq('challenge_id', challengeId)
      .eq('user_id', user.id);

    if (error) {
      toast({ title: 'Error updating progress', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Progress updated!' });
      fetchChallenges();
    }
  };

  const getChallengeStatus = (startDate: string, endDate: string) => {
    const now = new Date();
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    if (now < start) return { status: 'upcoming', color: 'bg-blue-500' };
    if (now > end) return { status: 'completed', color: 'bg-gray-500' };
    return { status: 'active', color: 'bg-green-500' };
  };

  const getDaysRemaining = (endDate: string) => {
    const days = differenceInDays(new Date(endDate), new Date());
    return days > 0 ? days : 0;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold">Challenges</h3>
        <Dialog open={showCreateChallenge} onOpenChange={setShowCreateChallenge}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Create Challenge
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Challenge</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Input
                placeholder="Challenge title"
                value={newChallenge.title}
                onChange={(e) => setNewChallenge({ ...newChallenge, title: e.target.value })}
              />
              <Textarea
                placeholder="Challenge description"
                value={newChallenge.description}
                onChange={(e) => setNewChallenge({ ...newChallenge, description: e.target.value })}
                rows={3}
              />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Start Date</label>
                  <Input
                    type="date"
                    value={newChallenge.start_date}
                    onChange={(e) => setNewChallenge({ ...newChallenge, start_date: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">End Date</label>
                  <Input
                    type="date"
                    value={newChallenge.end_date}
                    onChange={(e) => setNewChallenge({ ...newChallenge, end_date: e.target.value })}
                  />
                </div>
              </div>
              <Input
                placeholder="Prize (optional)"
                value={newChallenge.prize}
                onChange={(e) => setNewChallenge({ ...newChallenge, prize: e.target.value })}
              />
              <Textarea
                placeholder="Rules (one per line)"
                value={newChallenge.rules}
                onChange={(e) => setNewChallenge({ ...newChallenge, rules: e.target.value })}
                rows={4}
              />
              <Button onClick={handleCreateChallenge} className="w-full">Create Challenge</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {challenges.map((challenge) => {
          const { status, color } = getChallengeStatus(challenge.start_date, challenge.end_date);
          const daysRemaining = getDaysRemaining(challenge.end_date);
          
          return (
            <Card key={challenge.id} className="overflow-hidden">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-xl">{challenge.title}</CardTitle>
                    <CardDescription className="mt-2">{challenge.description}</CardDescription>
                  </div>
                  <Badge className={color}>{status}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <span>{format(new Date(challenge.start_date), 'MMM d')} - {format(new Date(challenge.end_date), 'MMM d')}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    <span>{challenge.participant_count} participants</span>
                  </div>
                </div>

                {challenge.prize && (
                  <div className="flex items-center gap-2 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                    <Trophy className="w-5 h-5 text-yellow-600" />
                    <span className="text-sm font-medium">Prize: {challenge.prize}</span>
                  </div>
                )}

                {challenge.is_participating && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Your Progress</span>
                      <span className="font-medium">{challenge.my_progress}%</span>
                    </div>
                    <Progress value={challenge.my_progress} />
                    {status === 'active' && (
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleUpdateProgress(challenge.id, Math.min(challenge.my_progress + 10, 100))}
                        >
                          +10%
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleUpdateProgress(challenge.id, 100)}
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Complete
                        </Button>
                      </div>
                    )}
                  </div>
                )}

                {!challenge.is_participating && status !== 'completed' && (
                  <Button className="w-full" onClick={() => handleJoinChallenge(challenge.id)}>
                    <Target className="w-4 h-4 mr-2" />
                    Join Challenge
                  </Button>
                )}

                {status === 'active' && (
                  <p className="text-sm text-muted-foreground text-center">
                    {daysRemaining} days remaining
                  </p>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default ChallengesSection;