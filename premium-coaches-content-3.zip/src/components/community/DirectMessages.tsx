import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { Send, Search, MessageCircle, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  is_read: boolean;
  created_at: string;
  sender?: {
    full_name: string;
    business_name: string;
  };
  receiver?: {
    full_name: string;
    business_name: string;
  };
}

interface Conversation {
  user_id: string;
  user_name: string;
  business_name: string;
  last_message: string;
  last_message_time: string;
  unread_count: number;
}

const DirectMessages = ({ user }: { user: any }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [members, setMembers] = useState<any[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      fetchConversations();
      fetchMembers();
      subscribeToMessages();
    }
  }, [user]);

  useEffect(() => {
    if (selectedConversation) {
      fetchMessages(selectedConversation);
      markAsRead(selectedConversation);
    }
  }, [selectedConversation]);

  const fetchConversations = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('direct_messages')
      .select(`
        *,
        sender:profiles!sender_id (full_name, business_name),
        receiver:profiles!receiver_id (full_name, business_name)
      `)
      .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
      .order('created_at', { ascending: false });

    if (data) {
      // Group messages by conversation
      const convMap = new Map<string, Conversation>();
      
      data.forEach((msg) => {
        const otherUserId = msg.sender_id === user.id ? msg.receiver_id : msg.sender_id;
        const otherUser = msg.sender_id === user.id ? msg.receiver : msg.sender;
        
        if (!convMap.has(otherUserId) || new Date(msg.created_at) > new Date(convMap.get(otherUserId)!.last_message_time)) {
          const unreadCount = data.filter(m => 
            m.sender_id === otherUserId && 
            m.receiver_id === user.id && 
            !m.is_read
          ).length;

          convMap.set(otherUserId, {
            user_id: otherUserId,
            user_name: otherUser?.full_name || 'Unknown',
            business_name: otherUser?.business_name || '',
            last_message: msg.content,
            last_message_time: msg.created_at,
            unread_count: unreadCount
          });
        }
      });

      setConversations(Array.from(convMap.values()));
    }
  };

  const fetchMessages = async (otherUserId: string) => {
    if (!user) return;

    const { data } = await supabase
      .from('direct_messages')
      .select(`
        *,
        sender:profiles!sender_id (full_name, business_name),
        receiver:profiles!receiver_id (full_name, business_name)
      `)
      .or(`and(sender_id.eq.${user.id},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${user.id})`)
      .order('created_at', { ascending: true });

    if (data) {
      setMessages(data);
    }
  };

  const fetchMembers = async () => {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .neq('id', user?.id)
      .order('full_name');

    if (data) {
      setMembers(data);
    }
  };

  const markAsRead = async (senderId: string) => {
    if (!user) return;

    await supabase
      .from('direct_messages')
      .update({ is_read: true })
      .eq('sender_id', senderId)
      .eq('receiver_id', user.id);
  };

  const subscribeToMessages = () => {
    if (!user) return;

    const subscription = supabase
      .channel('direct_messages')
      .on('postgres_changes', 
        { 
          event: 'INSERT', 
          schema: 'public', 
          table: 'direct_messages',
          filter: `or(sender_id.eq.${user.id},receiver_id.eq.${user.id})`
        }, 
        () => {
          fetchConversations();
          if (selectedConversation) {
            fetchMessages(selectedConversation);
          }
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  };

  const handleSendMessage = async () => {
    if (!user || !selectedConversation || !newMessage.trim()) return;

    const { error } = await supabase
      .from('direct_messages')
      .insert({
        sender_id: user.id,
        receiver_id: selectedConversation,
        content: newMessage.trim(),
        is_read: false
      });

    if (error) {
      toast({ title: 'Error sending message', description: error.message, variant: 'destructive' });
    } else {
      setNewMessage('');
      fetchMessages(selectedConversation);
      fetchConversations();
    }
  };

  const startNewConversation = (memberId: string) => {
    setSelectedConversation(memberId);
  };

  const filteredMembers = members.filter(member =>
    member.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.business_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedUser = selectedConversation 
    ? conversations.find(c => c.user_id === selectedConversation) || 
      members.find(m => m.id === selectedConversation)
    : null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-[600px]">
      <Card className="md:col-span-1">
        <CardHeader>
          <CardTitle>Conversations</CardTitle>
          <Input
            placeholder="Search members..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="mt-2"
          />
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-[480px]">
            {searchTerm ? (
              <div className="p-4 space-y-2">
                <p className="text-sm text-muted-foreground mb-2">Start new conversation:</p>
                {filteredMembers.map((member) => (
                  <div
                    key={member.id}
                    className="flex items-center gap-3 p-3 hover:bg-accent rounded-lg cursor-pointer"
                    onClick={() => startNewConversation(member.id)}
                  >
                    <Avatar>
                      <AvatarFallback>{member.full_name?.[0] || 'U'}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="font-medium">{member.full_name}</p>
                      <p className="text-sm text-muted-foreground">{member.business_name}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 space-y-2">
                {conversations.map((conv) => (
                  <div
                    key={conv.user_id}
                    className={`flex items-center gap-3 p-3 hover:bg-accent rounded-lg cursor-pointer ${
                      selectedConversation === conv.user_id ? 'bg-accent' : ''
                    }`}
                    onClick={() => setSelectedConversation(conv.user_id)}
                  >
                    <Avatar>
                      <AvatarFallback>{conv.user_name?.[0] || 'U'}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="font-medium truncate">{conv.user_name}</p>
                        {conv.unread_count > 0 && (
                          <Badge variant="destructive" className="ml-2">
                            {conv.unread_count}
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground truncate">{conv.last_message}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(conv.last_message_time))} ago
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      <Card className="md:col-span-2">
        {selectedConversation ? (
          <>
            <CardHeader className="border-b">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback>
                    {selectedUser?.user_name?.[0] || selectedUser?.full_name?.[0] || 'U'}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold">
                    {selectedUser?.user_name || selectedUser?.full_name}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {selectedUser?.business_name}
                  </p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[400px] p-4">
                <div className="space-y-4">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.sender_id === user?.id ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[70%] ${
                        msg.sender_id === user?.id 
                          ? 'bg-primary text-primary-foreground' 
                          : 'bg-muted'
                      } rounded-lg p-3`}>
                        <p>{msg.content}</p>
                        <p className="text-xs opacity-70 mt-1">
                          {formatDistanceToNow(new Date(msg.created_at))} ago
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
              <div className="p-4 border-t">
                <div className="flex gap-2">
                  <Input
                    placeholder="Type a message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  <Button onClick={handleSendMessage}>
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </>
        ) : (
          <CardContent className="flex items-center justify-center h-full">
            <div className="text-center">
              <MessageCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Select a conversation or search for a member to start messaging</p>
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
};

export default DirectMessages;