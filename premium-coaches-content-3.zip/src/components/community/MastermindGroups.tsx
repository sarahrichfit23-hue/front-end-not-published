import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { Users, Lock, Globe, Plus, UserPlus, Crown } from 'lucide-react';

interface Group {
  id: string;
  name: string;
  description: string;
  category: string;
  max_members: number;
  is_private: boolean;
  created_by: string;
  created_at: string;
  member_count?: number;
  is_member?: boolean;
}

const MastermindGroups = ({ user }: { user: any }) => {
  const [groups, setGroups] = useState<Group[]>([]);
  const [myGroups, setMyGroups] = useState<Group[]>([]);
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [newGroup, setNewGroup] = useState({
    name: '',
    description: '',
    category: 'general',
    max_members: 10,
    is_private: false
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchGroups();
    if (user) fetchMyGroups();
  }, [user]);

  const fetchGroups = async () => {
    const { data: groupsData } = await supabase
      .from('mastermind_groups')
      .select(`
        *,
        group_members (id)
      `)
      .order('created_at', { ascending: false });

    if (groupsData) {
      const groupsWithCount = await Promise.all(groupsData.map(async (group) => {
        const memberCount = group.group_members?.length || 0;
        let isMember = false;
        
        if (user) {
          const { data: membership } = await supabase
            .from('group_members')
            .select('id')
            .eq('group_id', group.id)
            .eq('user_id', user.id)
            .single();
          isMember = !!membership;
        }

        return {
          ...group,
          member_count: memberCount,
          is_member: isMember
        };
      }));
      setGroups(groupsWithCount);
    }
  };

  const fetchMyGroups = async () => {
    const { data } = await supabase
      .from('group_members')
      .select(`
        mastermind_groups (*)
      `)
      .eq('user_id', user.id);

    if (data) {
      setMyGroups(data.map(item => item.mastermind_groups).filter(Boolean));
    }
  };

  const handleCreateGroup = async () => {
    if (!user) {
      toast({ title: 'Please login to create a group', variant: 'destructive' });
      return;
    }

    const { error } = await supabase
      .from('mastermind_groups')
      .insert({
        ...newGroup,
        created_by: user.id
      });

    if (error) {
      toast({ title: 'Error creating group', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Group created successfully!' });
      setShowCreateGroup(false);
      setNewGroup({
        name: '',
        description: '',
        category: 'general',
        max_members: 10,
        is_private: false
      });
      fetchGroups();
    }
  };

  const handleJoinGroup = async (groupId: string) => {
    if (!user) {
      toast({ title: 'Please login to join groups', variant: 'destructive' });
      return;
    }

    const { error } = await supabase
      .from('group_members')
      .insert({
        group_id: groupId,
        user_id: user.id,
        role: 'member'
      });

    if (error) {
      toast({ title: 'Error joining group', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Successfully joined the group!' });
      fetchGroups();
      fetchMyGroups();
    }
  };

  const handleLeaveGroup = async (groupId: string) => {
    if (!user) return;

    const { error } = await supabase
      .from('group_members')
      .delete()
      .eq('group_id', groupId)
      .eq('user_id', user.id);

    if (error) {
      toast({ title: 'Error leaving group', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Successfully left the group' });
      fetchGroups();
      fetchMyGroups();
    }
  };

  const categoryColors: Record<string, string> = {
    general: 'bg-blue-500',
    marketing: 'bg-purple-500',
    sales: 'bg-green-500',
    mindset: 'bg-yellow-500',
    tech: 'bg-red-500'
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold">Mastermind Groups</h3>
        <Dialog open={showCreateGroup} onOpenChange={setShowCreateGroup}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Create Group
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Mastermind Group</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Group Name</Label>
                <Input
                  value={newGroup.name}
                  onChange={(e) => setNewGroup({ ...newGroup, name: e.target.value })}
                  placeholder="Enter group name"
                />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea
                  value={newGroup.description}
                  onChange={(e) => setNewGroup({ ...newGroup, description: e.target.value })}
                  placeholder="Describe your group's purpose"
                  rows={3}
                />
              </div>
              <div>
                <Label>Category</Label>
                <Select value={newGroup.category} onValueChange={(v) => setNewGroup({ ...newGroup, category: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General</SelectItem>
                    <SelectItem value="marketing">Marketing</SelectItem>
                    <SelectItem value="sales">Sales</SelectItem>
                    <SelectItem value="mindset">Mindset</SelectItem>
                    <SelectItem value="tech">Tech & Tools</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Max Members</Label>
                <Input
                  type="number"
                  value={newGroup.max_members}
                  onChange={(e) => setNewGroup({ ...newGroup, max_members: parseInt(e.target.value) })}
                  min="2"
                  max="50"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  checked={newGroup.is_private}
                  onCheckedChange={(checked) => setNewGroup({ ...newGroup, is_private: checked })}
                />
                <Label>Private Group (Invite Only)</Label>
              </div>
              <Button onClick={handleCreateGroup} className="w-full">Create Group</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {myGroups.length > 0 && (
        <div>
          <h4 className="text-lg font-medium mb-3">My Groups</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {myGroups.map((group) => (
              <Card key={group.id} className="border-primary/20">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center justify-between">
                    {group.name}
                    <Badge variant="outline">Member</Badge>
                  </CardTitle>
                  <CardDescription>{group.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <Badge className={categoryColors[group.category]}>{group.category}</Badge>
                    <Button variant="ghost" size="sm" onClick={() => handleLeaveGroup(group.id)}>
                      Leave
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      <div>
        <h4 className="text-lg font-medium mb-3">Discover Groups</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {groups.filter(g => !g.is_member).map((group) => (
            <Card key={group.id}>
              <CardHeader>
                <CardTitle className="text-lg flex items-center justify-between">
                  {group.name}
                  {group.is_private ? <Lock className="w-4 h-4" /> : <Globe className="w-4 h-4" />}
                </CardTitle>
                <CardDescription>{group.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Badge className={categoryColors[group.category]}>{group.category}</Badge>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Users className="w-4 h-4" />
                      {group.member_count}/{group.max_members}
                    </div>
                  </div>
                  <Button 
                    className="w-full" 
                    onClick={() => handleJoinGroup(group.id)}
                    disabled={group.member_count >= group.max_members}
                  >
                    <UserPlus className="w-4 h-4 mr-2" />
                    {group.member_count >= group.max_members ? 'Full' : 'Join Group'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MastermindGroups;