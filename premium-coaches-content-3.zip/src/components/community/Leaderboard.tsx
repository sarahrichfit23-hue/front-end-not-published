import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Trophy, Flame, Star, TrendingUp } from 'lucide-react';

export function Leaderboard() {
  const [streakLeaders, setStreakLeaders] = useState<any[]>([]);
  const [pointsLeaders, setPointsLeaders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLeaderboards();
  }, []);

  const loadLeaderboards = async () => {
    try {
      const { data: streakData } = await supabase
        .from('user_accountability')
        .select('display_name, current_streak, show_on_leaderboard')
        .eq('show_on_leaderboard', true)
        .order('current_streak', { ascending: false })
        .limit(10);

      const { data: pointsData } = await supabase
        .from('user_accountability')
        .select('display_name, total_points, show_on_leaderboard')
        .eq('show_on_leaderboard', true)
        .order('total_points', { ascending: false })
        .limit(10);

      setStreakLeaders(streakData || []);
      setPointsLeaders(pointsData || []);
    } catch (error) {
      console.error('Load leaderboard error:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRankBadge = (index: number) => {
    if (index === 0) return <Trophy className="w-5 h-5 text-yellow-500" />;
    if (index === 1) return <Trophy className="w-5 h-5 text-gray-400" />;
    if (index === 2) return <Trophy className="w-5 h-5 text-amber-600" />;
    return <span className="text-sm text-muted-foreground">#{index + 1}</span>;
  };

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-6">
        <Trophy className="w-6 h-6 text-amber-500" />
        <h2 className="text-2xl font-bold">Community Leaderboard</h2>
      </div>

      <Tabs defaultValue="streaks" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="streaks">
            <Flame className="w-4 h-4 mr-2" />
            Top Streaks
          </TabsTrigger>
          <TabsTrigger value="points">
            <Star className="w-4 h-4 mr-2" />
            Total Points
          </TabsTrigger>
        </TabsList>

        <TabsContent value="streaks" className="space-y-3 mt-4">
          {streakLeaders.map((leader, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div className="flex items-center gap-3">
                {getRankBadge(index)}
                <Avatar className="w-10 h-10">
                  <AvatarFallback>
                    {leader.display_name?.[0]?.toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <span className="font-medium">{leader.display_name || 'Anonymous User'}</span>
              </div>
              <Badge variant="secondary" className="flex items-center gap-1">
                <Flame className="w-4 h-4 text-orange-500" />
                {leader.current_streak} days
              </Badge>
            </div>
          ))}
          {streakLeaders.length === 0 && (
            <p className="text-center text-muted-foreground py-8">
              No leaders yet. Be the first to build a streak!
            </p>
          )}
        </TabsContent>

        <TabsContent value="points" className="space-y-3 mt-4">
          {pointsLeaders.map((leader, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div className="flex items-center gap-3">
                {getRankBadge(index)}
                <Avatar className="w-10 h-10">
                  <AvatarFallback>
                    {leader.display_name?.[0]?.toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <span className="font-medium">{leader.display_name || 'Anonymous User'}</span>
              </div>
              <Badge variant="secondary" className="flex items-center gap-1">
                <Star className="w-4 h-4 text-amber-500" />
                {leader.total_points} pts
              </Badge>
            </div>
          ))}
          {pointsLeaders.length === 0 && (
            <p className="text-center text-muted-foreground py-8">
              No leaders yet. Complete challenges to earn points!
            </p>
          )}
        </TabsContent>
      </Tabs>
    </Card>
  );
}

export default Leaderboard;
