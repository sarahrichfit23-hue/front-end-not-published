import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { MessageSquare, Heart, Eye, Plus, Clock, User } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface Post {
  id: string;
  title: string;
  content: string;
  category: string;
  tags: string[];
  likes: number;
  views: number;
  created_at: string;
  user_id: string;
  profiles: {
    full_name: string;
    business_name: string;
  };
  comments_count?: number;
}

const ForumSection = ({ user }: { user: any }) => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [filteredPosts, setFilteredPosts] = useState<Post[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showNewPost, setShowNewPost] = useState(false);
  const [newPost, setNewPost] = useState({
    title: '',
    content: '',
    category: 'discussion',
    tags: ''
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchPosts();
    subscribeToUpdates();
  }, []);

  useEffect(() => {
    filterPosts();
  }, [posts, searchTerm, selectedCategory]);

  const fetchPosts = async () => {
    const { data, error } = await supabase
      .from('community_posts')
      .select(`
        *,
        profiles!user_id (full_name, business_name),
        post_comments (id)
      `)
      .order('created_at', { ascending: false });

    if (data) {
      const postsWithCount = data.map(post => ({
        ...post,
        comments_count: post.post_comments?.length || 0
      }));
      setPosts(postsWithCount);
    }
  };

  const subscribeToUpdates = () => {
    const subscription = supabase
      .channel('forum_posts')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'community_posts' }, () => {
        fetchPosts();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  };

  const filterPosts = () => {
    let filtered = [...posts];
    
    if (searchTerm) {
      filtered = filtered.filter(post => 
        post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(post => post.category === selectedCategory);
    }

    setFilteredPosts(filtered);
  };

  const handleCreatePost = async () => {
    if (!user) {
      toast({ title: 'Please login to create a post', variant: 'destructive' });
      return;
    }

    const { error } = await supabase
      .from('community_posts')
      .insert({
        title: newPost.title,
        content: newPost.content,
        category: newPost.category,
        tags: newPost.tags.split(',').map(tag => tag.trim()).filter(Boolean),
        user_id: user.id
      });

    if (error) {
      toast({ title: 'Error creating post', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Post created successfully!' });
      setShowNewPost(false);
      setNewPost({ title: '', content: '', category: 'discussion', tags: '' });
      fetchPosts();
    }
  };

  const handleLikePost = async (postId: string, currentLikes: number) => {
    if (!user) {
      toast({ title: 'Please login to like posts', variant: 'destructive' });
      return;
    }

    await supabase
      .from('community_posts')
      .update({ likes: currentLikes + 1 })
      .eq('id', postId);
    
    fetchPosts();
  };

  const incrementViews = async (postId: string, currentViews: number) => {
    await supabase
      .from('community_posts')
      .update({ views: currentViews + 1 })
      .eq('id', postId);
  };

  const categoryColors: Record<string, string> = {
    success_story: 'bg-green-500',
    question: 'bg-blue-500',
    discussion: 'bg-purple-500',
    resource: 'bg-orange-500',
    announcement: 'bg-red-500'
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-4 items-center">
        <div className="flex-1">
          <Input
            placeholder="Search posts, tags..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full"
          />
        </div>
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="success_story">Success Stories</SelectItem>
            <SelectItem value="question">Questions</SelectItem>
            <SelectItem value="discussion">Discussions</SelectItem>
            <SelectItem value="resource">Resources</SelectItem>
            <SelectItem value="announcement">Announcements</SelectItem>
          </SelectContent>
        </Select>
        <Dialog open={showNewPost} onOpenChange={setShowNewPost}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              New Post
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Post</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Input
                placeholder="Post title..."
                value={newPost.title}
                onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
              />
              <Select value={newPost.category} onValueChange={(v) => setNewPost({ ...newPost, category: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="success_story">Success Story</SelectItem>
                  <SelectItem value="question">Question</SelectItem>
                  <SelectItem value="discussion">Discussion</SelectItem>
                  <SelectItem value="resource">Resource</SelectItem>
                  <SelectItem value="announcement">Announcement</SelectItem>
                </SelectContent>
              </Select>
              <Textarea
                placeholder="Write your post..."
                value={newPost.content}
                onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                rows={6}
              />
              <Input
                placeholder="Tags (comma separated)"
                value={newPost.tags}
                onChange={(e) => setNewPost({ ...newPost, tags: e.target.value })}
              />
              <Button onClick={handleCreatePost} className="w-full">Create Post</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-4">
        {filteredPosts.map((post) => (
          <Card key={post.id} className="hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => incrementViews(post.id, post.views)}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback>{post.profiles?.full_name?.[0] || 'U'}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold text-lg">{post.title}</h3>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span>{post.profiles?.full_name || 'Anonymous'}</span>
                      <span>•</span>
                      <span>{formatDistanceToNow(new Date(post.created_at))} ago</span>
                    </div>
                  </div>
                </div>
                <Badge className={categoryColors[post.category]}>
                  {post.category.replace('_', ' ')}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground line-clamp-3">{post.content}</p>
              <div className="flex items-center gap-4 mt-4">
                <Button variant="ghost" size="sm" onClick={(e) => {
                  e.stopPropagation();
                  handleLikePost(post.id, post.likes);
                }}>
                  <Heart className="w-4 h-4 mr-1" />
                  {post.likes}
                </Button>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <MessageSquare className="w-4 h-4" />
                  {post.comments_count}
                </div>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Eye className="w-4 h-4" />
                  {post.views}
                </div>
                <div className="flex gap-2 ml-auto">
                  {post.tags.map((tag, i) => (
                    <Badge key={i} variant="secondary">{tag}</Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ForumSection;