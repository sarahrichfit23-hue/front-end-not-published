import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  MoreVertical, 
  Edit, 
  Copy, 
  Trash, 
  BarChart, 
  Zap, 
  Target,
  Clock,
  Users
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface AutomationListProps {
  rules: any[];
  onToggleStatus: (rule: any) => void;
  onEdit: (rule: any) => void;
  onRefresh: () => void;
}

export default function AutomationList({ 
  rules, 
  onToggleStatus, 
  onEdit, 
  onRefresh 
}: AutomationListProps) {
  const { toast } = useToast();

  const deleteRule = async (ruleId: string) => {
    if (!confirm('Are you sure you want to delete this automation rule?')) return;

    try {
      const { error } = await supabase
        .from('automation_rules')
        .delete()
        .eq('id', ruleId);

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Automation rule deleted'
      });
      onRefresh();
    } catch (error) {
      console.error('Error deleting rule:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete rule',
        variant: 'destructive'
      });
    }
  };

  const duplicateRule = async (rule: any) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Create a copy of the rule
      const { data: newRule, error: ruleError } = await supabase
        .from('automation_rules')
        .insert({
          user_id: user.id,
          name: `${rule.name} (Copy)`,
          description: rule.description,
          is_active: false,
          is_global: false,
          priority: rule.priority
        })
        .select()
        .single();

      if (ruleError) throw ruleError;

      // Copy triggers
      for (const trigger of rule.automation_triggers || []) {
        await supabase.from('automation_triggers').insert({
          rule_id: newRule.id,
          trigger_type: trigger.trigger_type,
          trigger_config: trigger.trigger_config
        });
      }

      // Copy actions
      for (const action of rule.automation_actions || []) {
        await supabase.from('automation_actions').insert({
          rule_id: newRule.id,
          action_type: action.action_type,
          action_config: action.action_config,
          execution_order: action.execution_order,
          delay_minutes: action.delay_minutes
        });
      }

      toast({
        title: 'Success',
        description: 'Automation rule duplicated'
      });
      onRefresh();
    } catch (error) {
      console.error('Error duplicating rule:', error);
      toast({
        title: 'Error',
        description: 'Failed to duplicate rule',
        variant: 'destructive'
      });
    }
  };

  const getTriggerLabel = (trigger: any) => {
    const labels: Record<string, string> = {
      subscriber_signup: 'New Subscriber',
      content_download: 'Content Download',
      content_generation: 'Content Generated',
      form_submission: 'Form Submitted',
      abandoned_flow: 'Flow Abandoned',
      date_time: 'Scheduled',
      engagement_milestone: 'Engagement Milestone',
      tag_added: 'Tag Added',
      segment_entered: 'Segment Entered'
    };
    return labels[trigger.trigger_type] || trigger.trigger_type;
  };

  const getActionLabel = (action: any) => {
    const labels: Record<string, string> = {
      send_email: 'Send Email',
      send_sms: 'Send SMS',
      push_notification: 'Push Notification',
      add_tag: 'Add Tag',
      remove_tag: 'Remove Tag',
      move_to_segment: 'Move to Segment',
      unlock_content: 'Unlock Content',
      post_social: 'Post to Social',
      redirect_landing: 'Redirect to Page',
      webhook: 'Call Webhook'
    };
    return labels[action.action_type] || action.action_type;
  };

  if (rules.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Zap className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Automation Rules</h3>
          <p className="text-muted-foreground text-center mb-4">
            Create your first automation to start engaging with subscribers automatically
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-4">
      {rules.map((rule) => (
        <Card key={rule.id}>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <CardTitle className="flex items-center gap-2">
                  {rule.name}
                  {rule.is_global && (
                    <Badge variant="secondary">
                      <Users className="h-3 w-3 mr-1" />
                      Global
                    </Badge>
                  )}
                  {rule.priority > 0 && (
                    <Badge variant="outline">
                      Priority: {rule.priority}
                    </Badge>
                  )}
                </CardTitle>
                {rule.description && (
                  <p className="text-sm text-muted-foreground">
                    {rule.description}
                  </p>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={rule.is_active}
                  onCheckedChange={() => onToggleStatus(rule)}
                />
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => onEdit(rule)}>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => duplicateRule(rule)}>
                      <Copy className="mr-2 h-4 w-4" />
                      Duplicate
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <BarChart className="mr-2 h-4 w-4" />
                      View Analytics
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => deleteRule(rule.id)}
                      className="text-destructive"
                    >
                      <Trash className="mr-2 h-4 w-4" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-blue-500" />
                <span className="font-medium">IF:</span>
                <div className="flex gap-1">
                  {(rule.automation_triggers || []).map((trigger: any, i: number) => (
                    <Badge key={i} variant="secondary">
                      {getTriggerLabel(trigger)}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4 text-green-500" />
                <span className="font-medium">THEN:</span>
                <div className="flex gap-1">
                  {(rule.automation_actions || []).map((action: any, i: number) => (
                    <Badge key={i} variant="secondary">
                      {getActionLabel(action)}
                      {action.delay_minutes > 0 && (
                        <Clock className="ml-1 h-3 w-3" />
                      )}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}