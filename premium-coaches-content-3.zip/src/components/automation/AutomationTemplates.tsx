import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Mail, 
  UserPlus, 
  Download, 
  ShoppingCart, 
  Calendar,
  Trophy,
  Gift,
  Heart,
  Star,
  TrendingUp
} from 'lucide-react';

interface AutomationTemplatesProps {
  onUseTemplate: (template: any) => void;
}

const templates = [
  {
    id: '1',
    name: 'Welcome Email Series',
    description: 'Automatically send a series of welcome emails to new subscribers',
    icon: UserPlus,
    category: 'Onboarding',
    automation_triggers: [{
      trigger_type: 'subscriber_signup',
      trigger_config: {}
    }],
    automation_actions: [
      {
        action_type: 'send_email',
        action_config: { 
          subject: 'Welcome! Here\'s what to expect',
          template: 'welcome_1'
        },
        delay_minutes: 0
      },
      {
        action_type: 'send_email',
        action_config: { 
          subject: 'Your exclusive content is ready',
          template: 'welcome_2'
        },
        delay_minutes: 1440 // 1 day
      },
      {
        action_type: 'send_email',
        action_config: { 
          subject: 'Don\'t miss out on these features',
          template: 'welcome_3'
        },
        delay_minutes: 4320 // 3 days
      }
    ]
  },
  {
    id: '2',
    name: 'Content Download Follow-up',
    description: 'Send targeted emails after someone downloads your content',
    icon: Download,
    category: 'Engagement',
    automation_triggers: [{
      trigger_type: 'content_download',
      trigger_config: {}
    }],
    automation_actions: [
      {
        action_type: 'send_email',
        action_config: { 
          subject: 'Thanks for downloading!',
          template: 'download_thanks'
        },
        delay_minutes: 0
      },
      {
        action_type: 'add_tag',
        action_config: { tag: 'content_downloader' },
        delay_minutes: 0
      },
      {
        action_type: 'send_email',
        action_config: { 
          subject: 'How are you finding the content?',
          template: 'download_followup'
        },
        delay_minutes: 2880 // 2 days
      }
    ]
  },
  {
    id: '3',
    name: 'Abandoned Cart Recovery',
    description: 'Recover lost sales with automated cart abandonment emails',
    icon: ShoppingCart,
    category: 'Sales',
    automation_triggers: [{
      trigger_type: 'abandoned_flow',
      trigger_config: { flow_type: 'checkout' }
    }],
    automation_actions: [
      {
        action_type: 'send_email',
        action_config: { 
          subject: 'You left something behind!',
          template: 'cart_reminder_1'
        },
        delay_minutes: 60 // 1 hour
      },
      {
        action_type: 'send_email',
        action_config: { 
          subject: 'Still interested? Here\'s 10% off',
          template: 'cart_discount'
        },
        delay_minutes: 1440 // 1 day
      },
      {
        action_type: 'send_sms',
        action_config: { 
          message: 'Your cart is waiting! Complete your purchase with 15% off'
        },
        delay_minutes: 4320 // 3 days
      }
    ]
  },
  {
    id: '4',
    name: 'Birthday Celebration',
    description: 'Automatically send birthday wishes and special offers',
    icon: Gift,
    category: 'Loyalty',
    automation_triggers: [{
      trigger_type: 'date_time',
      trigger_config: { type: 'birthday' }
    }],
    automation_actions: [
      {
        action_type: 'send_email',
        action_config: { 
          subject: '🎉 Happy Birthday! Here\'s a gift for you',
          template: 'birthday_wish'
        },
        delay_minutes: 0
      },
      {
        action_type: 'unlock_content',
        action_config: { content_pack: 'birthday_special' },
        delay_minutes: 0
      },
      {
        action_type: 'add_tag',
        action_config: { tag: 'birthday_celebrated' },
        delay_minutes: 0
      }
    ]
  },
  {
    id: '5',
    name: 'Engagement Milestone Rewards',
    description: 'Reward loyal subscribers when they hit engagement milestones',
    icon: Trophy,
    category: 'Loyalty',
    automation_triggers: [{
      trigger_type: 'engagement_milestone',
      trigger_config: { threshold: 10 }
    }],
    automation_actions: [
      {
        action_type: 'send_email',
        action_config: { 
          subject: 'You\'ve unlocked VIP status!',
          template: 'vip_unlock'
        },
        delay_minutes: 0
      },
      {
        action_type: 'move_to_segment',
        action_config: { segment_id: 'vip_members' },
        delay_minutes: 0
      },
      {
        action_type: 'unlock_content',
        action_config: { content_pack: 'vip_exclusive' },
        delay_minutes: 0
      }
    ]
  },
  {
    id: '6',
    name: 'Weekly Newsletter',
    description: 'Automatically send weekly content digests to subscribers',
    icon: Calendar,
    category: 'Content',
    automation_triggers: [{
      trigger_type: 'date_time',
      trigger_config: { type: 'weekly', day: 'monday' }
    }],
    automation_actions: [
      {
        action_type: 'send_email',
        action_config: { 
          subject: 'Your weekly content roundup',
          template: 'weekly_digest'
        },
        delay_minutes: 0
      },
      {
        action_type: 'post_social',
        action_config: { 
          platforms: ['twitter', 'linkedin'],
          message: 'New weekly digest is out!'
        },
        delay_minutes: 60
      }
    ]
  },
  {
    id: '7',
    name: 'Re-engagement Campaign',
    description: 'Win back inactive subscribers with targeted messages',
    icon: Heart,
    category: 'Retention',
    automation_triggers: [{
      trigger_type: 'engagement_milestone',
      trigger_config: { type: 'inactive_days', threshold: 30 }
    }],
    automation_actions: [
      {
        action_type: 'send_email',
        action_config: { 
          subject: 'We miss you! Here\'s what you\'ve missed',
          template: 'reengagement_1'
        },
        delay_minutes: 0
      },
      {
        action_type: 'send_email',
        action_config: { 
          subject: 'Come back for 25% off',
          template: 'reengagement_discount'
        },
        delay_minutes: 4320 // 3 days
      }
    ]
  },
  {
    id: '8',
    name: 'Review Request',
    description: 'Ask satisfied customers for reviews at the right time',
    icon: Star,
    category: 'Feedback',
    automation_triggers: [{
      trigger_type: 'engagement_milestone',
      trigger_config: { type: 'purchase_complete', days_after: 7 }
    }],
    automation_actions: [
      {
        action_type: 'send_email',
        action_config: { 
          subject: 'How was your experience?',
          template: 'review_request'
        },
        delay_minutes: 0
      },
      {
        action_type: 'send_sms',
        action_config: { 
          message: 'Quick question: How would you rate your recent purchase? Reply 1-5 ⭐'
        },
        delay_minutes: 2880 // 2 days
      }
    ]
  },
  {
    id: '9',
    name: 'Upsell Sequence',
    description: 'Promote premium features to engaged users',
    icon: TrendingUp,
    category: 'Sales',
    automation_triggers: [{
      trigger_type: 'engagement_milestone',
      trigger_config: { type: 'high_engagement', threshold: 20 }
    }],
    automation_actions: [
      {
        action_type: 'send_email',
        action_config: { 
          subject: 'You\'re a power user! Unlock premium features',
          template: 'upsell_premium'
        },
        delay_minutes: 0
      },
      {
        action_type: 'add_tag',
        action_config: { tag: 'upsell_candidate' },
        delay_minutes: 0
      }
    ]
  }
];

const categoryColors: Record<string, string> = {
  'Onboarding': 'bg-blue-500',
  'Engagement': 'bg-green-500',
  'Sales': 'bg-purple-500',
  'Loyalty': 'bg-yellow-500',
  'Content': 'bg-indigo-500',
  'Retention': 'bg-pink-500',
  'Feedback': 'bg-orange-500'
};

export default function AutomationTemplates({ onUseTemplate }: AutomationTemplatesProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {templates.map((template) => {
        const Icon = template.icon;
        return (
          <Card key={template.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <Badge className={categoryColors[template.category]}>
                  {template.category}
                </Badge>
              </div>
              <CardTitle className="mt-4">{template.name}</CardTitle>
              <CardDescription>{template.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="text-sm">
                  <span className="font-medium">Triggers:</span>
                  <span className="ml-2 text-muted-foreground">
                    {template.automation_triggers.length} trigger(s)
                  </span>
                </div>
                <div className="text-sm">
                  <span className="font-medium">Actions:</span>
                  <span className="ml-2 text-muted-foreground">
                    {template.automation_actions.length} action(s)
                  </span>
                </div>
                <Button 
                  className="w-full" 
                  onClick={() => onUseTemplate(template)}
                >
                  Use Template
                </Button>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}