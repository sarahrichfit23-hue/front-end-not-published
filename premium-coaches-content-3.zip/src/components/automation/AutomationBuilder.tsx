import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { Plus, X, Zap, Target, Clock, ArrowRight } from 'lucide-react';

interface AutomationBuilderProps {
  rule?: any;
  onClose: () => void;
  onSave: () => void;
}

const TRIGGER_TYPES = [
  { value: 'subscriber_signup', label: 'New Subscriber Signup', icon: '👤' },
  { value: 'content_download', label: 'Content Download', icon: '📥' },
  { value: 'content_generation', label: 'Content Generation', icon: '✨' },
  { value: 'form_submission', label: 'Form Submission', icon: '📝' },
  { value: 'abandoned_flow', label: 'Abandoned Flow', icon: '🚪' },
  { value: 'date_time', label: 'Date/Time Schedule', icon: '📅' },
  { value: 'engagement_milestone', label: 'Engagement Milestone', icon: '🎯' },
  { value: 'tag_added', label: 'Tag Added', icon: '🏷️' },
  { value: 'segment_entered', label: 'Segment Entered', icon: '📊' }
];

const ACTION_TYPES = [
  { value: 'send_email', label: 'Send Email', icon: '📧' },
  { value: 'send_sms', label: 'Send SMS', icon: '💬' },
  { value: 'push_notification', label: 'Push Notification', icon: '🔔' },
  { value: 'add_tag', label: 'Add Tag', icon: '🏷️' },
  { value: 'remove_tag', label: 'Remove Tag', icon: '🏷️' },
  { value: 'move_to_segment', label: 'Move to Segment', icon: '📊' },
  { value: 'unlock_content', label: 'Unlock Content Pack', icon: '🔓' },
  { value: 'post_social', label: 'Post to Social Media', icon: '📱' },
  { value: 'redirect_landing', label: 'Redirect to Landing Page', icon: '🔗' },
  { value: 'webhook', label: 'Call Webhook', icon: '🔌' }
];

export default function AutomationBuilder({ rule, onClose, onSave }: AutomationBuilderProps) {
  const [name, setName] = useState(rule?.name || '');
  const [description, setDescription] = useState(rule?.description || '');
  const [isGlobal, setIsGlobal] = useState(rule?.is_global || false);
  const [priority, setPriority] = useState(rule?.priority || 0);
  const [triggers, setTriggers] = useState<any[]>(rule?.automation_triggers || []);
  const [actions, setActions] = useState<any[]>(rule?.automation_actions || []);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const addTrigger = () => {
    setTriggers([...triggers, { 
      trigger_type: 'subscriber_signup', 
      trigger_config: {} 
    }]);
  };

  const updateTrigger = (index: number, field: string, value: any) => {
    const updated = [...triggers];
    if (field === 'trigger_type') {
      updated[index].trigger_type = value;
    } else {
      updated[index].trigger_config = {
        ...updated[index].trigger_config,
        [field]: value
      };
    }
    setTriggers(updated);
  };

  const removeTrigger = (index: number) => {
    setTriggers(triggers.filter((_, i) => i !== index));
  };

  const addAction = () => {
    setActions([...actions, { 
      action_type: 'send_email', 
      action_config: {},
      execution_order: actions.length,
      delay_minutes: 0
    }]);
  };

  const updateAction = (index: number, field: string, value: any) => {
    const updated = [...actions];
    if (field === 'action_type') {
      updated[index].action_type = value;
    } else if (field === 'delay_minutes' || field === 'execution_order') {
      updated[index][field] = value;
    } else {
      updated[index].action_config = {
        ...updated[index].action_config,
        [field]: value
      };
    }
    setActions(updated);
  };

  const removeAction = (index: number) => {
    setActions(actions.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    if (!name || triggers.length === 0 || actions.length === 0) {
      toast({
        title: 'Validation Error',
        description: 'Please provide a name and at least one trigger and action',
        variant: 'destructive'
      });
      return;
    }

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      if (rule?.id) {
        // Update existing rule
        const { error } = await supabase
          .from('automation_rules')
          .update({
            name,
            description,
            is_global: isGlobal,
            priority,
            updated_at: new Date().toISOString()
          })
          .eq('id', rule.id);

        if (error) throw error;

        // Delete existing triggers and actions
        await supabase.from('automation_triggers').delete().eq('rule_id', rule.id);
        await supabase.from('automation_actions').delete().eq('rule_id', rule.id);

        // Insert new triggers
        for (const trigger of triggers) {
          await supabase.from('automation_triggers').insert({
            rule_id: rule.id,
            ...trigger
          });
        }

        // Insert new actions
        for (const action of actions) {
          await supabase.from('automation_actions').insert({
            rule_id: rule.id,
            ...action
          });
        }
      } else {
        // Create new rule
        const { data: newRule, error } = await supabase
          .from('automation_rules')
          .insert({
            user_id: user.id,
            name,
            description,
            is_global: isGlobal,
            priority
          })
          .select()
          .single();

        if (error) throw error;

        // Insert triggers
        for (const trigger of triggers) {
          await supabase.from('automation_triggers').insert({
            rule_id: newRule.id,
            ...trigger
          });
        }

        // Insert actions
        for (const action of actions) {
          await supabase.from('automation_actions').insert({
            rule_id: newRule.id,
            ...action
          });
        }
      }

      toast({
        title: 'Success',
        description: `Automation rule ${rule ? 'updated' : 'created'} successfully`
      });
      onSave();
    } catch (error) {
      console.error('Error saving rule:', error);
      toast({
        title: 'Error',
        description: 'Failed to save automation rule',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {rule ? 'Edit Automation Rule' : 'Create Automation Rule'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Info */}
          <div className="space-y-4">
            <div>
              <Label>Rule Name</Label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Welcome Email Sequence"
              />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe what this automation does"
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Switch
                  checked={isGlobal}
                  onCheckedChange={setIsGlobal}
                />
                <Label>Global Rule (applies to all users)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Label>Priority</Label>
                <Input
                  type="number"
                  value={priority}
                  onChange={(e) => setPriority(parseInt(e.target.value))}
                  className="w-20"
                />
              </div>
            </div>
          </div>

          {/* Triggers */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="mr-2 h-5 w-5" />
                IF (Triggers)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {triggers.map((trigger, index) => (
                <div key={index} className="flex items-start space-x-2">
                  <Select
                    value={trigger.trigger_type}
                    onValueChange={(value) => updateTrigger(index, 'trigger_type', value)}
                  >
                    <SelectTrigger className="w-[250px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {TRIGGER_TYPES.map(type => (
                        <SelectItem key={type.value} value={type.value}>
                          <span className="flex items-center">
                            <span className="mr-2">{type.icon}</span>
                            {type.label}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeTrigger(index)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button variant="outline" onClick={addTrigger}>
                <Plus className="mr-2 h-4 w-4" />
                Add Trigger
              </Button>
            </CardContent>
          </Card>

          {/* Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="mr-2 h-5 w-5" />
                THEN (Actions)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {actions.map((action, index) => (
                <div key={index} className="space-y-2 p-4 border rounded-lg">
                  <div className="flex items-start space-x-2">
                    <Select
                      value={action.action_type}
                      onValueChange={(value) => updateAction(index, 'action_type', value)}
                    >
                      <SelectTrigger className="w-[250px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {ACTION_TYPES.map(type => (
                          <SelectItem key={type.value} value={type.value}>
                            <span className="flex items-center">
                              <span className="mr-2">{type.icon}</span>
                              {type.label}
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4" />
                      <Input
                        type="number"
                        value={action.delay_minutes}
                        onChange={(e) => updateAction(index, 'delay_minutes', parseInt(e.target.value))}
                        className="w-20"
                        placeholder="0"
                      />
                      <span className="text-sm">min delay</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeAction(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              <Button variant="outline" onClick={addAction}>
                <Plus className="mr-2 h-4 w-4" />
                Add Action
              </Button>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={saving}>
              {saving ? 'Saving...' : 'Save Automation'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}