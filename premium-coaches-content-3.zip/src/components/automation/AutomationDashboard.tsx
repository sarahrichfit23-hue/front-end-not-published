import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { Plus, Play, Pause, BarChart, Settings, Zap } from 'lucide-react';
import AutomationBuilder from './AutomationBuilder';
import AutomationList from './AutomationList';
import AutomationAnalytics from './AutomationAnalytics';
import AutomationTemplates from './AutomationTemplates';

interface AutomationRule {
  id: string;
  name: string;
  description: string;
  is_active: boolean;
  is_global: boolean;
  priority: number;
  created_at: string;
  triggers?: any[];
  actions?: any[];
  analytics?: any;
}

export default function AutomationDashboard() {
  const [rules, setRules] = useState<AutomationRule[]>([]);
  const [selectedRule, setSelectedRule] = useState<AutomationRule | null>(null);
  const [isBuilderOpen, setIsBuilderOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('rules');
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalRules: 0,
    activeRules: 0,
    triggersToday: 0,
    actionsExecuted: 0
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchRules();
    fetchStats();
  }, []);

  const fetchRules = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('automation_rules')
        .select(`
          *,
          automation_triggers(*),
          automation_actions(*)
        `)
        .or(`user_id.eq.${user.id},is_global.eq.true`)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRules(data || []);
    } catch (error) {
      console.error('Error fetching rules:', error);
      toast({
        title: 'Error',
        description: 'Failed to load automation rules',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Fetch today's analytics
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('automation_analytics')
        .select('*')
        .eq('date', today);

      if (!error && data) {
        const totals = data.reduce((acc, curr) => ({
          triggers: acc.triggers + curr.triggers_fired,
          actions: acc.actions + curr.actions_executed
        }), { triggers: 0, actions: 0 });

        setStats(prev => ({
          ...prev,
          triggersToday: totals.triggers,
          actionsExecuted: totals.actions
        }));
      }

      // Count rules
      const { count: totalCount } = await supabase
        .from('automation_rules')
        .select('*', { count: 'exact', head: true })
        .or(`user_id.eq.${user.id},is_global.eq.true`);

      const { count: activeCount } = await supabase
        .from('automation_rules')
        .select('*', { count: 'exact', head: true })
        .or(`user_id.eq.${user.id},is_global.eq.true`)
        .eq('is_active', true);

      setStats(prev => ({
        ...prev,
        totalRules: totalCount || 0,
        activeRules: activeCount || 0
      }));
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const toggleRuleStatus = async (rule: AutomationRule) => {
    try {
      const { error } = await supabase
        .from('automation_rules')
        .update({ is_active: !rule.is_active })
        .eq('id', rule.id);

      if (error) throw error;

      toast({
        title: 'Success',
        description: `Rule ${!rule.is_active ? 'activated' : 'deactivated'}`
      });

      fetchRules();
    } catch (error) {
      console.error('Error toggling rule:', error);
      toast({
        title: 'Error',
        description: 'Failed to update rule status',
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Automation Engine</h1>
          <p className="text-muted-foreground mt-1">
            Create powerful IF-THEN automation rules to engage subscribers
          </p>
        </div>
        <Button onClick={() => setIsBuilderOpen(true)} size="lg">
          <Plus className="mr-2 h-4 w-4" />
          Create Automation
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Rules</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalRules}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Rules</CardTitle>
            <Play className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeRules}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Triggers Today</CardTitle>
            <Zap className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.triggersToday}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Actions Executed</CardTitle>
            <Settings className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.actionsExecuted}</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="rules">My Rules</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="logs">Activity Logs</TabsTrigger>
        </TabsList>

        <TabsContent value="rules" className="space-y-4">
          <AutomationList 
            rules={rules}
            onToggleStatus={toggleRuleStatus}
            onEdit={(rule) => {
              setSelectedRule(rule);
              setIsBuilderOpen(true);
            }}
            onRefresh={fetchRules}
          />
        </TabsContent>

        <TabsContent value="templates">
          <AutomationTemplates 
            onUseTemplate={(template) => {
              setSelectedRule(template);
              setIsBuilderOpen(true);
            }}
          />
        </TabsContent>

        <TabsContent value="analytics">
          <AutomationAnalytics rules={rules} />
        </TabsContent>

        <TabsContent value="logs">
          <Card>
            <CardHeader>
              <CardTitle>Activity Logs</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                View detailed logs of automation executions
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Automation Builder Modal */}
      {isBuilderOpen && (
        <AutomationBuilder
          rule={selectedRule}
          onClose={() => {
            setIsBuilderOpen(false);
            setSelectedRule(null);
          }}
          onSave={() => {
            setIsBuilderOpen(false);
            setSelectedRule(null);
            fetchRules();
            fetchStats();
          }}
        />
      )}
    </div>
  );
}