import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronRight, Plus, Sparkles, Clock, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface ContentItem {
  id: string;
  title: string;
  content: string;
  format: string;
  status: string;
  platform: string;
  scheduled_date?: string;
  engagement_rate?: number;
  tags?: string[];
}

interface WorkflowStage {
  name: string;
  items: ContentItem[];
  color: string;
  icon: React.ReactNode;
}

export function ContentWorkflow() {
  const { toast } = useToast();
  const [items, setItems] = useState<ContentItem[]>([]);
  const [draggedItem, setDraggedItem] = useState<ContentItem | null>(null);

  const stages: WorkflowStage[] = [
    { name: 'idea', items: [], color: 'bg-purple-100 text-purple-800', icon: <Sparkles className="h-4 w-4" /> },
    { name: 'draft', items: [], color: 'bg-blue-100 text-blue-800', icon: <Clock className="h-4 w-4" /> },
    { name: 'approved', items: [], color: 'bg-green-100 text-green-800', icon: <TrendingUp className="h-4 w-4" /> },
    { name: 'posted', items: [], color: 'bg-gray-100 text-gray-800', icon: <ChevronRight className="h-4 w-4" /> },
    { name: 'repurpose', items: [], color: 'bg-orange-100 text-orange-800', icon: <Sparkles className="h-4 w-4" /> }
  ];

  // Group items by status
  stages.forEach(stage => {
    stage.items = items.filter(item => item.status === stage.name);
  });

  const handleDragStart = (item: ContentItem) => {
    setDraggedItem(item);
  };

  const handleDrop = async (status: string) => {
    if (!draggedItem) return;

    try {
      const { error } = await supabase
        .from('content_items')
        .update({ status, updated_at: new Date().toISOString() })
        .eq('id', draggedItem.id);

      if (error) throw error;

      setItems(prev => prev.map(item => 
        item.id === draggedItem.id ? { ...item, status } : item
      ));

      toast({
        title: 'Content moved',
        description: `Moved to ${status} stage`
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update content status',
        variant: 'destructive'
      });
    }

    setDraggedItem(null);
  };

  return (
    <div className="grid grid-cols-5 gap-4 h-full">
      {stages.map((stage) => (
        <div
          key={stage.name}
          className="flex flex-col"
          onDragOver={(e) => e.preventDefault()}
          onDrop={() => handleDrop(stage.name)}
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              {stage.icon}
              <h3 className="font-semibold capitalize">{stage.name}</h3>
              <Badge variant="secondary">{stage.items.length}</Badge>
            </div>
            <Button size="icon" variant="ghost">
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex-1 space-y-3 min-h-[400px] p-2 bg-gray-50 rounded-lg">
            {stage.items.map((item) => (
              <Card
                key={item.id}
                draggable
                onDragStart={() => handleDragStart(item)}
                className="p-3 cursor-move hover:shadow-md transition-shadow"
              >
                <h4 className="font-medium text-sm mb-1">{item.title}</h4>
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline" className="text-xs">
                    {item.format}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {item.platform}
                  </Badge>
                </div>
                {item.engagement_rate && (
                  <div className="text-xs text-gray-500">
                    Engagement: {item.engagement_rate}%
                  </div>
                )}
                {item.scheduled_date && (
                  <div className="text-xs text-gray-500">
                    {new Date(item.scheduled_date).toLocaleDateString()}
                  </div>
                )}
              </Card>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}