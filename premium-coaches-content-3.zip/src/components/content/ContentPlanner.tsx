import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar, Sparkles, Download, RefreshCw, TrendingUp, Clock, Target, Hash } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { ContentWorkflow } from './ContentWorkflow';

export function ContentPlanner() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('workflow');
  const [contentItems, setContentItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  const [selectedContent, setSelectedContent] = useState(null);
  const [stats, setStats] = useState({
    total: 0,
    ideas: 0,
    drafts: 0,
    posted: 0,
    avgEngagement: 0
  });

  useEffect(() => {
    fetchContentItems();
    fetchStats();
  }, []);

  const fetchContentItems = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('content_items')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setContentItems(data || []);
    } catch (error) {
      console.error('Error fetching content:', error);
    }
  };

  const fetchStats = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('content_items')
        .select('status, engagement_rate')
        .eq('user_id', user.id);

      if (error) throw error;

      const stats = {
        total: data.length,
        ideas: data.filter(i => i.status === 'idea').length,
        drafts: data.filter(i => i.status === 'draft').length,
        posted: data.filter(i => i.status === 'posted').length,
        avgEngagement: data.reduce((acc, i) => acc + (i.engagement_rate || 0), 0) / data.length || 0
      };

      setStats(stats);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const generateAISuggestions = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('content-ai-operations', {
        body: {
          action: 'suggest-content',
          data: {
            niche: 'business',
            goal: 'engagement',
            recentPosts: contentItems.slice(0, 5).map(i => i.title)
          }
        }
      });

      if (error) throw error;
      setAiSuggestions(data.suggestions || []);
      
      toast({
        title: 'AI Suggestions Generated',
        description: 'Check out these fresh content ideas!'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to generate suggestions',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const repurposeContent = async (contentId: string) => {
    setLoading(true);
    try {
      const content = contentItems.find(i => i.id === contentId);
      if (!content) return;

      const { data, error } = await supabase.functions.invoke('content-ai-operations', {
        body: {
          action: 'repurpose-content',
          data: {
            content: content.content,
            currentFormat: content.format,
            targetFormats: ['reel', 'carousel', 'email']
          }
        }
      });

      if (error) throw error;

      toast({
        title: 'Content Repurposed',
        description: 'Your content has been transformed into multiple formats!'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to repurpose content',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const exportContentPlan = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('content-ai-operations', {
        body: {
          action: 'export-plan',
          data: {
            items: contentItems,
            format: 'csv'
          }
        }
      });

      if (error) throw error;

      // Create download link
      const blob = new Blob([data], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'content-plan.csv';
      a.click();

      toast({
        title: 'Export Successful',
        description: 'Your content plan has been downloaded'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to export content plan',
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Content</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </div>
            <Hash className="h-8 w-8 text-gray-400" />
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Ideas</p>
              <p className="text-2xl font-bold">{stats.ideas}</p>
            </div>
            <Sparkles className="h-8 w-8 text-purple-400" />
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Drafts</p>
              <p className="text-2xl font-bold">{stats.drafts}</p>
            </div>
            <Clock className="h-8 w-8 text-blue-400" />
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Posted</p>
              <p className="text-2xl font-bold">{stats.posted}</p>
            </div>
            <Target className="h-8 w-8 text-green-400" />
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg Engagement</p>
              <p className="text-2xl font-bold">{stats.avgEngagement.toFixed(1)}%</p>
            </div>
            <TrendingUp className="h-8 w-8 text-orange-400" />
          </div>
        </Card>
      </div>

      {/* Action Bar */}
      <div className="flex justify-between items-center">
        <div className="flex gap-2">
          <Button onClick={generateAISuggestions} disabled={loading}>
            <Sparkles className="h-4 w-4 mr-2" />
            AI Suggestions
          </Button>
          <Button variant="outline" onClick={exportContentPlan}>
            <Download className="h-4 w-4 mr-2" />
            Export Plan
          </Button>
        </div>
      </div>

      {/* Main Content Area */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="workflow">Workflow View</TabsTrigger>
          <TabsTrigger value="ai-suggestions">AI Suggestions</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="workflow" className="mt-4">
          <ContentWorkflow />
        </TabsContent>

        <TabsContent value="ai-suggestions" className="mt-4">
          <div className="grid gap-4">
            {aiSuggestions.length > 0 ? (
              aiSuggestions.map((suggestion, index) => (
                <Card key={index} className="p-4">
                  <div className="flex justify-between items-start">
                    <p className="flex-1">{suggestion}</p>
                    <Button size="sm" variant="outline">
                      Use This
                    </Button>
                  </div>
                </Card>
              ))
            ) : (
              <Card className="p-8 text-center">
                <Sparkles className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-600">Click "AI Suggestions" to generate content ideas</p>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="performance" className="mt-4">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Content Performance Analytics</h3>
            <p className="text-gray-600">Performance tracking coming soon...</p>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}