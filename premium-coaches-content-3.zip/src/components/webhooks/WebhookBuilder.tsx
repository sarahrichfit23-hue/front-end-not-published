import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { supabase } from '@/lib/supabase';
import { Plus, X, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

interface WebhookBuilderProps {
  onClose: () => void;
  onSuccess: () => void;
}

export function WebhookBuilder({ onClose, onSuccess }: WebhookBuilderProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [allowedSources, setAllowedSources] = useState<string[]>([]);
  const [newSource, setNewSource] = useState('');
  const [retryAttempts, setRetryAttempts] = useState(3);
  const [timeoutSeconds, setTimeoutSeconds] = useState(30);
  const [mappings, setMappings] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);

  const triggerTypes = [
    { value: 'new_subscriber', label: 'New Subscriber' },
    { value: 'form_submission', label: 'Form Submission' },
    { value: 'payment_received', label: 'Payment Received' },
    { value: 'payment_failed', label: 'Payment Failed' },
    { value: 'subscription_created', label: 'Subscription Created' },
    { value: 'subscription_cancelled', label: 'Subscription Cancelled' },
    { value: 'order_completed', label: 'Order Completed' },
    { value: 'custom_event', label: 'Custom Event' }
  ];

  const addSource = () => {
    if (newSource && !allowedSources.includes(newSource)) {
      setAllowedSources([...allowedSources, newSource]);
      setNewSource('');
    }
  };

  const removeSource = (source: string) => {
    setAllowedSources(allowedSources.filter(s => s !== source));
  };

  const addMapping = () => {
    setMappings([...mappings, {
      id: Date.now(),
      fieldPath: '',
      triggerType: '',
      transformationType: 'none'
    }]);
  };

  const updateMapping = (id: number, field: string, value: any) => {
    setMappings(mappings.map(m => 
      m.id === id ? { ...m, [field]: value } : m
    ));
  };

  const removeMapping = (id: number) => {
    setMappings(mappings.filter(m => m.id !== id));
  };

  const handleSave = async () => {
    if (!name) {
      toast.error('Please enter a webhook name');
      return;
    }

    setSaving(true);

    try {
      // Generate endpoint URL and secret
      const endpointUrl = name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
      const secretKey = Array.from(crypto.getRandomValues(new Uint8Array(32)))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');

      // Create webhook config
      const { data: webhook, error: webhookError } = await supabase
        .from('webhook_configs')
        .insert({
          name,
          description,
          endpoint_url: endpointUrl,
          secret_key: secretKey,
          allowed_sources: allowedSources.length > 0 ? allowedSources : null,
          retry_attempts: retryAttempts,
          timeout_seconds: timeoutSeconds
        })
        .select()
        .single();

      if (webhookError) throw webhookError;

      // Create mappings
      if (mappings.length > 0 && webhook) {
        const mappingData = mappings
          .filter(m => m.fieldPath && m.triggerType)
          .map(m => ({
            webhook_config_id: webhook.id,
            field_path: m.fieldPath,
            automation_trigger_type: m.triggerType,
            transformation_rules: m.transformationType !== 'none' ? {
              type: m.transformationType
            } : {}
          }));

        if (mappingData.length > 0) {
          const { error: mappingError } = await supabase
            .from('webhook_mappings')
            .insert(mappingData);

          if (mappingError) throw mappingError;
        }
      }

      toast.success('Webhook created successfully');
      onSuccess();
    } catch (error: any) {
      toast.error(error.message || 'Failed to create webhook');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Webhook</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Webhook Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Payment Processor"
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Handles payment events from Stripe"
              />
            </div>
          </div>

          <div>
            <Label>Allowed Sources (Optional)</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newSource}
                onChange={(e) => setNewSource(e.target.value)}
                placeholder="stripe.com"
                onKeyPress={(e) => e.key === 'Enter' && addSource()}
              />
              <Button onClick={addSource} size="sm">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {allowedSources.map(source => (
                <Badge key={source} variant="secondary">
                  {source}
                  <button
                    onClick={() => removeSource(source)}
                    className="ml-1 hover:text-red-500"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="retry">Retry Attempts</Label>
              <Input
                id="retry"
                type="number"
                value={retryAttempts}
                onChange={(e) => setRetryAttempts(parseInt(e.target.value))}
                min="0"
                max="10"
              />
            </div>
            <div>
              <Label htmlFor="timeout">Timeout (seconds)</Label>
              <Input
                id="timeout"
                type="number"
                value={timeoutSeconds}
                onChange={(e) => setTimeoutSeconds(parseInt(e.target.value))}
                min="5"
                max="300"
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-3">
              <Label>Field Mappings</Label>
              <Button onClick={addMapping} size="sm" variant="outline">
                <Plus className="h-4 w-4 mr-1" />
                Add Mapping
              </Button>
            </div>

            <div className="space-y-3">
              {mappings.map(mapping => (
                <Card key={mapping.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <Input
                        placeholder="Field path (e.g., data.email)"
                        value={mapping.fieldPath}
                        onChange={(e) => updateMapping(mapping.id, 'fieldPath', e.target.value)}
                        className="flex-1"
                      />
                      <ArrowRight className="h-4 w-4 text-muted-foreground" />
                      <Select
                        value={mapping.triggerType}
                        onValueChange={(value) => updateMapping(mapping.id, 'triggerType', value)}
                      >
                        <SelectTrigger className="w-[200px]">
                          <SelectValue placeholder="Trigger type" />
                        </SelectTrigger>
                        <SelectContent>
                          {triggerTypes.map(type => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => removeMapping(mapping.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={saving}>
              {saving ? 'Creating...' : 'Create Webhook'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}