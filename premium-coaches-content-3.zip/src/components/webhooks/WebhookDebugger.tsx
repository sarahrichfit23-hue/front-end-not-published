import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { Send, Copy, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export function WebhookDebugger() {
  const [webhooks, setWebhooks] = useState<any[]>([]);
  const [selectedWebhook, setSelectedWebhook] = useState('');
  const [testPayload, setTestPayload] = useState('{\n  "event": "test",\n  "data": {\n    "email": "test@example.com",\n    "name": "Test User"\n  }\n}');
  const [customHeaders, setCustomHeaders] = useState('{\n  "X-Test-Header": "test-value"\n}');
  const [includeSignature, setIncludeSignature] = useState(true);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [recentTests, setRecentTests] = useState<any[]>([]);

  useEffect(() => {
    loadWebhooks();
    loadRecentTests();
  }, []);

  const loadWebhooks = async () => {
    const { data } = await supabase
      .from('webhook_configs')
      .select('*')
      .eq('is_active', true);
    
    if (data) {
      setWebhooks(data);
      if (data.length > 0) {
        setSelectedWebhook(data[0].id);
      }
    }
  };

  const loadRecentTests = async () => {
    const { data } = await supabase
      .from('webhook_test_logs')
      .select(`
        *,
        webhook_configs!inner(name)
      `)
      .order('created_at', { ascending: false })
      .limit(5);
    
    if (data) setRecentTests(data);
  };

  const testWebhook = async () => {
    if (!selectedWebhook) {
      toast.error('Please select a webhook');
      return;
    }

    try {
      const payload = JSON.parse(testPayload);
      const headers = JSON.parse(customHeaders);
    } catch (error) {
      toast.error('Invalid JSON in payload or headers');
      return;
    }

    setTesting(true);
    setTestResult(null);

    try {
      const webhook = webhooks.find(w => w.id === selectedWebhook);
      if (!webhook) return;

      const payload = JSON.parse(testPayload);
      const headers = JSON.parse(customHeaders);

      // Generate signature if needed
      let signature = '';
      if (includeSignature && webhook.secret_key) {
        const encoder = new TextEncoder();
        const key = await crypto.subtle.importKey(
          'raw',
          encoder.encode(webhook.secret_key),
          { name: 'HMAC', hash: 'SHA-256' },
          false,
          ['sign']
        );
        
        const signatureBuffer = await crypto.subtle.sign(
          'HMAC',
          key,
          encoder.encode(testPayload)
        );
        
        signature = Array.from(new Uint8Array(signatureBuffer))
          .map(b => b.toString(16).padStart(2, '0'))
          .join('');
      }

      // Call the webhook endpoint
      const response = await fetch(`/api/webhooks/${webhook.endpoint_url}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(signature && { 'X-Webhook-Signature': signature }),
          'X-Webhook-Id': `test-${Date.now()}`,
          ...headers
        },
        body: testPayload
      });

      const responseData = await response.json();

      const result = {
        success: response.ok,
        status: response.status,
        response: responseData,
        timestamp: new Date().toISOString()
      };

      setTestResult(result);

      // Log test result
      await supabase
        .from('webhook_test_logs')
        .insert({
          webhook_config_id: selectedWebhook,
          test_payload: payload,
          response: responseData,
          success: response.ok,
          error_message: !response.ok ? responseData.error : null
        });

      loadRecentTests();

      if (response.ok) {
        toast.success('Webhook test successful');
      } else {
        toast.error('Webhook test failed');
      }
    } catch (error: any) {
      setTestResult({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      });
      toast.error('Test failed: ' + error.message);
    } finally {
      setTesting(false);
    }
  };

  const copyEndpoint = () => {
    const webhook = webhooks.find(w => w.id === selectedWebhook);
    if (webhook) {
      const url = `${window.location.origin}/api/webhooks/${webhook.endpoint_url}`;
      navigator.clipboard.writeText(url);
      toast.success('Endpoint copied to clipboard');
    }
  };

  const loadSamplePayload = (type: string) => {
    const samples: Record<string, string> = {
      stripe: JSON.stringify({
        type: 'payment_intent.succeeded',
        data: {
          object: {
            id: 'pi_1234567890',
            amount: 2000,
            currency: 'usd',
            customer: 'cus_1234567890',
            metadata: {
              order_id: '12345'
            }
          }
        }
      }, null, 2),
      form: JSON.stringify({
        event: 'form_submission',
        form_id: 'contact-form',
        data: {
          name: 'John Doe',
          email: 'john@example.com',
          message: 'Hello, I would like to learn more.'
        },
        submitted_at: new Date().toISOString()
      }, null, 2),
      crm: JSON.stringify({
        event: 'contact.created',
        contact: {
          id: '12345',
          email: 'jane@example.com',
          first_name: 'Jane',
          last_name: 'Smith',
          tags: ['lead', 'newsletter']
        }
      }, null, 2)
    };

    setTestPayload(samples[type] || samples.form);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Test Webhook</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="webhook">Select Webhook</Label>
              <Select value={selectedWebhook} onValueChange={setSelectedWebhook}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a webhook" />
                </SelectTrigger>
                <SelectContent>
                  {webhooks.map(webhook => (
                    <SelectItem key={webhook.id} value={webhook.id}>
                      {webhook.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedWebhook && (
              <div className="p-3 bg-muted rounded-lg">
                <div className="flex items-center justify-between">
                  <code className="text-xs">
                    {window.location.origin}/api/webhooks/
                    {webhooks.find(w => w.id === selectedWebhook)?.endpoint_url}
                  </code>
                  <Button size="sm" variant="ghost" onClick={copyEndpoint}>
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            )}

            <div>
              <div className="flex justify-between items-center mb-2">
                <Label htmlFor="payload">Test Payload</Label>
                <div className="flex gap-1">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => loadSamplePayload('stripe')}
                  >
                    Stripe
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => loadSamplePayload('form')}
                  >
                    Form
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => loadSamplePayload('crm')}
                  >
                    CRM
                  </Button>
                </div>
              </div>
              <Textarea
                id="payload"
                value={testPayload}
                onChange={(e) => setTestPayload(e.target.value)}
                className="font-mono text-sm"
                rows={10}
              />
            </div>

            <div>
              <Label htmlFor="headers">Custom Headers (Optional)</Label>
              <Textarea
                id="headers"
                value={customHeaders}
                onChange={(e) => setCustomHeaders(e.target.value)}
                className="font-mono text-sm"
                rows={3}
              />
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="signature"
                checked={includeSignature}
                onChange={(e) => setIncludeSignature(e.target.checked)}
                className="rounded"
              />
              <Label htmlFor="signature" className="cursor-pointer">
                Include signature header
              </Label>
            </div>

            <Button 
              onClick={testWebhook} 
              disabled={testing || !selectedWebhook}
              className="w-full"
            >
              {testing ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Testing...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Send Test Webhook
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {testResult && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                Test Result
                {testResult.success ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-500" />
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <div className="text-sm font-medium mb-1">Status</div>
                  <Badge variant={testResult.success ? 'outline' : 'destructive'}>
                    {testResult.status || 'Error'}
                  </Badge>
                </div>
                <div>
                  <div className="text-sm font-medium mb-1">Response</div>
                  <pre className="bg-muted p-3 rounded text-xs overflow-x-auto">
                    {JSON.stringify(testResult.response || testResult.error, null, 2)}
                  </pre>
                </div>
                <div className="text-xs text-muted-foreground">
                  {testResult.timestamp}
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <div>
        <Card>
          <CardHeader>
            <CardTitle>Recent Tests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentTests.map(test => (
                <div key={test.id} className="border rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-sm">
                      {test.webhook_configs?.name}
                    </span>
                    {test.success ? (
                      <CheckCircle className="h-4 w-4 text-green-500" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-500" />
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(test.created_at).toLocaleString()}
                  </div>
                  {test.error_message && (
                    <div className="mt-2 text-xs text-red-600">
                      {test.error_message}
                    </div>
                  )}
                </div>
              ))}

              {recentTests.length === 0 && (
                <div className="text-center py-4 text-muted-foreground">
                  No test logs yet
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}