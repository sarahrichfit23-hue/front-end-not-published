import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase';
import { Plus, Webhook, Activity, AlertCircle, CheckCircle } from 'lucide-react';
import { WebhookList } from './WebhookList';
import { WebhookBuilder } from './WebhookBuilder';
import { WebhookLogs } from './WebhookLogs';
import { WebhookDebugger } from './WebhookDebugger';

export function WebhookDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [showBuilder, setShowBuilder] = useState(false);
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    successful: 0,
    failed: 0,
    pending: 0
  });

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    const { data: configs } = await supabase
      .from('webhook_configs')
      .select('is_active');

    const { data: logs } = await supabase
      .from('webhook_logs')
      .select('status')
      .gte('created_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString());

    if (configs) {
      setStats({
        total: configs.length,
        active: configs.filter(c => c.is_active).length,
        successful: logs?.filter(l => l.status === 'success').length || 0,
        failed: logs?.filter(l => l.status === 'failed').length || 0,
        pending: logs?.filter(l => l.status === 'pending' || l.status === 'retrying').length || 0
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Webhook Management</h2>
          <p className="text-muted-foreground">Configure and monitor webhook integrations</p>
        </div>
        <Button onClick={() => setShowBuilder(true)}>
          <Plus className="h-4 w-4 mr-2" />
          New Webhook
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Webhooks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
            <Badge variant="secondary" className="mt-2">
              <Webhook className="h-3 w-3 mr-1" />
              {stats.active} active
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Successful (24h)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.successful}</div>
            <Badge variant="outline" className="mt-2 border-green-600 text-green-600">
              <CheckCircle className="h-3 w-3 mr-1" />
              Success
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Failed (24h)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.failed}</div>
            <Badge variant="outline" className="mt-2 border-red-600 text-red-600">
              <AlertCircle className="h-3 w-3 mr-1" />
              Failed
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
            <Badge variant="outline" className="mt-2 border-yellow-600 text-yellow-600">
              <Activity className="h-3 w-3 mr-1" />
              Processing
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats.successful + stats.failed > 0
                ? Math.round((stats.successful / (stats.successful + stats.failed)) * 100)
                : 0}%
            </div>
            <div className="mt-2 h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-green-600"
                style={{
                  width: `${stats.successful + stats.failed > 0
                    ? (stats.successful / (stats.successful + stats.failed)) * 100
                    : 0}%`
                }}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Webhooks</TabsTrigger>
          <TabsTrigger value="logs">Logs</TabsTrigger>
          <TabsTrigger value="debugger">Debugger</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <WebhookList onRefresh={loadStats} />
        </TabsContent>

        <TabsContent value="logs" className="space-y-4">
          <WebhookLogs />
        </TabsContent>

        <TabsContent value="debugger" className="space-y-4">
          <WebhookDebugger />
        </TabsContent>
      </Tabs>

      {showBuilder && (
        <WebhookBuilder
          onClose={() => setShowBuilder(false)}
          onSuccess={() => {
            setShowBuilder(false);
            loadStats();
          }}
        />
      )}
    </div>
  );
}