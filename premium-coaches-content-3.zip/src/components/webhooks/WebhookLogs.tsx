import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/lib/supabase';
import { 
  Search, Filter, RefreshCw, ChevronDown, ChevronUp,
  Clock, CheckCircle, XCircle, AlertCircle
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

export function WebhookLogs() {
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedLogs, setExpandedLogs] = useState<Set<string>>(new Set());
  const [filters, setFilters] = useState({
    status: 'all',
    webhook: 'all',
    search: ''
  });
  const [webhooks, setWebhooks] = useState<any[]>([]);

  useEffect(() => {
    loadWebhooks();
    loadLogs();
  }, [filters]);

  const loadWebhooks = async () => {
    const { data } = await supabase
      .from('webhook_configs')
      .select('id, name');
    
    if (data) setWebhooks(data);
  };

  const loadLogs = async () => {
    setLoading(true);
    
    let query = supabase
      .from('webhook_logs')
      .select(`
        *,
        webhook_configs!inner(name)
      `)
      .order('created_at', { ascending: false })
      .limit(100);

    if (filters.status !== 'all') {
      query = query.eq('status', filters.status);
    }

    if (filters.webhook !== 'all') {
      query = query.eq('webhook_config_id', filters.webhook);
    }

    if (filters.search) {
      query = query.or(`request_id.ilike.%${filters.search}%,source_ip.ilike.%${filters.search}%`);
    }

    const { data, error } = await query;

    if (data) {
      setLogs(data);
    }
    setLoading(false);
  };

  const toggleLogExpansion = (id: string) => {
    const newExpanded = new Set(expandedLogs);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedLogs(newExpanded);
  };

  const retryWebhook = async (logId: string) => {
    const log = logs.find(l => l.id === logId);
    if (!log) return;

    const { error } = await supabase
      .from('webhook_retry_queue')
      .insert({
        webhook_log_id: logId,
        webhook_config_id: log.webhook_config_id,
        payload: log.payload,
        next_retry_at: new Date().toISOString()
      });

    if (!error) {
      toast.success('Webhook queued for retry');
      loadLogs();
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'retrying':
        return <RefreshCw className="h-4 w-4 text-yellow-500 animate-spin" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, any> = {
      success: 'outline',
      failed: 'destructive',
      pending: 'secondary',
      processing: 'secondary',
      retrying: 'secondary'
    };

    return (
      <Badge variant={variants[status] || 'secondary'}>
        {status}
      </Badge>
    );
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Webhook Logs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-3 mb-4">
            <div className="flex-1">
              <Input
                placeholder="Search by request ID or IP..."
                value={filters.search}
                onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                className="w-full"
              />
            </div>
            <Select
              value={filters.status}
              onValueChange={(value) => setFilters({ ...filters, status: value })}
            >
              <SelectTrigger className="w-[150px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="success">Success</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="retrying">Retrying</SelectItem>
              </SelectContent>
            </Select>
            <Select
              value={filters.webhook}
              onValueChange={(value) => setFilters({ ...filters, webhook: value })}
            >
              <SelectTrigger className="w-[200px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Webhooks</SelectItem>
                {webhooks.map(webhook => (
                  <SelectItem key={webhook.id} value={webhook.id}>
                    {webhook.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={loadLogs} variant="outline">
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-2">
            {logs.map(log => (
              <div key={log.id} className="border rounded-lg p-4">
                <div 
                  className="flex items-center justify-between cursor-pointer"
                  onClick={() => toggleLogExpansion(log.id)}
                >
                  <div className="flex items-center gap-3">
                    {getStatusIcon(log.status)}
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">
                          {log.webhook_configs?.name}
                        </span>
                        {getStatusBadge(log.status)}
                        {log.retry_count > 0 && (
                          <Badge variant="outline">
                            Retry {log.retry_count}
                          </Badge>
                        )}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {format(new Date(log.created_at), 'MMM d, yyyy HH:mm:ss')}
                        {log.processing_time_ms && (
                          <span className="ml-2">• {log.processing_time_ms}ms</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {log.status === 'failed' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          retryWebhook(log.id);
                        }}
                      >
                        <RefreshCw className="h-3 w-3 mr-1" />
                        Retry
                      </Button>
                    )}
                    {expandedLogs.has(log.id) ? 
                      <ChevronUp className="h-4 w-4" /> : 
                      <ChevronDown className="h-4 w-4" />
                    }
                  </div>
                </div>

                {expandedLogs.has(log.id) && (
                  <div className="mt-4 space-y-3">
                    <div>
                      <div className="text-sm font-medium mb-1">Request Details</div>
                      <div className="bg-muted p-3 rounded text-sm space-y-1">
                        <div>ID: {log.request_id}</div>
                        <div>IP: {log.source_ip}</div>
                        <div>Method: {log.method}</div>
                        {log.response_status && (
                          <div>Response Status: {log.response_status}</div>
                        )}
                      </div>
                    </div>

                    {log.payload && (
                      <div>
                        <div className="text-sm font-medium mb-1">Payload</div>
                        <pre className="bg-muted p-3 rounded text-xs overflow-x-auto">
                          {JSON.stringify(log.payload, null, 2)}
                        </pre>
                      </div>
                    )}

                    {log.error_message && (
                      <div>
                        <div className="text-sm font-medium mb-1">Error</div>
                        <div className="bg-red-50 text-red-600 p-3 rounded text-sm">
                          {log.error_message}
                        </div>
                      </div>
                    )}

                    {log.response_body && (
                      <div>
                        <div className="text-sm font-medium mb-1">Response</div>
                        <pre className="bg-muted p-3 rounded text-xs overflow-x-auto">
                          {JSON.stringify(log.response_body, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>

          {logs.length === 0 && !loading && (
            <div className="text-center py-8 text-muted-foreground">
              No webhook logs found
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}