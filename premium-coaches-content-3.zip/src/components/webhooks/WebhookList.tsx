import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/lib/supabase';
import { 
  Copy, Edit, Trash2, ExternalLink, Shield, RefreshCw,
  MoreVertical, Eye, EyeOff
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

interface WebhookListProps {
  onRefresh: () => void;
}

export function WebhookList({ onRefresh }: WebhookListProps) {
  const [webhooks, setWebhooks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});

  useEffect(() => {
    loadWebhooks();
  }, []);

  const loadWebhooks = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('webhook_configs')
      .select(`
        *,
        webhook_mappings(count),
        webhook_logs!inner(
          status,
          created_at
        )
      `)
      .order('created_at', { ascending: false });

    if (data) {
      setWebhooks(data);
    }
    setLoading(false);
  };

  const toggleWebhook = async (id: string, isActive: boolean) => {
    const { error } = await supabase
      .from('webhook_configs')
      .update({ is_active: !isActive })
      .eq('id', id);

    if (!error) {
      toast.success(`Webhook ${!isActive ? 'activated' : 'deactivated'}`);
      loadWebhooks();
      onRefresh();
    }
  };

  const deleteWebhook = async (id: string) => {
    if (!confirm('Are you sure you want to delete this webhook?')) return;

    const { error } = await supabase
      .from('webhook_configs')
      .delete()
      .eq('id', id);

    if (!error) {
      toast.success('Webhook deleted');
      loadWebhooks();
      onRefresh();
    }
  };

  const copyEndpoint = (endpoint: string) => {
    const fullUrl = `${window.location.origin}/api/webhooks/${endpoint}`;
    navigator.clipboard.writeText(fullUrl);
    toast.success('Endpoint URL copied to clipboard');
  };

  const regenerateSecret = async (id: string) => {
    const newSecret = Array.from(crypto.getRandomValues(new Uint8Array(32)))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');

    const { error } = await supabase
      .from('webhook_configs')
      .update({ secret_key: newSecret })
      .eq('id', id);

    if (!error) {
      toast.success('Secret key regenerated');
      loadWebhooks();
    }
  };

  const getRecentStatus = (logs: any[]) => {
    if (!logs || logs.length === 0) return null;
    const recent = logs.sort((a, b) => 
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    )[0];
    return recent.status;
  };

  if (loading) {
    return <div>Loading webhooks...</div>;
  }

  return (
    <div className="space-y-4">
      {webhooks.map((webhook) => {
        const recentStatus = getRecentStatus(webhook.webhook_logs);
        
        return (
          <Card key={webhook.id}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-semibold text-lg">{webhook.name}</h3>
                    <Badge variant={webhook.is_active ? 'default' : 'secondary'}>
                      {webhook.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                    {recentStatus && (
                      <Badge 
                        variant={
                          recentStatus === 'success' ? 'outline' :
                          recentStatus === 'failed' ? 'destructive' :
                          'secondary'
                        }
                      >
                        Last: {recentStatus}
                      </Badge>
                    )}
                  </div>
                  
                  {webhook.description && (
                    <p className="text-sm text-muted-foreground mb-3">
                      {webhook.description}
                    </p>
                  )}

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">Endpoint:</span>
                      <code className="text-xs bg-muted px-2 py-1 rounded">
                        /api/webhooks/{webhook.endpoint_url}
                      </code>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyEndpoint(webhook.endpoint_url)}
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">Secret:</span>
                      <code className="text-xs bg-muted px-2 py-1 rounded">
                        {showSecrets[webhook.id] 
                          ? webhook.secret_key 
                          : '••••••••••••••••'}
                      </code>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setShowSecrets(prev => ({
                          ...prev,
                          [webhook.id]: !prev[webhook.id]
                        }))}
                      >
                        {showSecrets[webhook.id] ? 
                          <EyeOff className="h-3 w-3" /> : 
                          <Eye className="h-3 w-3" />
                        }
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => regenerateSecret(webhook.id)}
                      >
                        <RefreshCw className="h-3 w-3" />
                      </Button>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>{webhook.webhook_mappings?.[0]?.count || 0} mappings</span>
                      <span>•</span>
                      <span>{webhook.retry_attempts} retries</span>
                      <span>•</span>
                      <span>{webhook.timeout_seconds}s timeout</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Switch
                    checked={webhook.is_active}
                    onCheckedChange={() => toggleWebhook(webhook.id, webhook.is_active)}
                  />
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Edit className="h-4 w-4 mr-2" />
                        Edit Configuration
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Shield className="h-4 w-4 mr-2" />
                        Manage Mappings
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Test Webhook
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-red-600"
                        onClick={() => deleteWebhook(webhook.id)}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}

      {webhooks.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <p className="text-muted-foreground">No webhooks configured yet</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}