import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface WorkflowNodeEditorProps {
  node: any;
  onClose: () => void;
  onSave: (node: any) => void;
}

const WorkflowNodeEditor: React.FC<WorkflowNodeEditorProps> = ({ node, onClose, onSave }) => {
  const [nodeData, setNodeData] = useState({
    label: node.label || '',
    config: node.config || {}
  });

  const handleSave = () => {
    onSave({
      ...node,
      label: nodeData.label,
      config: nodeData.config
    });
  };

  const updateConfig = (key: string, value: any) => {
    setNodeData({
      ...nodeData,
      config: {
        ...nodeData.config,
        [key]: value
      }
    });
  };

  const renderConfigFields = () => {
    switch (node.type) {
      case 'trigger':
        return (
          <>
            <div className="space-y-2">
              <Label>Trigger Type</Label>
              <Select 
                value={nodeData.config.trigger_type || 'signup'} 
                onValueChange={(v) => updateConfig('trigger_type', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="signup">New Signup</SelectItem>
                  <SelectItem value="abandoned_cart">Abandoned Cart</SelectItem>
                  <SelectItem value="purchase">Purchase Made</SelectItem>
                  <SelectItem value="tag_added">Tag Added</SelectItem>
                  <SelectItem value="date_based">Date Based</SelectItem>
                  <SelectItem value="re_engagement">Re-engagement</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </>
        );
      
      case 'email':
        return (
          <>
            <div className="space-y-2">
              <Label>Subject Line</Label>
              <Input
                value={nodeData.config.subject || ''}
                onChange={(e) => updateConfig('subject', e.target.value)}
                placeholder="Enter email subject"
              />
            </div>
            <div className="space-y-2">
              <Label>From Email</Label>
              <Input
                type="email"
                value={nodeData.config.from_email || ''}
                onChange={(e) => updateConfig('from_email', e.target.value)}
                placeholder="sender@example.com"
              />
            </div>
            <div className="space-y-2">
              <Label>Email Content</Label>
              <Textarea
                value={nodeData.config.content || ''}
                onChange={(e) => updateConfig('content', e.target.value)}
                placeholder="Enter email HTML content"
                rows={6}
              />
            </div>
          </>
        );
      
      case 'delay':
        return (
          <>
            <div className="space-y-2">
              <Label>Delay Duration</Label>
              <div className="flex gap-2">
                <Input
                  type="number"
                  value={nodeData.config.delay || 1}
                  onChange={(e) => updateConfig('delay', parseInt(e.target.value))}
                  min="1"
                />
                <Select 
                  value={nodeData.config.delay_unit || 'hours'} 
                  onValueChange={(v) => updateConfig('delay_unit', v)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="minutes">Minutes</SelectItem>
                    <SelectItem value="hours">Hours</SelectItem>
                    <SelectItem value="days">Days</SelectItem>
                    <SelectItem value="weeks">Weeks</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </>
        );
      
      case 'condition':
        return (
          <>
            <div className="space-y-2">
              <Label>Condition Type</Label>
              <Select 
                value={nodeData.config.condition_type || 'email_opened'} 
                onValueChange={(v) => updateConfig('condition_type', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="email_opened">Email Opened</SelectItem>
                  <SelectItem value="email_clicked">Link Clicked</SelectItem>
                  <SelectItem value="tag_exists">Has Tag</SelectItem>
                  <SelectItem value="purchase_made">Made Purchase</SelectItem>
                  <SelectItem value="custom">Custom Condition</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {nodeData.config.condition_type === 'custom' && (
              <div className="space-y-2">
                <Label>Custom Condition</Label>
                <Textarea
                  value={nodeData.config.custom_condition || ''}
                  onChange={(e) => updateConfig('custom_condition', e.target.value)}
                  placeholder="Enter custom condition logic"
                  rows={3}
                />
              </div>
            )}
          </>
        );
      
      case 'action':
        return (
          <>
            <div className="space-y-2">
              <Label>Action Type</Label>
              <Select 
                value={nodeData.config.action_type || 'add_tag'} 
                onValueChange={(v) => updateConfig('action_type', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="add_tag">Add Tag</SelectItem>
                  <SelectItem value="remove_tag">Remove Tag</SelectItem>
                  <SelectItem value="update_field">Update Field</SelectItem>
                  <SelectItem value="webhook">Call Webhook</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {(nodeData.config.action_type === 'add_tag' || nodeData.config.action_type === 'remove_tag') && (
              <div className="space-y-2">
                <Label>Tag Name</Label>
                <Input
                  value={nodeData.config.tag || ''}
                  onChange={(e) => updateConfig('tag', e.target.value)}
                  placeholder="Enter tag name"
                />
              </div>
            )}
          </>
        );
      
      default:
        return null;
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Edit {node.type} Node</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Node Label</Label>
            <Input
              value={nodeData.label}
              onChange={(e) => setNodeData({...nodeData, label: e.target.value})}
              placeholder="Enter node label"
            />
          </div>
          
          {renderConfigFields()}
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default WorkflowNodeEditor;