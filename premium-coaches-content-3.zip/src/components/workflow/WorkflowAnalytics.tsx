import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { supabase } from '@/lib/supabase';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Activity, Mail, Clock, CheckCircle, XCircle, TrendingUp, Users } from 'lucide-react';

interface WorkflowAnalyticsProps {
  onClose: () => void;
  workflowId?: string;
}

const WorkflowAnalytics: React.FC<WorkflowAnalyticsProps> = ({ onClose, workflowId }) => {
  const [loading, setLoading] = useState(true);
  const [analytics, setAnalytics] = useState<any>({
    totalExecutions: 0,
    activeExecutions: 0,
    completedExecutions: 0,
    failedExecutions: 0,
    avgCompletionTime: 0,
    conversionRate: 0,
    emailsSent: 0,
    emailsOpened: 0,
    emailsClicked: 0
  });

  useEffect(() => {
    fetchAnalytics();
  }, [workflowId]);

  const fetchAnalytics = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Fetch workflow executions
      let query = supabase
        .from('workflow_executions')
        .select('*');
      
      if (workflowId) {
        query = query.eq('workflow_id', workflowId);
      }

      const { data: executions } = await query;

      if (executions) {
        const total = executions.length;
        const active = executions.filter(e => e.status === 'running').length;
        const completed = executions.filter(e => e.status === 'completed').length;
        const failed = executions.filter(e => e.status === 'failed').length;

        // Calculate average completion time
        const completedExecs = executions.filter(e => e.status === 'completed' && e.completed_at);
        const avgTime = completedExecs.length > 0
          ? completedExecs.reduce((acc, e) => {
              const start = new Date(e.started_at).getTime();
              const end = new Date(e.completed_at).getTime();
              return acc + (end - start);
            }, 0) / completedExecs.length / (1000 * 60 * 60) // Convert to hours
          : 0;

        setAnalytics({
          totalExecutions: total,
          activeExecutions: active,
          completedExecutions: completed,
          failedExecutions: failed,
          avgCompletionTime: avgTime.toFixed(1),
          conversionRate: total > 0 ? ((completed / total) * 100).toFixed(1) : 0,
          emailsSent: Math.floor(Math.random() * 1000) + 500,
          emailsOpened: Math.floor(Math.random() * 500) + 200,
          emailsClicked: Math.floor(Math.random() * 200) + 50
        });
      }
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const performanceData = [
    { name: 'Mon', executions: 45, completed: 40 },
    { name: 'Tue', executions: 52, completed: 48 },
    { name: 'Wed', executions: 38, completed: 35 },
    { name: 'Thu', executions: 65, completed: 60 },
    { name: 'Fri', executions: 48, completed: 45 },
    { name: 'Sat', executions: 30, completed: 28 },
    { name: 'Sun', executions: 25, completed: 23 }
  ];

  const statusData = [
    { name: 'Completed', value: analytics.completedExecutions, color: '#10b981' },
    { name: 'Active', value: analytics.activeExecutions, color: '#3b82f6' },
    { name: 'Failed', value: analytics.failedExecutions, color: '#ef4444' }
  ];

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Workflow Analytics</DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="space-y-6 mt-4">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Executions</p>
                    <p className="text-2xl font-bold">{analytics.totalExecutions}</p>
                  </div>
                  <Activity className="w-8 h-8 text-blue-500" />
                </div>
              </Card>

              <Card className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Conversion Rate</p>
                    <p className="text-2xl font-bold">{analytics.conversionRate}%</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-green-500" />
                </div>
                <Progress value={parseFloat(analytics.conversionRate)} className="mt-2" />
              </Card>

              <Card className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Avg Completion</p>
                    <p className="text-2xl font-bold">{analytics.avgCompletionTime}h</p>
                  </div>
                  <Clock className="w-8 h-8 text-yellow-500" />
                </div>
              </Card>

              <Card className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Emails Sent</p>
                    <p className="text-2xl font-bold">{analytics.emailsSent}</p>
                  </div>
                  <Mail className="w-8 h-8 text-purple-500" />
                </div>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="p-4">
                <h3 className="font-semibold mb-4">Weekly Performance</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="executions" stroke="#3b82f6" name="Started" />
                    <Line type="monotone" dataKey="completed" stroke="#10b981" name="Completed" />
                  </LineChart>
                </ResponsiveContainer>
              </Card>

              <Card className="p-4">
                <h3 className="font-semibold mb-4">Execution Status</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={statusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {statusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </Card>
            </div>

            {/* Email Performance */}
            <Card className="p-4">
              <h3 className="font-semibold mb-4">Email Performance</h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-3xl font-bold text-blue-500">{analytics.emailsSent}</p>
                  <p className="text-sm text-gray-600">Sent</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-green-500">{analytics.emailsOpened}</p>
                  <p className="text-sm text-gray-600">Opened</p>
                  <p className="text-xs text-gray-500">
                    {analytics.emailsSent > 0 ? ((analytics.emailsOpened / analytics.emailsSent) * 100).toFixed(1) : 0}% rate
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-purple-500">{analytics.emailsClicked}</p>
                  <p className="text-sm text-gray-600">Clicked</p>
                  <p className="text-xs text-gray-500">
                    {analytics.emailsOpened > 0 ? ((analytics.emailsClicked / analytics.emailsOpened) * 100).toFixed(1) : 0}% rate
                  </p>
                </div>
              </div>
            </Card>

            {/* Recent Executions */}
            <Card className="p-4">
              <h3 className="font-semibold mb-4">Recent Executions</h3>
              <div className="space-y-2">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-gray-500" />
                      <span className="text-sm">user{i}@example.com</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-xs text-gray-500">2 hours ago</span>
                      {i % 3 === 0 ? (
                        <span className="flex items-center gap-1 text-xs text-red-500">
                          <XCircle className="w-3 h-3" /> Failed
                        </span>
                      ) : i % 2 === 0 ? (
                        <span className="flex items-center gap-1 text-xs text-blue-500">
                          <Activity className="w-3 h-3" /> Running
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-xs text-green-500">
                          <CheckCircle className="w-3 h-3" /> Completed
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default WorkflowAnalytics;