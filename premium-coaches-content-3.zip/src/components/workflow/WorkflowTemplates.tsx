import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Mail, ShoppingCart, UserPlus, RefreshCw, Gift } from 'lucide-react';

interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  nodes: any[];
  edges: any[];
  icon: React.ReactNode;
}

const templates: WorkflowTemplate[] = [
  {
    id: 'welcome-series',
    name: 'Welcome Series',
    description: '5-email welcome sequence for new subscribers',
    category: 'Onboarding',
    icon: <UserPlus className="w-5 h-5" />,
    nodes: [
      { id: 'trigger_1', type: 'trigger', position: { x: 100, y: 100 }, data: { label: 'New Signup', config: { trigger_type: 'signup' } } },
      { id: 'email_1', type: 'email', position: { x: 300, y: 100 }, data: { label: 'Welcome Email', config: { subject: 'Welcome!' } } },
      { id: 'delay_1', type: 'delay', position: { x: 500, y: 100 }, data: { label: 'Wait 1 Day', config: { delay: 1, delay_unit: 'days' } } },
      { id: 'email_2', type: 'email', position: { x: 700, y: 100 }, data: { label: 'Getting Started', config: { subject: 'Getting Started Guide' } } },
      { id: 'delay_2', type: 'delay', position: { x: 900, y: 100 }, data: { label: 'Wait 3 Days', config: { delay: 3, delay_unit: 'days' } } },
      { id: 'email_3', type: 'email', position: { x: 1100, y: 100 }, data: { label: 'Tips & Tricks', config: { subject: 'Pro Tips' } } },
    ],
    edges: [
      { id: 'e1', source: 'trigger_1', target: 'email_1' },
      { id: 'e2', source: 'email_1', target: 'delay_1' },
      { id: 'e3', source: 'delay_1', target: 'email_2' },
      { id: 'e4', source: 'email_2', target: 'delay_2' },
      { id: 'e5', source: 'delay_2', target: 'email_3' },
    ]
  },
  {
    id: 'abandoned-cart',
    name: 'Abandoned Cart Recovery',
    description: '3-email sequence to recover abandoned carts',
    category: 'Sales',
    icon: <ShoppingCart className="w-5 h-5" />,
    nodes: [
      { id: 'trigger_1', type: 'trigger', position: { x: 100, y: 100 }, data: { label: 'Cart Abandoned', config: { trigger_type: 'abandoned_cart' } } },
      { id: 'delay_1', type: 'delay', position: { x: 300, y: 100 }, data: { label: 'Wait 1 Hour', config: { delay: 1, delay_unit: 'hours' } } },
      { id: 'email_1', type: 'email', position: { x: 500, y: 100 }, data: { label: 'Reminder', config: { subject: 'You left something behind!' } } },
      { id: 'condition_1', type: 'condition', position: { x: 700, y: 100 }, data: { label: 'Check Purchase', config: { condition_type: 'purchase_made' } } },
      { id: 'delay_2', type: 'delay', position: { x: 900, y: 50 }, data: { label: 'Wait 24 Hours', config: { delay: 24, delay_unit: 'hours' } } },
      { id: 'email_2', type: 'email', position: { x: 1100, y: 50 }, data: { label: '10% Discount', config: { subject: 'Special offer just for you' } } },
    ],
    edges: [
      { id: 'e1', source: 'trigger_1', target: 'delay_1' },
      { id: 'e2', source: 'delay_1', target: 'email_1' },
      { id: 'e3', source: 'email_1', target: 'condition_1' },
      { id: 'e4', source: 'condition_1', target: 'delay_2' },
      { id: 'e5', source: 'delay_2', target: 'email_2' },
    ]
  },
  {
    id: 're-engagement',
    name: 'Re-engagement Campaign',
    description: 'Win back inactive subscribers',
    category: 'Retention',
    icon: <RefreshCw className="w-5 h-5" />,
    nodes: [
      { id: 'trigger_1', type: 'trigger', position: { x: 100, y: 100 }, data: { label: 'Inactive 30 Days', config: { trigger_type: 're_engagement' } } },
      { id: 'email_1', type: 'email', position: { x: 300, y: 100 }, data: { label: 'We Miss You', config: { subject: 'We miss you!' } } },
      { id: 'delay_1', type: 'delay', position: { x: 500, y: 100 }, data: { label: 'Wait 7 Days', config: { delay: 7, delay_unit: 'days' } } },
      { id: 'condition_1', type: 'condition', position: { x: 700, y: 100 }, data: { label: 'Check Activity', config: { condition_type: 'email_opened' } } },
      { id: 'email_2', type: 'email', position: { x: 900, y: 50 }, data: { label: 'Special Offer', config: { subject: 'Exclusive offer inside' } } },
      { id: 'action_1', type: 'action', position: { x: 900, y: 150 }, data: { label: 'Add Inactive Tag', config: { action_type: 'add_tag', tag: 'inactive' } } },
    ],
    edges: [
      { id: 'e1', source: 'trigger_1', target: 'email_1' },
      { id: 'e2', source: 'email_1', target: 'delay_1' },
      { id: 'e3', source: 'delay_1', target: 'condition_1' },
      { id: 'e4', source: 'condition_1', target: 'email_2' },
      { id: 'e5', source: 'condition_1', target: 'action_1' },
    ]
  },
  {
    id: 'birthday',
    name: 'Birthday Campaign',
    description: 'Automated birthday wishes with special offer',
    category: 'Engagement',
    icon: <Gift className="w-5 h-5" />,
    nodes: [
      { id: 'trigger_1', type: 'trigger', position: { x: 100, y: 100 }, data: { label: 'Birthday Trigger', config: { trigger_type: 'date_based' } } },
      { id: 'email_1', type: 'email', position: { x: 300, y: 100 }, data: { label: 'Birthday Wishes', config: { subject: 'Happy Birthday! 🎉' } } },
      { id: 'action_1', type: 'action', position: { x: 500, y: 100 }, data: { label: 'Add Birthday Tag', config: { action_type: 'add_tag', tag: 'birthday_2024' } } },
    ],
    edges: [
      { id: 'e1', source: 'trigger_1', target: 'email_1' },
      { id: 'e2', source: 'email_1', target: 'action_1' },
    ]
  },
  {
    id: 'post-purchase',
    name: 'Post-Purchase Follow-up',
    description: 'Thank you and review request sequence',
    category: 'Sales',
    icon: <Mail className="w-5 h-5" />,
    nodes: [
      { id: 'trigger_1', type: 'trigger', position: { x: 100, y: 100 }, data: { label: 'Purchase Made', config: { trigger_type: 'purchase' } } },
      { id: 'email_1', type: 'email', position: { x: 300, y: 100 }, data: { label: 'Thank You', config: { subject: 'Thank you for your purchase!' } } },
      { id: 'delay_1', type: 'delay', position: { x: 500, y: 100 }, data: { label: 'Wait 7 Days', config: { delay: 7, delay_unit: 'days' } } },
      { id: 'email_2', type: 'email', position: { x: 700, y: 100 }, data: { label: 'Review Request', config: { subject: 'How was your experience?' } } },
    ],
    edges: [
      { id: 'e1', source: 'trigger_1', target: 'email_1' },
      { id: 'e2', source: 'email_1', target: 'delay_1' },
      { id: 'e3', source: 'delay_1', target: 'email_2' },
    ]
  }
];

interface WorkflowTemplatesProps {
  onClose: () => void;
  onSelect: (template: WorkflowTemplate) => void;
}

const WorkflowTemplates: React.FC<WorkflowTemplatesProps> = ({ onClose, onSelect }) => {
  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Workflow Templates</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {templates.map((template) => (
            <Card key={template.id} className="p-4 hover:shadow-lg transition-shadow cursor-pointer" onClick={() => onSelect(template)}>
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  {template.icon}
                  <h3 className="font-semibold">{template.name}</h3>
                </div>
                <Badge variant="secondary">{template.category}</Badge>
              </div>
              <p className="text-sm text-gray-600 mb-3">{template.description}</p>
              <div className="flex items-center gap-4 text-xs text-gray-500">
                <span>{template.nodes.length} nodes</span>
                <span>{template.edges.length} connections</span>
              </div>
              <Button className="w-full mt-3" variant="outline" size="sm">
                Use Template
              </Button>
            </Card>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default WorkflowTemplates;