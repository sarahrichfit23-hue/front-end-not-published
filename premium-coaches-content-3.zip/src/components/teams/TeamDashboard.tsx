import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { Users, Activity, Settings, Plus, Shield, Clock } from 'lucide-react';
import TeamList from './TeamList';
import TeamMembers from './TeamMembers';
import TeamActivity from './TeamActivity';
import TeamSettings from './TeamSettings';
import CreateTeamDialog from './CreateTeamDialog';

export default function TeamDashboard() {
  const [teams, setTeams] = useState<any[]>([]);
  const [selectedTeam, setSelectedTeam] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [stats, setStats] = useState({
    totalTeams: 0,
    totalMembers: 0,
    pendingInvites: 0,
    recentActivity: 0
  });

  useEffect(() => {
    loadTeams();
    loadStats();
  }, []);

  const loadTeams = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('teams')
        .select(`
          *,
          team_members!inner(*)
        `)
        .eq('team_members.user_id', user.id)
        .eq('team_members.status', 'active');

      if (error) throw error;
      setTeams(data || []);
      if (data && data.length > 0 && !selectedTeam) {
        setSelectedTeam(data[0]);
      }
    } catch (error) {
      console.error('Error loading teams:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadStats = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Get team stats
      const { count: teamCount } = await supabase
        .from('team_members')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('status', 'active');

      const { count: memberCount } = await supabase
        .from('team_members')
        .select('*', { count: 'exact', head: true })
        .in('team_id', teams.map(t => t.id))
        .eq('status', 'active');

      const { count: inviteCount } = await supabase
        .from('team_invitations')
        .select('*', { count: 'exact', head: true })
        .in('team_id', teams.map(t => t.id))
        .is('accepted_at', null)
        .gt('expires_at', new Date().toISOString());

      const { count: activityCount } = await supabase
        .from('team_activity_logs')
        .select('*', { count: 'exact', head: true })
        .in('team_id', teams.map(t => t.id))
        .gte('created_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString());

      setStats({
        totalTeams: teamCount || 0,
        totalMembers: memberCount || 0,
        pendingInvites: inviteCount || 0,
        recentActivity: activityCount || 0
      });
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  };

  const handleTeamCreated = (team: any) => {
    setTeams([...teams, team]);
    setSelectedTeam(team);
    setShowCreateDialog(false);
    loadStats();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Team Collaboration</h2>
          <p className="text-muted-foreground mt-1">
            Manage teams, invite members, and collaborate on content
          </p>
        </div>
        <Button onClick={() => setShowCreateDialog(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create Team
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Teams</p>
                <p className="text-2xl font-bold">{stats.totalTeams}</p>
              </div>
              <Users className="h-8 w-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Team Members</p>
                <p className="text-2xl font-bold">{stats.totalMembers}</p>
              </div>
              <Shield className="h-8 w-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending Invites</p>
                <p className="text-2xl font-bold">{stats.pendingInvites}</p>
              </div>
              <Clock className="h-8 w-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Recent Activity</p>
                <p className="text-2xl font-bold">{stats.recentActivity}</p>
                <p className="text-xs text-muted-foreground">Last 24h</p>
              </div>
              <Activity className="h-8 w-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Team Management */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <TeamList
            teams={teams}
            selectedTeam={selectedTeam}
            onSelectTeam={setSelectedTeam}
            onRefresh={loadTeams}
          />
        </div>

        <div className="lg:col-span-2">
          {selectedTeam ? (
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>{selectedTeam.name}</CardTitle>
                  <Badge variant="outline">
                    {selectedTeam.team_members?.[0]?.role || 'Member'}
                  </Badge>
                </div>
                {selectedTeam.description && (
                  <p className="text-sm text-muted-foreground mt-2">
                    {selectedTeam.description}
                  </p>
                )}
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="members">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="members">
                      <Users className="mr-2 h-4 w-4" />
                      Members
                    </TabsTrigger>
                    <TabsTrigger value="activity">
                      <Activity className="mr-2 h-4 w-4" />
                      Activity
                    </TabsTrigger>
                    <TabsTrigger value="settings">
                      <Settings className="mr-2 h-4 w-4" />
                      Settings
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="members">
                    <TeamMembers 
                      teamId={selectedTeam.id}
                      userRole={selectedTeam.team_members?.[0]?.role}
                    />
                  </TabsContent>

                  <TabsContent value="activity">
                    <TeamActivity teamId={selectedTeam.id} />
                  </TabsContent>

                  <TabsContent value="settings">
                    <TeamSettings 
                      team={selectedTeam}
                      userRole={selectedTeam.team_members?.[0]?.role}
                      onUpdate={(updatedTeam) => {
                        setSelectedTeam(updatedTeam);
                        loadTeams();
                      }}
                    />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Team Selected</h3>
                <p className="text-muted-foreground mb-4">
                  Select a team from the list or create a new one to get started
                </p>
                <Button onClick={() => setShowCreateDialog(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Your First Team
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <CreateTeamDialog
        open={showCreateDialog}
        onClose={() => setShowCreateDialog(false)}
        onTeamCreated={handleTeamCreated}
      />
    </div>
  );
}