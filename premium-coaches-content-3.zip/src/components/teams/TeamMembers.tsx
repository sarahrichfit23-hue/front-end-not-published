import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/lib/supabase';
import { UserPlus, Crown, Shield, User, Edit2, Trash2, Mail } from 'lucide-react';
import InviteMemberDialog from './InviteMemberDialog';

interface TeamMembersProps {
  teamId: string;
  userRole: string;
}

export default function TeamMembers({ teamId, userRole }: TeamMembersProps) {
  const [members, setMembers] = useState<any[]>([]);
  const [invitations, setInvitations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [editingMember, setEditingMember] = useState<string | null>(null);

  useEffect(() => {
    loadMembers();
    loadInvitations();
  }, [teamId]);

  const loadMembers = async () => {
    try {
      const { data, error } = await supabase
        .from('team_members')
        .select(`
          *,
          profiles:user_id(*)
        `)
        .eq('team_id', teamId)
        .eq('status', 'active');

      if (error) throw error;
      setMembers(data || []);
    } catch (error) {
      console.error('Error loading members:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadInvitations = async () => {
    try {
      const { data, error } = await supabase
        .from('team_invitations')
        .select('*')
        .eq('team_id', teamId)
        .is('accepted_at', null)
        .gt('expires_at', new Date().toISOString());

      if (error) throw error;
      setInvitations(data || []);
    } catch (error) {
      console.error('Error loading invitations:', error);
    }
  };

  const handleRoleChange = async (memberId: string, newRole: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('team-operations', {
        body: {
          action: 'update-member-role',
          teamId,
          memberId,
          newRole
        }
      });

      if (error) throw error;
      
      loadMembers();
      setEditingMember(null);
    } catch (error) {
      console.error('Error updating role:', error);
    }
  };

  const handleRemoveMember = async (memberId: string) => {
    if (!confirm('Are you sure you want to remove this member?')) return;

    try {
      const { data, error } = await supabase.functions.invoke('team-operations', {
        body: {
          action: 'remove-member',
          teamId,
          memberId
        }
      });

      if (error) throw error;
      loadMembers();
    } catch (error) {
      console.error('Error removing member:', error);
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'owner':
        return <Crown className="h-4 w-4" />;
      case 'admin':
        return <Shield className="h-4 w-4" />;
      default:
        return <User className="h-4 w-4" />;
    }
  };

  const canManageMembers = ['owner', 'admin'].includes(userRole);
  const canChangeRoles = userRole === 'owner';

  return (
    <div className="space-y-4">
      {canManageMembers && (
        <div className="flex justify-end">
          <Button onClick={() => setShowInviteDialog(true)}>
            <UserPlus className="mr-2 h-4 w-4" />
            Invite Member
          </Button>
        </div>
      )}

      {/* Active Members */}
      <div className="space-y-2">
        <h4 className="font-medium mb-2">Active Members ({members.length})</h4>
        {members.map((member) => (
          <div key={member.id} className="flex items-center justify-between p-3 border rounded-lg">
            <div className="flex items-center space-x-3">
              <Avatar>
                <AvatarFallback>
                  {member.profiles?.full_name?.[0] || member.profiles?.email?.[0] || '?'}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">
                  {member.profiles?.full_name || member.profiles?.email || 'Unknown'}
                </p>
                <p className="text-sm text-muted-foreground">{member.profiles?.email}</p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {editingMember === member.id && canChangeRoles ? (
                <Select
                  value={member.role}
                  onValueChange={(value) => handleRoleChange(member.id, value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="member">Member</SelectItem>
                    <SelectItem value="editor">Editor</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                    {userRole === 'owner' && <SelectItem value="owner">Owner</SelectItem>}
                  </SelectContent>
                </Select>
              ) : (
                <Badge variant={member.role === 'owner' ? 'destructive' : 'secondary'}>
                  <span className="mr-1">{getRoleIcon(member.role)}</span>
                  {member.role}
                </Badge>
              )}

              {canManageMembers && member.role !== 'owner' && (
                <>
                  {canChangeRoles && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setEditingMember(
                        editingMember === member.id ? null : member.id
                      )}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemoveMember(member.user_id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Pending Invitations */}
      {invitations.length > 0 && (
        <div className="space-y-2">
          <h4 className="font-medium mb-2">Pending Invitations ({invitations.length})</h4>
          {invitations.map((invitation) => (
            <div key={invitation.id} className="flex items-center justify-between p-3 border rounded-lg opacity-75">
              <div className="flex items-center space-x-3">
                <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center">
                  <Mail className="h-5 w-5 text-muted-foreground" />
                </div>
                <div>
                  <p className="font-medium">{invitation.email}</p>
                  <p className="text-sm text-muted-foreground">
                    Invited {new Date(invitation.created_at).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <Badge variant="outline">{invitation.role}</Badge>
            </div>
          ))}
        </div>
      )}

      <InviteMemberDialog
        open={showInviteDialog}
        onClose={() => setShowInviteDialog(false)}
        teamId={teamId}
        onInvited={() => {
          loadInvitations();
          setShowInviteDialog(false);
        }}
      />
    </div>
  );
}