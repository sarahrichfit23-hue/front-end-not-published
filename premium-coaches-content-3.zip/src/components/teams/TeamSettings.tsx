import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/lib/supabase';
import { Save, Trash2, AlertCircle } from 'lucide-react';

interface TeamSettingsProps {
  team: any;
  userRole: string;
  onUpdate: (team: any) => void;
}

export default function TeamSettings({ team, userRole, onUpdate }: TeamSettingsProps) {
  const [formData, setFormData] = useState({
    name: team.name || '',
    description: team.description || '',
    settings: team.settings || {}
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const canEdit = ['owner', 'admin'].includes(userRole);
  const canDelete = userRole === 'owner';

  const handleSave = async () => {
    if (!canEdit) return;

    setSaving(true);
    setError('');

    try {
      const { data, error } = await supabase
        .from('teams')
        .update({
          name: formData.name,
          description: formData.description,
          settings: formData.settings,
          updated_at: new Date().toISOString()
        })
        .eq('id', team.id)
        .select()
        .single();

      if (error) throw error;

      // Log activity
      await supabase
        .from('team_activity_logs')
        .insert({
          team_id: team.id,
          user_id: (await supabase.auth.getUser()).data.user?.id,
          action: 'settings_updated',
          resource_type: 'team',
          resource_id: team.id,
          resource_name: team.name
        });

      onUpdate(data);
    } catch (error: any) {
      setError(error.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!canDelete) return;
    
    if (!confirm('Are you sure you want to delete this team? This action cannot be undone.')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('teams')
        .delete()
        .eq('id', team.id);

      if (error) throw error;

      window.location.href = '/dashboard';
    } catch (error: any) {
      setError(error.message);
    }
  };

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="space-y-4">
        <div>
          <Label htmlFor="name">Team Name</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            disabled={!canEdit}
            className="mt-1"
          />
        </div>

        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            disabled={!canEdit}
            rows={3}
            className="mt-1"
            placeholder="Describe your team's purpose and goals..."
          />
        </div>

        <div className="space-y-4 border-t pt-4">
          <h4 className="font-medium">Team Preferences</h4>
          
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="notifications">Email Notifications</Label>
              <p className="text-sm text-muted-foreground">
                Receive email updates about team activity
              </p>
            </div>
            <Switch
              id="notifications"
              checked={formData.settings.emailNotifications !== false}
              onCheckedChange={(checked) => 
                setFormData({
                  ...formData,
                  settings: { ...formData.settings, emailNotifications: checked }
                })
              }
              disabled={!canEdit}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="approvals">Require Content Approval</Label>
              <p className="text-sm text-muted-foreground">
                Content must be approved before publishing
              </p>
            </div>
            <Switch
              id="approvals"
              checked={formData.settings.requireApproval === true}
              onCheckedChange={(checked) => 
                setFormData({
                  ...formData,
                  settings: { ...formData.settings, requireApproval: checked }
                })
              }
              disabled={!canEdit}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="collaboration">Real-time Collaboration</Label>
              <p className="text-sm text-muted-foreground">
                Enable live editing and presence indicators
              </p>
            </div>
            <Switch
              id="collaboration"
              checked={formData.settings.realtimeCollaboration !== false}
              onCheckedChange={(checked) => 
                setFormData({
                  ...formData,
                  settings: { ...formData.settings, realtimeCollaboration: checked }
                })
              }
              disabled={!canEdit}
            />
          </div>
        </div>
      </div>

      <div className="flex justify-between pt-4 border-t">
        {canDelete && (
          <Button variant="destructive" onClick={handleDelete}>
            <Trash2 className="mr-2 h-4 w-4" />
            Delete Team
          </Button>
        )}
        
        {canEdit && (
          <Button 
            onClick={handleSave} 
            disabled={saving}
            className="ml-auto"
          >
            <Save className="mr-2 h-4 w-4" />
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        )}
      </div>
    </div>
  );
}