import { useState, useEffect } from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { supabase } from '@/lib/supabase';
import { 
  Users, UserPlus, UserMinus, Edit, FileText, MessageSquare, 
  CheckCircle, XCircle, Settings, Clock 
} from 'lucide-react';

interface TeamActivityProps {
  teamId: string;
}

export default function TeamActivity({ teamId }: TeamActivityProps) {
  const [activities, setActivities] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadActivities();
    
    // Subscribe to real-time updates
    const subscription = supabase
      .channel(`team-activity-${teamId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'team_activity_logs',
        filter: `team_id=eq.${teamId}`
      }, (payload) => {
        loadActivities();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [teamId]);

  const loadActivities = async () => {
    try {
      const { data, error } = await supabase
        .from('team_activity_logs')
        .select(`
          *,
          profiles:user_id(*)
        `)
        .eq('team_id', teamId)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setActivities(data || []);
    } catch (error) {
      console.error('Error loading activities:', error);
    } finally {
      setLoading(false);
    }
  };

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'team_created':
        return <Users className="h-4 w-4" />;
      case 'member_invited':
      case 'member_joined':
        return <UserPlus className="h-4 w-4" />;
      case 'member_removed':
        return <UserMinus className="h-4 w-4" />;
      case 'role_updated':
        return <Edit className="h-4 w-4" />;
      case 'content_created':
      case 'content_updated':
        return <FileText className="h-4 w-4" />;
      case 'comment_added':
        return <MessageSquare className="h-4 w-4" />;
      case 'approval_requested':
      case 'content_approved':
        return <CheckCircle className="h-4 w-4" />;
      case 'content_rejected':
        return <XCircle className="h-4 w-4" />;
      case 'settings_updated':
        return <Settings className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getActionDescription = (activity: any) => {
    const userName = activity.profiles?.full_name || activity.profiles?.email || 'Someone';
    
    switch (activity.action) {
      case 'team_created':
        return `${userName} created the team`;
      case 'member_invited':
        return `${userName} invited ${activity.details?.email || 'a new member'}`;
      case 'member_joined':
        return `${userName} joined the team`;
      case 'member_removed':
        return `${userName} was removed from the team`;
      case 'role_updated':
        return `${userName}'s role was updated to ${activity.details?.newRole}`;
      case 'content_created':
        return `${userName} created ${activity.resource_name || 'new content'}`;
      case 'content_updated':
        return `${userName} updated ${activity.resource_name || 'content'}`;
      case 'comment_added':
        return `${userName} commented on ${activity.resource_name || 'content'}`;
      case 'approval_requested':
        return `${userName} requested approval for ${activity.resource_name || 'content'}`;
      case 'content_approved':
        return `${userName} approved ${activity.resource_name || 'content'}`;
      case 'content_rejected':
        return `${userName} rejected ${activity.resource_name || 'content'}`;
      case 'settings_updated':
        return `${userName} updated team settings`;
      default:
        return `${userName} performed ${activity.action}`;
    }
  };

  const getRelativeTime = (date: string) => {
    const now = new Date();
    const then = new Date(date);
    const seconds = Math.floor((now.getTime() - then.getTime()) / 1000);

    if (seconds < 60) return 'just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
    return then.toLocaleDateString();
  };

  if (loading) {
    return <div className="text-center py-8">Loading activity...</div>;
  }

  return (
    <ScrollArea className="h-[400px]">
      <div className="space-y-4">
        {activities.length === 0 ? (
          <div className="text-center py-8">
            <Clock className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No activity yet</p>
          </div>
        ) : (
          activities.map((activity) => (
            <div key={activity.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-muted/50">
              <div className="mt-1">
                <Avatar className="h-8 w-8">
                  <AvatarFallback>
                    {activity.profiles?.full_name?.[0] || activity.profiles?.email?.[0] || '?'}
                  </AvatarFallback>
                </Avatar>
              </div>
              <div className="flex-1 space-y-1">
                <div className="flex items-center space-x-2">
                  {getActionIcon(activity.action)}
                  <p className="text-sm">{getActionDescription(activity)}</p>
                </div>
                <p className="text-xs text-muted-foreground">
                  {getRelativeTime(activity.created_at)}
                </p>
              </div>
            </div>
          ))
        )}
      </div>
    </ScrollArea>
  );
}