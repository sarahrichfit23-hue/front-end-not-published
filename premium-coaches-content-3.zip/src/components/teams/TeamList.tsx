import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Users, Crown, Shield, User, RefreshCw } from 'lucide-react';

interface TeamListProps {
  teams: any[];
  selectedTeam: any;
  onSelectTeam: (team: any) => void;
  onRefresh: () => void;
}

export default function TeamList({ teams, selectedTeam, onSelectTeam, onRefresh }: TeamListProps) {
  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'owner':
        return <Crown className="h-4 w-4" />;
      case 'admin':
        return <Shield className="h-4 w-4" />;
      default:
        return <User className="h-4 w-4" />;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'owner':
        return 'destructive';
      case 'admin':
        return 'default';
      case 'editor':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  return (
    <Card className="h-full">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Your Teams</CardTitle>
          <Button variant="ghost" size="icon" onClick={onRefresh}>
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[500px]">
          <div className="space-y-2">
            {teams.length === 0 ? (
              <div className="text-center py-8">
                <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No teams yet</p>
              </div>
            ) : (
              teams.map((team) => (
                <div
                  key={team.id}
                  className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                    selectedTeam?.id === team.id
                      ? 'bg-primary/10 border-primary'
                      : 'hover:bg-muted'
                  }`}
                  onClick={() => onSelectTeam(team)}
                >
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold">{team.name}</h4>
                    <Badge variant={getRoleColor(team.team_members?.[0]?.role)}>
                      <span className="mr-1">
                        {getRoleIcon(team.team_members?.[0]?.role)}
                      </span>
                      {team.team_members?.[0]?.role}
                    </Badge>
                  </div>
                  {team.description && (
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {team.description}
                    </p>
                  )}
                  <div className="flex items-center mt-2 text-xs text-muted-foreground">
                    <Users className="h-3 w-3 mr-1" />
                    <span>{team.team_members?.length || 0} members</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}