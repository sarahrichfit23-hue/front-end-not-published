import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import {
  Key,
  Shield,
  Users,
  DollarSign,
  Package,
  AlertCircle,
  Copy,
  Download,
  RefreshCw,
  Ban,
  CheckCircle,
  Building,
  TrendingUp
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';

interface LicenseTier {
  id: string;
  name: string;
  type: string;
  price: number;
  features: string[];
  usage_limit?: number;
  domain_limit?: number;
  white_label_allowed: boolean;
  reseller_allowed: boolean;
}

export function LicenseManager({ templateId }: { templateId: string }) {
  const [tiers, setTiers] = useState<LicenseTier[]>([]);
  const [licenses, setLicenses] = useState<any[]>([]);
  const [usage, setUsage] = useState<any[]>([]);
  const [compliance, setCompliance] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showTierDialog, setShowTierDialog] = useState(false);
  const { toast } = useToast();

  const [newTier, setNewTier] = useState({
    name: '',
    type: 'personal',
    price: 0,
    features: [],
    usage_limit: null,
    domain_limit: 1,
    white_label_allowed: false,
    reseller_allowed: false
  });

  useEffect(() => {
    loadLicenseData();
  }, [templateId]);

  const loadLicenseData = async () => {
    try {
      const [tiersRes, licensesRes, usageRes, complianceRes] = await Promise.all([
        supabase.from('license_tiers').select('*').eq('template_id', templateId),
        supabase.from('license_keys').select('*, profiles(*)').eq('template_id', templateId),
        supabase.from('license_usage').select('*').eq('license_key_id', 'in', '(SELECT id FROM license_keys WHERE template_id = $1)', templateId),
        supabase.from('license_compliance_logs').select('*').eq('license_key_id', 'in', '(SELECT id FROM license_keys WHERE template_id = $1)', templateId)
      ]);

      setTiers(tiersRes.data || []);
      setLicenses(licensesRes.data || []);
      setUsage(usageRes.data || []);
      setCompliance(complianceRes.data || []);
    } catch (error) {
      console.error('Error loading license data:', error);
    } finally {
      setLoading(false);
    }
  };

  const createTier = async () => {
    try {
      const { error } = await supabase.from('license_tiers').insert({
        template_id: templateId,
        ...newTier
      });

      if (error) throw error;

      toast({
        title: 'License tier created',
        description: 'New licensing tier has been added successfully.'
      });

      setShowTierDialog(false);
      loadLicenseData();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create license tier.',
        variant: 'destructive'
      });
    }
  };

  const revokeLicense = async (keyId: string) => {
    try {
      const { error } = await supabase.functions.invoke('license-management', {
        body: { action: 'revoke_key', keyId, reason: 'Manual revocation by creator' }
      });

      if (error) throw error;

      toast({
        title: 'License revoked',
        description: 'The license has been revoked successfully.'
      });

      loadLicenseData();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to revoke license.',
        variant: 'destructive'
      });
    }
  };

  const copyLicenseKey = (key: string) => {
    navigator.clipboard.writeText(key);
    toast({
      title: 'Copied',
      description: 'License key copied to clipboard.'
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">License Management</h3>
        <Dialog open={showTierDialog} onOpenChange={setShowTierDialog}>
          <DialogTrigger asChild>
            <Button>
              <Package className="h-4 w-4 mr-2" />
              Add License Tier
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create License Tier</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Tier Name</Label>
                <Input
                  value={newTier.name}
                  onChange={(e) => setNewTier({ ...newTier, name: e.target.value })}
                  placeholder="e.g., Professional"
                />
              </div>
              <div>
                <Label>License Type</Label>
                <Select value={newTier.type} onValueChange={(v) => setNewTier({ ...newTier, type: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="personal">Personal</SelectItem>
                    <SelectItem value="commercial">Commercial</SelectItem>
                    <SelectItem value="enterprise">Enterprise</SelectItem>
                    <SelectItem value="white_label">White Label</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Price</Label>
                <Input
                  type="number"
                  value={newTier.price}
                  onChange={(e) => setNewTier({ ...newTier, price: parseFloat(e.target.value) })}
                />
              </div>
              <div>
                <Label>Usage Limit (leave empty for unlimited)</Label>
                <Input
                  type="number"
                  value={newTier.usage_limit || ''}
                  onChange={(e) => setNewTier({ ...newTier, usage_limit: e.target.value ? parseInt(e.target.value) : null })}
                />
              </div>
              <div>
                <Label>Domain Limit</Label>
                <Input
                  type="number"
                  value={newTier.domain_limit}
                  onChange={(e) => setNewTier({ ...newTier, domain_limit: parseInt(e.target.value) })}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  checked={newTier.white_label_allowed}
                  onCheckedChange={(checked) => setNewTier({ ...newTier, white_label_allowed: checked })}
                />
                <Label>Allow White Label</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  checked={newTier.reseller_allowed}
                  onCheckedChange={(checked) => setNewTier({ ...newTier, reseller_allowed: checked })}
                />
                <Label>Allow Reseller Program</Label>
              </div>
              <Button onClick={createTier} className="w-full">Create Tier</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="tiers">
        <TabsList>
          <TabsTrigger value="tiers">License Tiers</TabsTrigger>
          <TabsTrigger value="keys">Active Licenses</TabsTrigger>
          <TabsTrigger value="usage">Usage Analytics</TabsTrigger>
          <TabsTrigger value="compliance">Compliance</TabsTrigger>
        </TabsList>

        <TabsContent value="tiers" className="space-y-4">
          <div className="grid gap-4">
            {tiers.map((tier) => (
              <Card key={tier.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{tier.name}</CardTitle>
                      <Badge className="mt-2">{tier.type}</Badge>
                    </div>
                    <div className="text-2xl font-bold">${tier.price}</div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Usage Limit:</span>
                      <span className="ml-2">{tier.usage_limit || 'Unlimited'}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Domain Limit:</span>
                      <span className="ml-2">{tier.domain_limit}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">White Label:</span>
                      <span className="ml-2">{tier.white_label_allowed ? 'Yes' : 'No'}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Reseller:</span>
                      <span className="ml-2">{tier.reseller_allowed ? 'Yes' : 'No'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="keys" className="space-y-4">
          <div className="space-y-2">
            {licenses.map((license) => (
              <Card key={license.id}>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-4">
                      <Key className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <div className="font-mono text-sm">{license.key}</div>
                        <div className="text-sm text-muted-foreground">
                          {license.profiles?.email} • Activations: {license.current_activations}/{license.max_activations}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={license.status === 'active' ? 'default' : 'destructive'}>
                        {license.status}
                      </Badge>
                      <Button size="sm" variant="ghost" onClick={() => copyLicenseKey(license.key)}>
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => revokeLicense(license.id)}>
                        <Ban className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="usage">
          <Card>
            <CardHeader>
              <CardTitle>Usage Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{licenses.length}</div>
                    <div className="text-sm text-muted-foreground">Total Licenses</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">
                      {licenses.filter(l => l.status === 'active').length}
                    </div>
                    <div className="text-sm text-muted-foreground">Active</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">
                      {licenses.reduce((sum, l) => sum + l.current_activations, 0)}
                    </div>
                    <div className="text-sm text-muted-foreground">Total Activations</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="compliance">
          <div className="space-y-2">
            {compliance.map((log) => (
              <Card key={log.id}>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-4">
                      <AlertCircle className="h-5 w-5 text-yellow-500" />
                      <div>
                        <div className="font-medium">{log.violation_type}</div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(log.logged_at).toLocaleString()}
                        </div>
                      </div>
                    </div>
                    <Badge variant={log.severity === 'high' ? 'destructive' : 'secondary'}>
                      {log.severity}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}