import { useState, useEffect } from 'react';
import { Search, Filter, Star, Download, Eye, TrendingUp, DollarSign, Package } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

const categories = ['Welcome Series', 'Promotional', 'Newsletter', 'Transactional', 'Re-engagement', 'Workflow'];

export default function TemplateMarketplace() {
  const [templates, setTemplates] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('popular');
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchTemplates();
  }, [selectedCategory, sortBy]);

  const fetchTemplates = async () => {
    setLoading(true);
    let query = supabase.from('marketplace_templates').select('*').eq('status', 'approved');
    
    if (selectedCategory !== 'all') {
      query = query.eq('category', selectedCategory);
    }
    
    if (sortBy === 'popular') {
      query = query.order('downloads', { ascending: false });
    } else if (sortBy === 'rating') {
      query = query.order('rating', { ascending: false });
    } else if (sortBy === 'newest') {
      query = query.order('created_at', { ascending: false });
    } else if (sortBy === 'price-low') {
      query = query.order('price', { ascending: true });
    }

    const { data, error } = await query;
    if (!error && data) {
      setTemplates(data);
    }
    setLoading(false);
  };

  const handlePurchase = async (template: any) => {
    try {
      const { data, error } = await supabase.functions.invoke('marketplace-purchase', {
        body: {
          templateId: template.id,
          price: template.price,
          title: template.title,
          creatorShare: template.revenue_share
        }
      });

      if (error) throw error;
      if (data?.url) {
        window.location.href = data.url;
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to initiate purchase',
        variant: 'destructive'
      });
    }
  };

  const trackEvent = async (templateId: string, eventType: string) => {
    await supabase.from('marketplace_analytics').insert({
      template_id: templateId,
      event_type: eventType,
      user_id: (await supabase.auth.getUser()).data.user?.id
    });
  };

  const filteredTemplates = templates.filter(t =>
    t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map(cat => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="popular">Most Popular</SelectItem>
            <SelectItem value="rating">Highest Rated</SelectItem>
            <SelectItem value="newest">Newest</SelectItem>
            <SelectItem value="price-low">Price: Low to High</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="templates" className="w-full">
        <TabsList>
          <TabsTrigger value="templates">Email Templates</TabsTrigger>
          <TabsTrigger value="workflows">Workflow Automations</TabsTrigger>
          <TabsTrigger value="bundles">Template Bundles</TabsTrigger>
        </TabsList>

        <TabsContent value="templates" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {loading ? (
              Array.from({ length: 8 }).map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <div className="h-48 bg-muted" />
                  <CardHeader>
                    <div className="h-4 bg-muted rounded w-3/4" />
                    <div className="h-3 bg-muted rounded w-full mt-2" />
                  </CardHeader>
                </Card>
              ))
            ) : (
              filteredTemplates.map((template) => (
                <Card key={template.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div 
                    className="h-48 bg-cover bg-center cursor-pointer"
                    style={{ backgroundImage: `url(${template.thumbnail_url || 'https://d64gsuwffb70l.cloudfront.net/68dfc9e8b5169294db44bd19_1759539782025_e51c83a2.webp'})` }}
                    onClick={() => {
                      trackEvent(template.id, 'preview');
                      // Open preview modal
                    }}
                  />
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{template.title}</CardTitle>
                      {template.featured && <Badge variant="secondary">Featured</Badge>}
                    </div>
                    <CardDescription className="line-clamp-2">{template.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                        <span>{template.rating?.toFixed(1) || '0.0'}</span>
                        <span>({template.total_ratings || 0})</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Download className="h-4 w-4" />
                        <span>{template.downloads || 0}</span>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-2 flex-wrap">
                      {template.tags?.slice(0, 3).map((tag: string) => (
                        <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between items-center">
                    <div className="text-2xl font-bold">
                      {template.price === 0 ? 'Free' : `$${template.price}`}
                    </div>
                    <Button 
                      size="sm"
                      onClick={() => template.price === 0 ? 
                        toast({ title: 'Template imported successfully!' }) : 
                        handlePurchase(template)
                      }
                    >
                      {template.price === 0 ? 'Import' : 'Purchase'}
                    </Button>
                  </CardFooter>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="workflows" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {['Welcome Series', 'Abandoned Cart', 'Re-engagement', 'Birthday Campaign'].map((workflow, i) => (
              <Card key={i} className="overflow-hidden">
                <div 
                  className="h-48 bg-cover bg-center"
                  style={{ backgroundImage: `url(https://d64gsuwffb70l.cloudfront.net/68dfc9e8b5169294db44bd19_175953979${5897 + i * 1698}_${['da7f98a1', '25241254', '52c80fb2', '5da0c3f9'][i]}.webp)` }}
                />
                <CardHeader>
                  <CardTitle>{workflow} Automation</CardTitle>
                  <CardDescription>Complete workflow with all triggers and conditions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Package className="h-4 w-4" />
                      <span>{3 + i} emails</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <TrendingUp className="h-4 w-4" />
                      <span>{85 + i * 3}% success rate</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <span className="text-2xl font-bold">${29 + i * 10}</span>
                  <Button size="sm">Get Workflow</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="bundles" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {['Starter Pack', 'Professional Suite', 'Enterprise Collection'].map((bundle, i) => (
              <Card key={i} className="border-2 hover:border-primary transition-colors">
                <CardHeader>
                  <CardTitle>{bundle}</CardTitle>
                  <CardDescription>{10 + i * 5} premium templates</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2">
                      <Badge variant="outline">Email Templates</Badge>
                      <span>{5 + i * 3}</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Badge variant="outline">Workflows</Badge>
                      <span>{3 + i * 2}</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Badge variant="outline">Support</Badge>
                      <span>{i === 2 ? 'Priority' : i === 1 ? 'Standard' : 'Community'}</span>
                    </li>
                  </ul>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div>
                    <div className="text-2xl font-bold">${99 + i * 100}</div>
                    <div className="text-sm text-muted-foreground line-through">${149 + i * 150}</div>
                  </div>
                  <Button>Get Bundle</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}