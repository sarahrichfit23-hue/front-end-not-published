import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import {
  Package,
  DollarSign,
  Users,
  TrendingUp,
  Edit,
  Trash2,
  Eye,
  Plus,
  Upload,
  History,
  Key,
  Shield
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription as DialogDesc,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { VersionHistory } from './VersionHistory';
import { LicenseManager } from './LicenseManager';
import { Star, GitBranch } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export function CreatorDashboard() {
  const [stats, setStats] = useState<any>({ totalRevenue: 0, monthlyRevenue: 0, totalSales: 0, totalViews: 0, avgRating: 0, templates: [] });
  const [revenueData, setRevenueData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTemplate, setSelectedTemplate] = useState<any>(null);
  const [showVersionDialog, setShowVersionDialog] = useState(false);
  const [showHistoryDialog, setShowHistoryDialog] = useState(false);
  const [versionForm, setVersionForm] = useState({
    versionNumber: '',
    changelog: '',
    releaseNotes: '',
    isBeta: false,
    notifyUsers: true
  });
  const { toast } = useToast();
  
  useEffect(() => {
    fetchCreatorStats();
    fetchRevenueData();
  }, []);

  const fetchCreatorStats = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    // Fetch templates with version info
    const { data: templates } = await supabase
      .from('marketplace_templates')
      .select('*, template_versions(count)')
      .eq('creator_id', user.id);

    // Fetch purchases
    const { data: purchases } = await supabase
      .from('template_purchases')
      .select('*')
      .in('template_id', templates?.map(t => t.id) || []);

    // Calculate stats
    const totalRevenue = purchases?.reduce((sum, p) => sum + (p.price * 0.7), 0) || 0;
    const monthlyRevenue = purchases?.filter(p => {
      const purchaseDate = new Date(p.purchased_at);
      const now = new Date();
      return purchaseDate.getMonth() === now.getMonth() && purchaseDate.getFullYear() === now.getFullYear();
    }).reduce((sum, p) => sum + (p.price * 0.7), 0) || 0;

    setStats({
      totalRevenue,
      monthlyRevenue,
      totalSales: purchases?.length || 0,
      totalViews: templates?.reduce((sum, t) => sum + (t.downloads || 0), 0) || 0,
      avgRating: templates?.reduce((sum, t) => sum + (t.rating || 0), 0) / (templates?.length || 1) || 0,
      templates: templates || []
    });
    setLoading(false);
  };

  const fetchRevenueData = async () => {
    // Mock revenue data for chart
    const data = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      return {
        date: date.toLocaleDateString('en-US', { weekday: 'short' }),
        revenue: Math.floor(Math.random() * 500) + 100,
        sales: Math.floor(Math.random() * 10) + 1
      };
    });
    setRevenueData(data);
  };

  const handlePayout = async () => {
    // Trigger payout request
    console.log('Payout requested');
  };

  const handlePublishVersion = async () => {
    if (!selectedTemplate || !versionForm.versionNumber) return;

    try {
      const { data, error } = await supabase.functions.invoke('template-version-update', {
        body: {
          templateId: selectedTemplate.id,
          ...versionForm
        }
      });

      if (error) throw error;

      toast({
        title: "Version Published",
        description: `Version ${versionForm.versionNumber} has been published successfully.`
      });

      setShowVersionDialog(false);
      setVersionForm({
        versionNumber: '',
        changelog: '',
        releaseNotes: '',
        isBeta: false,
        notifyUsers: true
      });
      fetchCreatorStats();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to publish version. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleRollback = async (versionId: string) => {
    try {
      // Set the selected version as current
      await supabase
        .from('template_versions')
        .update({ is_current: false })
        .eq('template_id', selectedTemplate.id);

      await supabase
        .from('template_versions')
        .update({ is_current: true })
        .eq('id', versionId);

      toast({
        title: "Rollback Successful",
        description: "Template has been rolled back to the selected version."
      });

      setShowHistoryDialog(false);
      fetchCreatorStats();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to rollback version.",
        variant: "destructive"
      });
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats.totalRevenue.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Lifetime earnings</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats.monthlyRevenue.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalSales}</div>
            <p className="text-xs text-muted-foreground">Templates sold</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgRating.toFixed(1)}</div>
            <div className="flex gap-1 mt-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className={`h-3 w-3 ${i < Math.round(stats.avgRating) ? 'fill-yellow-500 text-yellow-500' : 'text-gray-300'}`} />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Revenue Overview</CardTitle>
          <CardDescription>Your earnings over the last 7 days</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="revenue" stroke="#8884d8" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Tabs defaultValue="templates" className="w-full">
        <TabsList>
          <TabsTrigger value="templates">My Templates</TabsTrigger>
          <TabsTrigger value="licensing">Licensing</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="payouts">Payouts</TabsTrigger>
        </TabsList>

        <TabsContent value="templates">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Published Templates</CardTitle>
                <Button>Upload New Template</Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Template</TableHead>
                    <TableHead>Version</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Sales</TableHead>
                    <TableHead>Revenue</TableHead>
                    <TableHead>Rating</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stats.templates.map((template: any) => (
                    <TableRow key={template.id}>
                      <TableCell className="font-medium">{template.title}</TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          v{template.current_version || '1.0.0'}
                        </Badge>
                      </TableCell>
                      <TableCell>{template.category}</TableCell>
                      <TableCell>${template.price}</TableCell>
                      <TableCell>{template.downloads || 0}</TableCell>
                      <TableCell>${((template.downloads || 0) * template.price * 0.7).toFixed(2)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                          <span>{template.rating?.toFixed(1) || '0.0'}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedTemplate(template);
                              setShowVersionDialog(true);
                            }}
                          >
                            <GitBranch className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedTemplate(template);
                              setShowHistoryDialog(true);
                            }}
                          >
                            <History className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="licensing">
          {selectedTemplate ? (
            <LicenseManager templateId={selectedTemplate.id} />
          ) : (
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-muted-foreground">
                  Select a template from the My Templates tab to manage its licensing
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>Performance Analytics</CardTitle>
              <CardDescription>Detailed insights into your template performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3">Views vs Sales</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={revenueData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="sales" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div>
                  <h3 className="font-semibold mb-3">Conversion Rate</h3>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>View to Purchase</span>
                        <span>12%</span>
                      </div>
                      <Progress value={12} />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Add to Cart</span>
                        <span>35%</span>
                      </div>
                      <Progress value={35} />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Repeat Customers</span>
                        <span>22%</span>
                      </div>
                      <Progress value={22} />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payouts">
          <Card>
            <CardHeader>
              <CardTitle>Payout History</CardTitle>
              <CardDescription>Your earnings and payout schedule</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-semibold">Available Balance</p>
                      <p className="text-2xl font-bold">${stats.monthlyRevenue.toFixed(2)}</p>
                      <p className="text-sm text-muted-foreground">Minimum payout: $50</p>
                    </div>
                    <Button 
                      onClick={handlePayout}
                      disabled={stats.monthlyRevenue < 50}
                    >
                      Request Payout
                    </Button>
                  </div>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Transaction ID</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>Oct 1, 2024</TableCell>
                      <TableCell>$450.00</TableCell>
                      <TableCell>
                        <Badge variant="default">Completed</Badge>
                      </TableCell>
                      <TableCell className="font-mono text-sm">pay_1234567890</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Sep 1, 2024</TableCell>
                      <TableCell>$325.00</TableCell>
                      <TableCell>
                        <Badge variant="default">Completed</Badge>
                      </TableCell>
                      <TableCell className="font-mono text-sm">pay_0987654321</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Version Update Dialog */}
      <Dialog open={showVersionDialog} onOpenChange={setShowVersionDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Publish New Version</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="version">Version Number</Label>
              <Input
                id="version"
                placeholder="e.g., 1.1.0"
                value={versionForm.versionNumber}
                onChange={(e) => setVersionForm({ ...versionForm, versionNumber: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="releaseNotes">Release Notes</Label>
              <Textarea
                id="releaseNotes"
                placeholder="Describe what's new in this version"
                rows={3}
                value={versionForm.releaseNotes}
                onChange={(e) => setVersionForm({ ...versionForm, releaseNotes: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="changelog">Changelog</Label>
              <Textarea
                id="changelog"
                placeholder="[added] New feature&#10;[fixed] Bug fix&#10;[changed] Updated behavior"
                rows={5}
                value={versionForm.changelog}
                onChange={(e) => setVersionForm({ ...versionForm, changelog: e.target.value })}
              />
              <p className="text-xs text-muted-foreground mt-1">
                Use prefixes: [added], [changed], [deprecated], [removed], [fixed], [security]
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="beta"
                checked={versionForm.isBeta}
                onCheckedChange={(checked) => setVersionForm({ ...versionForm, isBeta: checked })}
              />
              <Label htmlFor="beta">Mark as Beta Version</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="notify"
                checked={versionForm.notifyUsers}
                onCheckedChange={(checked) => setVersionForm({ ...versionForm, notifyUsers: checked })}
              />
              <Label htmlFor="notify">Notify all purchasers of this update</Label>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowVersionDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handlePublishVersion}>
                Publish Version
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Version History Dialog */}
      <Dialog open={showHistoryDialog} onOpenChange={setShowHistoryDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Version History - {selectedTemplate?.title}</DialogTitle>
          </DialogHeader>
          {selectedTemplate && (
            <VersionHistory
              templateId={selectedTemplate.id}
              canManage={true}
              onRollback={handleRollback}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}