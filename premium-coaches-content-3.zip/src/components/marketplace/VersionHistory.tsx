import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/lib/supabase';
import { Clock, Download, GitBranch, RotateCcw, ChevronDown, ChevronUp } from 'lucide-react';
import { format } from 'date-fns';

interface Version {
  id: string;
  version_number: string;
  changelog: string;
  release_notes: string;
  is_current: boolean;
  is_beta: boolean;
  created_at: string;
  downloads: number;
  created_by: string;
}

interface VersionHistoryProps {
  templateId: string;
  canManage?: boolean;
  onRollback?: (versionId: string) => void;
}

export function VersionHistory({ templateId, canManage, onRollback }: VersionHistoryProps) {
  const [versions, setVersions] = useState<Version[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedVersion, setExpandedVersion] = useState<string | null>(null);

  useEffect(() => {
    loadVersions();
  }, [templateId]);

  const loadVersions = async () => {
    const { data } = await supabase
      .from('template_versions')
      .select('*')
      .eq('template_id', templateId)
      .order('created_at', { ascending: false });

    if (data) setVersions(data);
    setLoading(false);
  };

  const handleRollback = async (versionId: string) => {
    if (!canManage || !onRollback) return;
    
    const confirm = window.confirm('Are you sure you want to rollback to this version?');
    if (confirm) {
      onRollback(versionId);
    }
  };

  const toggleExpanded = (versionId: string) => {
    setExpandedVersion(expandedVersion === versionId ? null : versionId);
  };

  if (loading) {
    return <div className="animate-pulse h-64 bg-gray-100 rounded-lg" />;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <GitBranch className="h-5 w-5" />
          Version History
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-96">
          <div className="space-y-4">
            {versions.map((version) => (
              <div
                key={version.id}
                className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="font-semibold text-lg">
                      v{version.version_number}
                    </span>
                    {version.is_current && (
                      <Badge className="bg-green-500">Current</Badge>
                    )}
                    {version.is_beta && (
                      <Badge variant="outline" className="border-blue-500 text-blue-500">
                        Beta
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {canManage && !version.is_current && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleRollback(version.id)}
                      >
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Rollback
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => toggleExpanded(version.id)}
                    >
                      {expandedVersion === version.id ? (
                        <ChevronUp className="h-4 w-4" />
                      ) : (
                        <ChevronDown className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>

                <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {format(new Date(version.created_at), 'MMM d, yyyy')}
                  </span>
                  <span className="flex items-center gap-1">
                    <Download className="h-3 w-3" />
                    {version.downloads} downloads
                  </span>
                </div>

                {expandedVersion === version.id && (
                  <div className="mt-4 space-y-3">
                    {version.release_notes && (
                      <div>
                        <h4 className="font-medium mb-1">Release Notes</h4>
                        <p className="text-sm text-gray-600">{version.release_notes}</p>
                      </div>
                    )}
                    {version.changelog && (
                      <div>
                        <h4 className="font-medium mb-1">Changelog</h4>
                        <pre className="text-sm text-gray-600 whitespace-pre-wrap">
                          {version.changelog}
                        </pre>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}