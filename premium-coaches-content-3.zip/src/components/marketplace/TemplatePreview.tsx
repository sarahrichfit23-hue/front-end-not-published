import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Textarea } from '@/components/ui/textarea';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { VersionHistory } from './VersionHistory';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Star,
  Download,
  Eye,
  Clock,
  User,
  ShoppingCart,
  Check,
  AlertCircle,
  GitBranch,
  Key,
  Shield,
  Building,
  X,
  Monitor,
  Smartphone,
  Heart,
  Share2,
  Code,
  Bell,
  CheckCircle,
  Link2
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface TemplatePreviewProps {
  template: any;
  isOpen: boolean;
  onClose: () => void;
  onPurchase: (template: any, tier?: any) => void;
  onImport: (template: any) => void;
}
export function TemplatePreview({ template, isOpen, onClose, onPurchase, onImport }: TemplatePreviewProps) {
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [deviceView, setDeviceView] = useState<'desktop' | 'mobile'>('desktop');
  const [isFavorite, setIsFavorite] = useState(false);
  const [hasUpdate, setHasUpdate] = useState(false);
  const [currentVersion, setCurrentVersion] = useState<any>(null);
  const [licenseTiers, setLicenseTiers] = useState<any[]>([]);
  const [selectedTier, setSelectedTier] = useState<string>('');
  const { toast } = useToast();

  useEffect(() => {
    if (template) {
      checkForUpdates();
      loadLicenseTiers();
    }
  }, [template]);

  const loadLicenseTiers = async () => {
    if (!template || template.price === 0) return;

    const { data: tiers } = await supabase
      .from('license_tiers')
      .select('*')
      .eq('template_id', template.id)
      .order('price', { ascending: true });

    if (tiers && tiers.length > 0) {
      setLicenseTiers(tiers);
      setSelectedTier(tiers[0].id);
    }
  };

  const checkForUpdates = async () => {
    if (!template) return;
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    // Check if user has purchased this template
    const { data: purchase } = await supabase
      .from('template_purchases')
      .select('*, template_versions(*)')
      .eq('template_id', template.id)
      .eq('user_id', user.id)
      .single();

    if (purchase) {
      // Get current version
      const { data: latestVersion } = await supabase
        .from('template_versions')
        .select('*')
        .eq('template_id', template.id)
        .eq('is_current', true)
        .single();

      if (latestVersion && purchase.installed_version_id !== latestVersion.id) {
        setHasUpdate(true);
        setCurrentVersion(latestVersion);
      }
    }
  };

  const handleRating = async () => {
    if (rating === 0) return;
    try {
      await supabase.from('marketplace_reviews').insert({
        template_id: template.id,
        rating,
        review_text: review
      });

      toast({
        title: 'Review submitted',
        description: 'Thank you for your feedback!'
      });
      setRating(0);
      setReview('');
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to submit review',
        variant: 'destructive'
      });
    }
  };

  const handleShare = () => {
    const url = `${window.location.origin}/marketplace/template/${template.id}`;
    navigator.clipboard.writeText(url);
    toast({
      title: 'Link copied',
      description: 'Template link copied to clipboard'
    });
  };

  const handleImport = () => {
    onImport(template);
    toast({
      title: 'Template imported',
      description: 'Template has been added to your library'
    });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex justify-between items-start">
            <div>
              <DialogTitle className="text-2xl">{template?.title}</DialogTitle>
              <p className="text-muted-foreground mt-2">{template?.description}</p>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between border-b pb-4">
              <div className="flex gap-2">
                <Button
                  variant={deviceView === 'desktop' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setDeviceView('desktop')}
                >
                  <Monitor className="h-4 w-4 mr-2" />
                  Desktop
                </Button>
                <Button
                  variant={deviceView === 'mobile' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setDeviceView('mobile')}
                >
                  <Smartphone className="h-4 w-4 mr-2" />
                  Mobile
                </Button>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setIsFavorite(!isFavorite)}
                >
                  <Heart className={`h-4 w-4 ${isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
                </Button>
                <Button variant="outline" size="icon" onClick={handleShare}>
                  <Share2 className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className={`border rounded-lg overflow-hidden ${deviceView === 'mobile' ? 'max-w-sm mx-auto' : ''}`}>
              <iframe
                src={`data:text/html;charset=utf-8,${encodeURIComponent(template?.preview_html || '<div style="padding: 40px; text-align: center; font-family: sans-serif;"><h1>Email Template Preview</h1><p>Your beautiful email content goes here</p></div>')}`}
                className="w-full h-[600px] bg-white"
                title="Template Preview"
              />
            </div>

            <Tabs defaultValue="reviews" className="w-full">
              <TabsList>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="code">HTML Code</TabsTrigger>
              </TabsList>

              <TabsContent value="reviews" className="space-y-4">
                <div className="border rounded-lg p-4">
                  <h3 className="font-semibold mb-3">Write a Review</h3>
                  <div className="flex gap-1 mb-3">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => setRating(star)}
                        className="p-1"
                      >
                        <Star className={`h-5 w-5 ${star <= rating ? 'fill-yellow-500 text-yellow-500' : 'text-gray-300'}`} />
                      </button>
                    ))}
                  </div>
                  <Textarea
                    placeholder="Share your experience with this template..."
                    value={review}
                    onChange={(e) => setReview(e.target.value)}
                    className="mb-3"
                  />
                  <Button onClick={handleRating} disabled={rating === 0}>
                    Submit Review
                  </Button>
                </div>

                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="border rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <Avatar>
                          <AvatarFallback>U{i}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-semibold">User {i}</p>
                              <div className="flex gap-1 mt-1">
                                {Array.from({ length: 5 }).map((_, j) => (
                                  <Star key={j} className={`h-4 w-4 ${j < 5 - i ? 'fill-yellow-500 text-yellow-500' : 'text-gray-300'}`} />
                                ))}
                              </div>
                            </div>
                            <span className="text-sm text-muted-foreground">{i} days ago</span>
                          </div>
                          <p className="mt-2 text-sm">Great template! Easy to customize and looks professional.</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="details">
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Category</p>
                      <p className="font-semibold">{template?.category}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Downloads</p>
                      <p className="font-semibold">{template?.downloads || 0}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Last Updated</p>
                      <p className="font-semibold">2 weeks ago</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Support</p>
                      <p className="font-semibold">6 months included</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Tags</p>
                    <div className="flex flex-wrap gap-2">
                      {template?.tags?.map((tag: string) => (
                        <Badge key={tag} variant="secondary">{tag}</Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="code">
                <div className="bg-muted rounded-lg p-4">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-sm font-mono">HTML</span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        navigator.clipboard.writeText(template?.preview_html || '');
                        toast({ title: 'Code copied to clipboard' });
                      }}
                    >
                      <Code className="h-4 w-4 mr-2" />
                      Copy Code
                    </Button>
                  </div>
                  <pre className="text-sm overflow-x-auto">
                    <code>{template?.preview_html || '<!-- Template HTML -->'}</code>
                  </pre>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          <div className="space-y-4">
            {hasUpdate && (
              <Alert className="border-blue-200 bg-blue-50">
                <Bell className="h-4 w-4 text-blue-600" />
                <AlertDescription>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-blue-900">Update Available!</p>
                      <p className="text-sm text-blue-700">Version {currentVersion?.version_number} is now available</p>
                    </div>
                    <Button size="sm" variant="outline" className="ml-4">
                      Update Now
                    </Button>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            <div className="border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-3xl font-bold">
                    {template?.price === 0 ? 'Free' : `$${template?.price}`}
                  </p>
                  {template?.price > 0 && (
                    <p className="text-sm text-muted-foreground">One-time purchase</p>
                  )}
                </div>
                <div className="flex items-center gap-1">
                  <Star className="h-5 w-5 fill-yellow-500 text-yellow-500" />
                  <span className="font-semibold">{template?.rating?.toFixed(1) || '0.0'}</span>
                  <span className="text-sm text-muted-foreground">({template?.total_ratings || 0})</span>
                </div>
              </div>

              <div className="flex items-center gap-2 mb-4">
                <Badge variant="outline" className="text-xs">
                  <GitBranch className="h-3 w-3 mr-1" />
                  v{template?.current_version || '1.0.0'}
                </Badge>
                {template?.auto_update_enabled && (
                  <Badge variant="secondary" className="text-xs">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Auto-updates enabled
                  </Badge>
                )}
              </div>

              {licenseTiers.length > 0 && (
                <div className="mb-4">
                  <label className="text-sm font-medium mb-2 block">Select License</label>
                  <Select value={selectedTier} onValueChange={setSelectedTier}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {licenseTiers.map((tier) => (
                        <SelectItem key={tier.id} value={tier.id}>
                          <div className="flex items-center justify-between w-full">
                            <span>{tier.name}</span>
                            <span className="ml-2 font-bold">${tier.price}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {licenseTiers.find(t => t.id === selectedTier) && (
                    <div className="mt-2 text-xs text-muted-foreground">
                      {licenseTiers.find(t => t.id === selectedTier)?.description}
                    </div>
                  )}
                </div>
              )}

              {template?.price === 0 ? (
                <Button className="w-full" size="lg" onClick={handleImport}>
                  <Download className="h-4 w-4 mr-2" />
                  Import Template
                </Button>
              ) : (
                <Button className="w-full" size="lg" onClick={() => onPurchase(template)}>
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Purchase Template
                </Button>
              )}

              <div className="mt-4 space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Eye className="h-4 w-4 text-muted-foreground" />
                  <span>Instant download after purchase</span>
                </div>
                <div className="flex items-center gap-2">
                  <Code className="h-4 w-4 text-muted-foreground" />
                  <span>Full HTML/CSS code included</span>
                </div>
                <div className="flex items-center gap-2">
                  <Star className="h-4 w-4 text-muted-foreground" />
                  <span>Free updates for 6 months</span>
                </div>
                <div className="flex items-center gap-2">
                  <GitBranch className="h-4 w-4 text-muted-foreground" />
                  <span>Version history & rollback</span>
                </div>
              </div>
            </div>

            <div className="border rounded-lg p-4">
              <div className="flex items-center gap-3 mb-3">
                <Avatar>
                  <AvatarFallback>CR</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold">Creator Name</p>
                  <p className="text-sm text-muted-foreground">50+ templates</p>
                </div>
              </div>
              <Button variant="outline" className="w-full">
                View Creator Profile
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}