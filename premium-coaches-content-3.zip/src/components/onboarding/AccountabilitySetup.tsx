import React, { useState } from 'react';
import { Check, Clock, Target, Calendar } from 'lucide-react';

interface AccountabilitySetupProps {
  onComplete: (data: {
    postingGoal: number;
    contentTypes: string[];
    checkinTime: string;
  }) => void;
  onBack: () => void;
}

const CONTENT_TYPES = [
  'Reels',
  'Carousels',
  'Stories',
  'Posts',
  'Email',
  'TikTok',
  'YouTube Shorts',
  'Blog Posts'
];

const AccountabilitySetup: React.FC<AccountabilitySetupProps> = ({ onComplete, onBack }) => {
  const [postingGoal, setPostingGoal] = useState(5);
  const [contentTypes, setContentTypes] = useState<string[]>(['Reels', 'Carousels']);
  const [checkinTime, setCheckinTime] = useState('09:00');

  const toggleContentType = (type: string) => {
    setContentTypes(prev =>
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  const handleSubmit = () => {
    onComplete({ postingGoal, contentTypes, checkinTime });
  };

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Target className="w-5 h-5 text-olive-600" />
          <h3 className="text-lg font-bold">Weekly Posting Goal</h3>
        </div>
        <p className="text-sm text-gray-600 mb-4">How many pieces of content do you want to create per week?</p>
        <div className="flex items-center gap-4">
          <input
            type="range"
            min="1"
            max="21"
            value={postingGoal}
            onChange={(e) => setPostingGoal(Number(e.target.value))}
            className="flex-1"
          />
          <span className="text-2xl font-bold text-olive-600 w-16">{postingGoal}</span>
        </div>
      </div>

      <div>
        <div className="flex items-center gap-2 mb-3">
          <Calendar className="w-5 h-5 text-olive-600" />
          <h3 className="text-lg font-bold">Preferred Content Types</h3>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {CONTENT_TYPES.map(type => (
            <button
              key={type}
              onClick={() => toggleContentType(type)}
              className={`p-3 rounded-lg border-2 transition-all ${
                contentTypes.includes(type)
                  ? 'border-olive-600 bg-olive-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">{type}</span>
                {contentTypes.includes(type) && <Check className="w-4 h-4 text-olive-600" />}
              </div>
            </button>
          ))}
        </div>
      </div>

      <div>
        <div className="flex items-center gap-2 mb-3">
          <Clock className="w-5 h-5 text-olive-600" />
          <h3 className="text-lg font-bold">Daily Check-in Time</h3>
        </div>
        <input
          type="time"
          value={checkinTime}
          onChange={(e) => setCheckinTime(e.target.value)}
          className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-olive-600 focus:outline-none"
        />
      </div>

      <div className="flex justify-between pt-4">
        <button
          onClick={onBack}
          className="px-6 py-3 bg-gray-200 text-gray-700 rounded-lg font-medium hover:bg-gray-300"
        >
          Back
        </button>
        <button
          onClick={handleSubmit}
          disabled={contentTypes.length === 0}
          className="px-6 py-3 bg-gradient-to-r from-yellow-600 to-olive-600 text-white rounded-lg font-medium hover:shadow-lg disabled:opacity-50"
        >
          Complete Setup
        </button>
      </div>
    </div>
  );
};

export default AccountabilitySetup;
