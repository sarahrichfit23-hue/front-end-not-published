import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import {
  TrendingUp, DollarSign, MousePointer, Users,
  Link, BarChart3, Download, Copy, Share2
} from 'lucide-react';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';

export function AffiliateDashboard() {
  const [program, setProgram] = useState<any>(null);
  const [metrics, setMetrics] = useState<any>(null);
  const [links, setLinks] = useState<any[]>([]);
  const [commissions, setCommissions] = useState<any[]>([]);
  const [performanceData, setPerformanceData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadAffiliateData();
  }, []);

  const loadAffiliateData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Get or create affiliate program
      let { data: program } = await supabase
        .from('affiliate_programs')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (!program) {
        const affiliateCode = generateAffiliateCode();
        const { data: newProgram } = await supabase
          .from('affiliate_programs')
          .insert({ user_id: user.id, affiliate_code: affiliateCode })
          .select()
          .single();
        program = newProgram;
      }

      setProgram(program);

      // Load affiliate data
      const [linksRes, commissionsRes, metricsRes] = await Promise.all([
        supabase.from('affiliate_links').select('*').eq('affiliate_id', program.id),
        supabase.from('affiliate_commissions').select('*').eq('affiliate_id', program.id),
        supabase.from('affiliate_performance_metrics')
          .select('*')
          .eq('affiliate_id', program.id)
          .order('date', { ascending: false })
          .limit(30)
      ]);

      setLinks(linksRes.data || []);
      setCommissions(commissionsRes.data || []);
      setPerformanceData(metricsRes.data || []);

      // Calculate current metrics
      const today = new Date().toISOString().split('T')[0];
      const todayMetrics = metricsRes.data?.find(m => m.date === today);
      setMetrics(todayMetrics || {
        clicks: 0,
        conversions: 0,
        revenue: 0,
        commission_earned: 0
      });

      setLoading(false);
    } catch (error) {
      console.error('Error loading affiliate data:', error);
      toast({
        title: 'Error',
        description: 'Failed to load affiliate data',
        variant: 'destructive'
      });
    }
  };

  const generateAffiliateCode = () => {
    return 'AFF' + Math.random().toString(36).substr(2, 9).toUpperCase();
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: 'Copied!',
      description: 'Link copied to clipboard'
    });
  };

  const getTierColor = (tier: string) => {
    const colors: any = {
      bronze: 'bg-orange-500',
      silver: 'bg-gray-400',
      gold: 'bg-yellow-500',
      platinum: 'bg-purple-500'
    };
    return colors[tier] || 'bg-gray-500';
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Affiliate Dashboard</h1>
          <p className="text-muted-foreground">
            Your affiliate code: <Badge>{program?.affiliate_code}</Badge>
          </p>
        </div>
        <Badge className={getTierColor(program?.tier)}>
          {program?.tier?.toUpperCase()} TIER
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Earnings</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${program?.total_earnings || 0}</div>
            <p className="text-xs text-muted-foreground">
              {program?.commission_rate}% commission rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Clicks</CardTitle>
            <MousePointer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{program?.total_clicks || 0}</div>
            <p className="text-xs text-muted-foreground">
              {metrics?.clicks || 0} today
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Conversions</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{program?.total_conversions || 0}</div>
            <p className="text-xs text-muted-foreground">
              {program?.conversion_rate?.toFixed(2) || 0}% rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pending Payout</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${commissions.filter(c => c.status === 'approved').reduce((sum, c) => sum + c.total_amount, 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              Threshold: ${program?.payment_threshold}
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="links">Links</TabsTrigger>
          <TabsTrigger value="commissions">Commissions</TabsTrigger>
          <TabsTrigger value="materials">Materials</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Performance Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="clicks" stroke="#8884d8" name="Clicks" />
                  <Line type="monotone" dataKey="conversions" stroke="#82ca9d" name="Conversions" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="links" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Your Affiliate Links</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {links.map((link) => (
                  <div key={link.id} className="flex items-center justify-between p-2 border rounded">
                    <div>
                      <p className="font-medium">{link.campaign_name || 'Default Campaign'}</p>
                      <p className="text-sm text-muted-foreground">{link.destination_url}</p>
                    </div>
                    <div className="flex gap-2">
                      <Badge variant="outline">
                        {link.click_count} clicks
                      </Badge>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(window.location.origin + link.destination_url)}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}