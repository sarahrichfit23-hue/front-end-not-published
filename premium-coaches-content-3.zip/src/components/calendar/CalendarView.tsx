import { useState, useEffect } from 'react';
import { Calendar, dateFnsLocalizer } from 'react-big-calendar';
import { format, parse, startOfWeek, getDay } from 'date-fns';
import { enUS } from 'date-fns/locale';
import { supabase } from '@/lib/supabase';
import { EventModal } from './EventModal';
import { Button } from '@/components/ui/button';
import { Plus, Video, Calendar as CalIcon } from 'lucide-react';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { toast } from 'sonner';

const locales = { 'en-US': enUS };
const localizer = dateFnsLocalizer({ format, parse, startOfWeek, getDay, locales });

export function CalendarView() {
  const [events, setEvents] = useState<any[]>([]);
  const [view, setView] = useState<'month' | 'week' | 'day'>('month');
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  const [selectedDate, setSelectedDate] = useState<Date>();

  useEffect(() => {
    loadEvents();
  }, []);

  const loadEvents = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data, error } = await supabase
      .from('calendar_events')
      .select('*')
      .eq('user_id', user.id)
      .order('start_time', { ascending: true });

    if (data) {
      const formattedEvents = data.map(e => ({
        id: e.id,
        title: e.title,
        start: new Date(e.start_time),
        end: new Date(e.end_time),
        extendedProps: e
      }));
      setEvents(formattedEvents);
    }
  };

  const handleSelectSlot = ({ start }: any) => {
    setSelectedDate(start);
    setSelectedEvent(null);
    setModalOpen(true);
  };

  const handleSelectEvent = (event: any) => {
    setSelectedEvent(event);
    setModalOpen(true);
  };

  const createZoomMeeting = async () => {
    try {
      const { data } = await supabase.functions.invoke('create-zoom-meeting', {
        body: { topic: 'Coaching Call', duration: 60 }
      });
      toast.success('Zoom link created!');
      navigator.clipboard.writeText(data.join_url);
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <div className="flex gap-2">
          <Button onClick={() => setView('month')} variant={view === 'month' ? 'default' : 'outline'}>Month</Button>
          <Button onClick={() => setView('week')} variant={view === 'week' ? 'default' : 'outline'}>Week</Button>
          <Button onClick={() => setView('day')} variant={view === 'day' ? 'default' : 'outline'}>Day</Button>
        </div>
        <div className="flex gap-2">
          <Button onClick={createZoomMeeting} variant="outline"><Video className="w-4 h-4 mr-2" />Create Zoom</Button>
          <Button onClick={() => { setSelectedEvent(null); setModalOpen(true); }}><Plus className="w-4 h-4 mr-2" />New Event</Button>
        </div>
      </div>
      <div className="flex-1 bg-white rounded-lg p-4">
        <Calendar
          localizer={localizer}
          events={events}
          startAccessor="start"
          endAccessor="end"
          view={view}
          onView={setView}
          onSelectSlot={handleSelectSlot}
          onSelectEvent={handleSelectEvent}
          selectable
          style={{ height: '100%' }}
        />
      </div>
      <EventModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        onSave={loadEvents}
        event={selectedEvent}
        selectedDate={selectedDate}
      />
    </div>
  );
}
