import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, CheckCircle2, XCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

export function GoogleCalendarConnect() {
  const [connected, setConnected] = useState(false);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    checkConnection();
  }, []);

  const checkConnection = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from('google_calendar_connections')
      .select('*')
      .eq('user_id', user.id)
      .single();

    setConnected(!!data);
  };

  const handleConnect = async () => {
    // In production, this would initiate OAuth flow
    // For now, we'll simulate a connection
    toast.info('Google Calendar OAuth flow would start here. In production, this connects to Google.');
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    // Simulate storing connection
    await supabase.from('google_calendar_connections').upsert({
      user_id: user.id,
      access_token: 'mock_token',
      refresh_token: 'mock_refresh',
      token_expiry: new Date(Date.now() + 3600000).toISOString(),
      sync_enabled: true
    });

    setConnected(true);
    toast.success('Connected to Google Calendar!');
  };

  const handleSync = async () => {
    setSyncing(true);
    try {
      const { data, error } = await supabase.functions.invoke('sync-google-calendar', {
        body: { action: 'sync' }
      });
      
      if (error) throw error;
      toast.success('Calendar synced!');
    } catch (error: any) {
      toast.error('Sync requires full OAuth setup');
    } finally {
      setSyncing(false);
    }
  };

  const handleDisconnect = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase
      .from('google_calendar_connections')
      .delete()
      .eq('user_id', user.id);

    setConnected(false);
    toast.success('Disconnected from Google Calendar');
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Calendar className="w-8 h-8 text-blue-600" />
          <div>
            <h3 className="font-semibold">Google Calendar</h3>
            <p className="text-sm text-gray-600">Sync events automatically</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {connected ? (
            <>
              <Badge variant="default" className="gap-1">
                <CheckCircle2 className="w-3 h-3" /> Connected
              </Badge>
              <Button onClick={handleSync} disabled={syncing} variant="outline" size="sm">
                {syncing ? 'Syncing...' : 'Sync Now'}
              </Button>
              <Button onClick={handleDisconnect} variant="ghost" size="sm">
                Disconnect
              </Button>
            </>
          ) : (
            <>
              <Badge variant="secondary" className="gap-1">
                <XCircle className="w-3 h-3" /> Not Connected
              </Badge>
              <Button onClick={handleConnect}>Connect</Button>
            </>
          )}
        </div>
      </div>
    </Card>
  );
}
