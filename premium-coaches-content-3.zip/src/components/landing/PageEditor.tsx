import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Type, Image, FileText, Layout, Video, Users, 
  Clock, Star, List, ChevronUp, ChevronDown, Trash2,
  Copy, Eye, Save, Smartphone, Monitor, Settings, GripVertical
} from 'lucide-react';

interface PageSection {
  id: string;
  type: string;
  data: any;
}

interface PageEditorProps {
  page: any;
  onSave: (pageData: any) => void;
  onPreview: () => void;
}

const SECTION_TYPES = [
  { type: 'hero', label: 'Hero Section', icon: Layout },
  { type: 'form', label: 'Opt-in Form', icon: FileText },
  { type: 'text', label: 'Text Block', icon: Type },
  { type: 'image', label: 'Image', icon: Image },
  { type: 'video', label: 'Video', icon: Video },
  { type: 'bullets', label: 'Bullet Points', icon: List },
  { type: 'countdown', label: 'Countdown Timer', icon: Clock },
  { type: 'testimonials', label: 'Testimonials', icon: Star },
  { type: 'presenter', label: 'Presenter Bio', icon: Users },
];

const SectionEditor = ({ section, onUpdate, onDelete, onMoveUp, onMoveDown, canMoveUp, canMoveDown }: any) => {
  const renderEditor = () => {
    switch (section.type) {
      case 'hero':
        return (
          <div className="space-y-3">
            <Input
              placeholder="Headline"
              value={section.data.headline || ''}
              onChange={(e) => onUpdate({ ...section.data, headline: e.target.value })}
            />
            <Input
              placeholder="Subheadline"
              value={section.data.subheadline || ''}
              onChange={(e) => onUpdate({ ...section.data, subheadline: e.target.value })}
            />
            <Input
              placeholder="Background Color"
              type="color"
              value={section.data.backgroundColor || '#1e40af'}
              onChange={(e) => onUpdate({ ...section.data, backgroundColor: e.target.value })}
            />
          </div>
        );
      case 'form':
        return (
          <div className="space-y-3">
            <Input
              placeholder="Button Text"
              value={section.data.buttonText || ''}
              onChange={(e) => onUpdate({ ...section.data, buttonText: e.target.value })}
            />
            <Input
              placeholder="Privacy Text"
              value={section.data.privacyText || ''}
              onChange={(e) => onUpdate({ ...section.data, privacyText: e.target.value })}
            />
          </div>
        );
      case 'text':
        return (
          <Textarea
            placeholder="Enter your text content..."
            value={section.data.content || ''}
            onChange={(e) => onUpdate({ ...section.data, content: e.target.value })}
            rows={4}
          />
        );
      default:
        return <p className="text-sm text-gray-500">Configure {section.type} section</p>;
    }
  };

  return (
    <Card className="p-4">
      <div className="flex justify-between items-start mb-3">
        <div className="flex items-center gap-2">
          <GripVertical className="h-4 w-4 text-gray-400" />
          <h4 className="font-medium capitalize">{section.type} Section</h4>
        </div>
        <div className="flex gap-1">
          <Button
            size="sm"
            variant="ghost"
            onClick={onMoveUp}
            disabled={!canMoveUp}
          >
            <ChevronUp className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={onMoveDown}
            disabled={!canMoveDown}
          >
            <ChevronDown className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={onDelete}
            className="text-red-500"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
      {renderEditor()}
    </Card>
  );
};

export function PageEditor({ page, onSave, onPreview }: PageEditorProps) {
  const [sections, setSections] = useState<PageSection[]>(
    page?.page_data?.sections || []
  );
  const [deviceView, setDeviceView] = useState<'desktop' | 'mobile'>('desktop');

  const handleAddSection = (type: string) => {
    const newSection: PageSection = {
      id: `section-${Date.now()}`,
      type,
      data: {},
    };
    setSections([...sections, newSection]);
  };

  const handleUpdateSection = (id: string, data: any) => {
    setSections(sections.map(s => s.id === id ? { ...s, data } : s));
  };

  const handleDeleteSection = (id: string) => {
    setSections(sections.filter(s => s.id !== id));
  };

  const handleMoveSection = (from: number, to: number) => {
    if (to < 0 || to >= sections.length) return;
    const newSections = [...sections];
    const [moved] = newSections.splice(from, 1);
    newSections.splice(to, 0, moved);
    setSections(newSections);
  };

  const handleSave = () => {
    onSave({
      ...page,
      page_data: { sections },
    });
  };

  return (
    <div className="flex h-[calc(100vh-200px)]">
      <div className="w-64 border-r p-4 overflow-y-auto">
        <h3 className="font-semibold mb-4">Page Elements</h3>
        <div className="space-y-2">
          {SECTION_TYPES.map((type) => (
            <Button
              key={type.type}
              variant="outline"
              className="w-full justify-start"
              onClick={() => handleAddSection(type.type)}
            >
              <type.icon className="h-4 w-4 mr-2" />
              {type.label}
            </Button>
          ))}
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        <div className="border-b p-4 flex justify-between items-center">
          <div className="flex gap-2">
            <Button
              variant={deviceView === 'desktop' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setDeviceView('desktop')}
            >
              <Monitor className="h-4 w-4" />
            </Button>
            <Button
              variant={deviceView === 'mobile' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setDeviceView('mobile')}
            >
              <Smartphone className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onPreview}>
              <Eye className="mr-2 h-4 w-4" />
              Preview
            </Button>
            <Button onClick={handleSave}>
              <Save className="mr-2 h-4 w-4" />
              Save
            </Button>
          </div>
        </div>

        <div className={`flex-1 p-4 overflow-y-auto ${
          deviceView === 'mobile' ? 'max-w-sm mx-auto' : ''
        }`}>
          {sections.length === 0 ? (
            <div className="border-2 border-dashed rounded-lg p-12 text-center text-gray-400">
              <Layout className="h-12 w-12 mx-auto mb-2" />
              <p>Click elements on the left to start building</p>
            </div>
          ) : (
            <div className="space-y-4">
              {sections.map((section: PageSection, index: number) => (
                <SectionEditor
                  key={section.id}
                  section={section}
                  onUpdate={(data) => handleUpdateSection(section.id, data)}
                  onDelete={() => handleDeleteSection(section.id)}
                  onMoveUp={() => handleMoveSection(index, index - 1)}
                  onMoveDown={() => handleMoveSection(index, index + 1)}
                  canMoveUp={index > 0}
                  canMoveDown={index < sections.length - 1}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="w-80 border-l p-4">
        <Tabs defaultValue="settings">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="settings">Settings</TabsTrigger>
            <TabsTrigger value="seo">SEO</TabsTrigger>
          </TabsList>
          <TabsContent value="settings" className="space-y-4">
            <div>
              <label className="text-sm font-medium">Page Name</label>
              <Input value={page?.name || ''} placeholder="My Landing Page" />
            </div>
            <div>
              <label className="text-sm font-medium">URL Slug</label>
              <Input value={page?.slug || ''} placeholder="my-page" />
            </div>
            <div>
              <label className="text-sm font-medium">Custom Domain</label>
              <Input value={page?.custom_domain || ''} placeholder="custom.domain.com" />
            </div>
          </TabsContent>
          <TabsContent value="seo" className="space-y-4">
            <div>
              <label className="text-sm font-medium">Meta Title</label>
              <Input placeholder="Page title for search engines" />
            </div>
            <div>
              <label className="text-sm font-medium">Meta Description</label>
              <Textarea placeholder="Page description for search engines" rows={3} />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}