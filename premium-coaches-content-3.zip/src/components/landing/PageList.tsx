import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Eye, Edit, Copy, Trash2, Globe, BarChart3 } from 'lucide-react';

interface PageListProps {
  pages: any[];
  onSelectPage: (page: any) => void;
  onPublish: (pageId: string) => void;
  onDuplicate: (pageId: string) => void;
  onDelete: (pageId: string) => void;
}

export function PageList({ pages, onSelectPage, onPublish, onDuplicate, onDelete }: PageListProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'published': return 'bg-green-100 text-green-800';
      case 'draft': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {pages.map(page => (
        <Card key={page.id} className="p-6">
          <div className="flex justify-between items-start mb-4">
            <h3 className="font-semibold text-lg">{page.name}</h3>
            <Badge className={getStatusColor(page.status)}>
              {page.status}
            </Badge>
          </div>
          
          <p className="text-sm text-gray-600 mb-4">
            /{page.slug}
          </p>

          {page.custom_domain && (
            <p className="text-sm text-blue-600 mb-4 flex items-center">
              <Globe className="h-3 w-3 mr-1" />
              {page.custom_domain}
            </p>
          )}

          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => onSelectPage(page)}
            >
              <Edit className="h-4 w-4" />
            </Button>
            
            {page.status === 'published' ? (
              <Button
                size="sm"
                variant="outline"
                onClick={() => window.open(`/landing/${page.slug}`, '_blank')}
              >
                <Eye className="h-4 w-4" />
              </Button>
            ) : (
              <Button
                size="sm"
                onClick={() => onPublish(page.id)}
              >
                <Globe className="h-4 w-4" />
              </Button>
            )}
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => onDuplicate(page.id)}
            >
              <Copy className="h-4 w-4" />
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              className="text-red-500"
              onClick={() => onDelete(page.id)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>

          <div className="mt-4 pt-4 border-t text-xs text-gray-500">
            Created {new Date(page.created_at).toLocaleDateString()}
          </div>
        </Card>
      ))}

      {pages.length === 0 && (
        <div className="col-span-full text-center py-12">
          <p className="text-gray-500">No pages yet. Create your first landing page!</p>
        </div>
      )}
    </div>
  );
}