import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { PageEditor } from './PageEditor';
import { TemplateGallery } from './TemplateGallery';
import { PageAnalytics } from './PageAnalytics';
import { PageList } from './PageList';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { Plus, BarChart3, Layout, Settings } from 'lucide-react';

export function LandingPageBuilder() {
  const [pages, setPages] = useState<any[]>([]);
  const [selectedPage, setSelectedPage] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('pages');
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchPages();
  }, []);

  const fetchPages = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('landing_pages')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPages(data || []);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const createNewPage = async (template?: any) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const newPage = {
        user_id: user.id,
        name: template ? `${template.name} Page` : 'New Landing Page',
        slug: `page-${Date.now()}`,
        template_id: template?.id,
        page_data: template ? template.template_data : { sections: [] },
        status: 'draft'
      };

      const { data, error } = await supabase
        .from('landing_pages')
        .insert(newPage)
        .select()
        .single();

      if (error) throw error;

      setPages([data, ...pages]);
      setSelectedPage(data);
      setActiveTab('editor');

      toast({
        title: 'Success',
        description: 'New page created',
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  const savePage = async (pageData: any) => {
    try {
      const { data, error } = await supabase
        .from('landing_pages')
        .update({
          page_data: pageData.page_data,
          updated_at: new Date().toISOString()
        })
        .eq('id', pageData.id)
        .select()
        .single();

      if (error) throw error;

      setPages(pages.map(p => p.id === data.id ? data : p));
      setSelectedPage(data);

      toast({
        title: 'Success',
        description: 'Page saved successfully',
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  const publishPage = async (pageId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('publish-landing-page', {
        body: { pageId, action: 'publish' }
      });

      if (error) throw error;

      await fetchPages();
      
      toast({
        title: 'Success',
        description: 'Page published successfully',
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="container mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Landing Page Builder</h1>
        <p className="text-gray-600">Create high-converting landing pages with drag-and-drop</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4 max-w-2xl">
          <TabsTrigger value="pages">
            <Layout className="mr-2 h-4 w-4" />
            My Pages
          </TabsTrigger>
          <TabsTrigger value="templates">
            <Plus className="mr-2 h-4 w-4" />
            Templates
          </TabsTrigger>
          <TabsTrigger value="editor" disabled={!selectedPage}>
            <Settings className="mr-2 h-4 w-4" />
            Editor
          </TabsTrigger>
          <TabsTrigger value="analytics" disabled={!selectedPage}>
            <BarChart3 className="mr-2 h-4 w-4" />
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pages" className="mt-6">
          <PageList
            pages={pages}
            onSelectPage={(page) => {
              setSelectedPage(page);
              setActiveTab('editor');
            }}
            onPublish={publishPage}
            onDuplicate={async (pageId) => {
              const { data } = await supabase.functions.invoke('publish-landing-page', {
                body: { pageId, action: 'duplicate' }
              });
              if (data?.page) {
                await fetchPages();
                toast({ title: 'Page duplicated' });
              }
            }}
            onDelete={async (pageId) => {
              await supabase.from('landing_pages').delete().eq('id', pageId);
              await fetchPages();
              toast({ title: 'Page deleted' });
            }}
          />
        </TabsContent>

        <TabsContent value="templates" className="mt-6">
          <TemplateGallery onSelectTemplate={createNewPage} />
        </TabsContent>

        <TabsContent value="editor" className="mt-6">
          {selectedPage && (
            <PageEditor
              page={selectedPage}
              onSave={savePage}
              onPreview={() => {
                window.open(`/preview/${selectedPage.slug}`, '_blank');
              }}
            />
          )}
        </TabsContent>

        <TabsContent value="analytics" className="mt-6">
          {selectedPage && <PageAnalytics pageId={selectedPage.id} />}
        </TabsContent>
      </Tabs>
    </div>
  );
}