import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Share2, Twitter, Facebook, Linkedin, Copy } from 'lucide-react';
import { toast } from 'sonner';

interface SocialShareProps {
  badgeName: string;
  badgeDescription: string;
}

export function SocialShare({ badgeName, badgeDescription }: SocialShareProps) {
  const shareText = `🎉 I just earned the "${badgeName}" badge on Content to Cash Club™! ${badgeDescription} Join me in building consistent content habits! #ContentToClub #ContentCreation`;
  const shareUrl = 'https://contenttocashclub.com';

  const copyToClipboard = () => {
    navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
    toast.success('Copied to clipboard!');
  };

  const shareToTwitter = () => {
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
    window.open(url, '_blank');
  };

  const shareToFacebook = () => {
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`;
    window.open(url, '_blank');
  };

  const shareToLinkedIn = () => {
    const url = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`;
    window.open(url, '_blank');
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline">
          <Share2 className="w-4 h-4 mr-2" />
          Share
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Share Your Achievement!</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="p-4 bg-muted rounded-lg">
            <p className="text-sm">{shareText}</p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Button onClick={shareToTwitter} variant="outline" className="w-full">
              <Twitter className="w-4 h-4 mr-2" />
              Twitter
            </Button>
            <Button onClick={shareToFacebook} variant="outline" className="w-full">
              <Facebook className="w-4 h-4 mr-2" />
              Facebook
            </Button>
            <Button onClick={shareToLinkedIn} variant="outline" className="w-full">
              <Linkedin className="w-4 h-4 mr-2" />
              LinkedIn
            </Button>
            <Button onClick={copyToClipboard} variant="outline" className="w-full">
              <Copy className="w-4 h-4 mr-2" />
              Copy
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
