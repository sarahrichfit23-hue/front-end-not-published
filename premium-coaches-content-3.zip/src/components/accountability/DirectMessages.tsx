import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send, Sparkles } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const QUICK_MESSAGES = [
  '🔥 Keep going!',
  '💪 You got this!',
  '⭐ Amazing progress!',
  '🎉 Way to go!',
  '👏 Keep up the great work!'
];

export default function DirectMessages({ buddyId, buddyName }: { buddyId: string; buddyName: string }) {
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [currentUserId, setCurrentUserId] = useState<string>('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadMessages();
    const channel = supabase
      .channel('buddy-messages')
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'buddy_messages',
        filter: `sender_id=eq.${buddyId},receiver_id=eq.${currentUserId}`
      }, () => loadMessages())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [buddyId]);

  const loadMessages = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    setCurrentUserId(user.id);

    const { data } = await supabase
      .from('buddy_messages')
      .select('*')
      .or(`and(sender_id.eq.${user.id},receiver_id.eq.${buddyId}),and(sender_id.eq.${buddyId},receiver_id.eq.${user.id})`)
      .order('created_at', { ascending: true });

    if (data) {
      setMessages(data);
      markAsRead(user.id);
      setTimeout(() => scrollRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    }
  };

  const markAsRead = async (userId: string) => {
    await supabase
      .from('buddy_messages')
      .update({ read_at: new Date().toISOString() })
      .eq('receiver_id', userId)
      .eq('sender_id', buddyId)
      .is('read_at', null);
  };

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;
    const { error } = await supabase.from('buddy_messages').insert({
      sender_id: currentUserId,
      receiver_id: buddyId,
      message: text.trim()
    });
    if (error) toast({ title: 'Error', description: 'Failed to send message', variant: 'destructive' });
    else setNewMessage('');
  };

  return (
    <Card className="p-4 h-[500px] flex flex-col">
      <h3 className="font-semibold mb-4">Chat with {buddyName}</h3>
      <ScrollArea className="flex-1 pr-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`mb-3 ${msg.sender_id === currentUserId ? 'text-right' : ''}`}>
            <div className={`inline-block px-4 py-2 rounded-lg ${
              msg.sender_id === currentUserId 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-900'
            }`}>
              {msg.message}
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {new Date(msg.created_at).toLocaleTimeString()}
              {msg.sender_id === currentUserId && msg.read_at && ' ✓✓'}
            </div>
          </div>
        ))}
        <div ref={scrollRef} />
      </ScrollArea>
      <div className="flex flex-wrap gap-2 my-3">
        {QUICK_MESSAGES.map((msg) => (
          <Button key={msg} size="sm" variant="outline" onClick={() => sendMessage(msg)}>
            <Sparkles className="w-3 h-3 mr-1" />
            {msg}
          </Button>
        ))}
      </div>
      <div className="flex gap-2">
        <Input value={newMessage} onChange={(e) => setNewMessage(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && sendMessage(newMessage)}
          placeholder="Type a message..." />
        <Button onClick={() => sendMessage(newMessage)}><Send className="w-4 h-4" /></Button>
      </div>
    </Card>
  );
}
