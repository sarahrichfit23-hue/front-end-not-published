import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { MessageCircle, Flame, X } from 'lucide-react';
import { toast } from 'sonner';
import DirectMessages from './DirectMessages';

  const [buddies, setBuddies] = useState<any[]>([]);
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBuddies();
  }, []);

  const loadBuddies = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: buddyData } = await supabase
        .from('accountability_buddies')
        .select('*')
        .or(`user_id.eq.${user.id},buddy_id.eq.${user.id}`);

      const accepted = buddyData?.filter(b => b.status === 'accepted') || [];
      const pending = buddyData?.filter(b => b.status === 'pending' && b.buddy_id === user.id) || [];

      setBuddies(accepted);
      setRequests(pending);
    } catch (error) {
      console.error('Load buddies error:', error);
    } finally {
      setLoading(false);
    }
  };

  const acceptRequest = async (requestId: string) => {
    const { error } = await supabase
      .from('accountability_buddies')
      .update({ status: 'accepted', accepted_at: new Date().toISOString() })
      .eq('id', requestId);

    if (error) {
      toast.error('Failed to accept request');
    } else {
      toast.success('Buddy request accepted!');
      loadBuddies();
    }
  };

  return (
    <div className="space-y-4">
      {requests.length > 0 && (
        <Card className="p-4">
          <h3 className="font-semibold mb-3">Pending Requests</h3>
          {requests.map(req => (
            <div key={req.id} className="flex items-center justify-between p-2 border rounded-lg mb-2">
              <span className="text-sm">New buddy request</span>
              <div className="flex gap-2">
                <Button size="sm" onClick={() => acceptRequest(req.id)}>
                  <Check className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </Card>
      )}

      <Card className="p-4">
        <h3 className="font-semibold mb-3">Your Accountability Buddies</h3>
        {buddies.length === 0 ? (
          <p className="text-sm text-muted-foreground">No buddies yet. Find someone to keep you accountable!</p>
        ) : (
          buddies.map(buddy => (
            <div key={buddy.id} className="flex items-center justify-between p-3 border rounded-lg mb-2">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback>AB</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">Accountability Buddy</p>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Flame className="w-4 h-4 text-orange-500" />
                    <span>Streak: 0 days</span>
                  </div>
                </div>
              </div>
              <Button size="sm" variant="outline">
                <MessageCircle className="w-4 h-4" />
              </Button>
            </div>
          ))
        )}
      </Card>
    </div>
  );
}
