import React from 'react';
import { Flame, Trophy, Target } from 'lucide-react';
import { Card } from '@/components/ui/card';

interface StreakTrackerProps {
  currentStreak: number;
  longestStreak: number;
  totalCheckins: number;
}

const StreakTracker: React.FC<StreakTrackerProps> = ({
  currentStreak,
  longestStreak,
  totalCheckins
}) => {
  return (
    <Card className="p-6 bg-gradient-to-br from-orange-50 to-red-50 border-orange-200">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-3 bg-orange-500 rounded-full">
          <Flame className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-2xl font-bold text-gray-900">{currentStreak} Days</h3>
          <p className="text-sm text-gray-600">Current Streak</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mt-4">
        <div className="flex items-center gap-2">
          <Trophy className="w-5 h-5 text-yellow-600" />
          <div>
            <p className="text-lg font-bold text-gray-900">{longestStreak}</p>
            <p className="text-xs text-gray-600">Best Streak</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Target className="w-5 h-5 text-blue-600" />
          <div>
            <p className="text-lg font-bold text-gray-900">{totalCheckins}</p>
            <p className="text-xs text-gray-600">Total Check-ins</p>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default StreakTracker;
