import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export function AudienceStep({ data, onUpdate }: any) {
  const updateAudience = (key: string, value: any) => {
    onUpdate({ targetAudience: { ...data.targetAudience, [key]: value } });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Define Your Target Audience</h2>
        <p className="text-muted-foreground">Who are you creating content for?</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <Label>Age Range</Label>
          <Select value={data.targetAudience.ageRange} onValueChange={v => updateAudience('ageRange', v)}>
            <SelectTrigger><SelectValue placeholder="Select age range" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="18-24">18-24</SelectItem>
              <SelectItem value="25-34">25-34</SelectItem>
              <SelectItem value="35-44">35-44</SelectItem>
              <SelectItem value="45-54">45-54</SelectItem>
              <SelectItem value="55+">55+</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Income Level</Label>
          <Select value={data.targetAudience.income} onValueChange={v => updateAudience('income', v)}>
            <SelectTrigger><SelectValue placeholder="Select income level" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="low">$0-50k</SelectItem>
              <SelectItem value="medium">$50k-100k</SelectItem>
              <SelectItem value="high">$100k-200k</SelectItem>
              <SelectItem value="very-high">$200k+</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <Label>Pain Points & Challenges</Label>
        <Textarea value={data.targetAudience.painPoints} onChange={e => updateAudience('painPoints', e.target.value)} placeholder="What problems does your audience face?" rows={3} />
      </div>

      <div>
        <Label>Customer Avatar Description</Label>
        <Textarea value={data.customerAvatar} onChange={e => onUpdate({ customerAvatar: e.target.value })} placeholder="Describe your ideal customer in detail..." rows={4} />
      </div>
    </div>
  );
}
