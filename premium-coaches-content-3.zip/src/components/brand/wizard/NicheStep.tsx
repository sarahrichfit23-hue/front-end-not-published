import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { BrandTemplateCard } from '../BrandTemplateCard';
import { brandTemplates } from '@/data/brandTemplates';
import { useState } from 'react';

export function NicheStep({ data, onUpdate }: any) {
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);

  const handleTemplateSelect = (template: any) => {
    setSelectedTemplate(template.id);
    onUpdate({
      niche: template.niche,
      industry: template.industry,
      brandVoice: template.brandVoice,
      toneAttributes: template.toneAttributes,
      writingStyle: template.writingStyle,
      missionStatement: template.missionStatement,
      valueProp: template.valueProp,
      keyMessages: template.keyMessages,
      brandValues: template.brandValues,
      contentPillars: template.contentPillars
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Define Your Niche</h2>
        <p className="text-muted-foreground">Start with a template or create from scratch</p>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {brandTemplates.map(template => (
          <BrandTemplateCard
            key={template.id}
            template={template}
            selected={selectedTemplate === template.id}
            onSelect={() => handleTemplateSelect(template)}
          />
        ))}
      </div>

      <div className="space-y-4 pt-6 border-t">
        <div>
          <Label>Brand Name</Label>
          <Input value={data.brandName} onChange={e => onUpdate({ brandName: e.target.value })} placeholder="Your brand name" />
        </div>
        <div>
          <Label>Niche</Label>
          <Input value={data.niche} onChange={e => onUpdate({ niche: e.target.value })} placeholder="e.g., Health Coaching, Business Consulting" />
        </div>
        <div>
          <Label>Industry</Label>
          <Input value={data.industry} onChange={e => onUpdate({ industry: e.target.value })} placeholder="e.g., Wellness, Technology" />
        </div>
      </div>
    </div>
  );
}
