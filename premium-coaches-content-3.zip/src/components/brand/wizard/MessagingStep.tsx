import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, X } from 'lucide-react';
import { useState } from 'react';

export function MessagingStep({ data, onUpdate }: any) {
  const [newMessage, setNewMessage] = useState('');
  const [newValue, setNewValue] = useState('');

  const addMessage = () => {
    if (newMessage.trim()) {
      onUpdate({ keyMessages: [...(data.keyMessages || []), newMessage.trim()] });
      setNewMessage('');
    }
  };

  const removeMessage = (idx: number) => {
    onUpdate({ keyMessages: data.keyMessages.filter((_: any, i: number) => i !== idx) });
  };

  const addValue = () => {
    if (newValue.trim()) {
      onUpdate({ brandValues: [...(data.brandValues || []), newValue.trim()] });
      setNewValue('');
    }
  };

  const removeValue = (idx: number) => {
    onUpdate({ brandValues: data.brandValues.filter((_: any, i: number) => i !== idx) });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Key Messaging & Values</h2>
        <p className="text-muted-foreground">What do you want to communicate?</p>
      </div>

      <div>
        <Label>Mission Statement</Label>
        <Textarea value={data.missionStatement} onChange={e => onUpdate({ missionStatement: e.target.value })} placeholder="Your brand's mission..." rows={3} />
      </div>

      <div>
        <Label>Value Proposition</Label>
        <Textarea value={data.valueProp} onChange={e => onUpdate({ valueProp: e.target.value })} placeholder="What makes you unique?" rows={2} />
      </div>

      <div>
        <Label>Key Messages</Label>
        <div className="flex gap-2 mb-2">
          <Input value={newMessage} onChange={e => setNewMessage(e.target.value)} placeholder="Add a key message" onKeyPress={e => e.key === 'Enter' && addMessage()} />
          <Button type="button" onClick={addMessage}><Plus className="w-4 h-4" /></Button>
        </div>
        <div className="flex flex-wrap gap-2">
          {data.keyMessages?.map((msg: string, i: number) => (
            <Badge key={i} variant="secondary">
              {msg} <X className="w-3 h-3 ml-1 cursor-pointer" onClick={() => removeMessage(i)} />
            </Badge>
          ))}
        </div>
      </div>

      <div>
        <Label>Brand Values</Label>
        <div className="flex gap-2 mb-2">
          <Input value={newValue} onChange={e => setNewValue(e.target.value)} placeholder="Add a value" onKeyPress={e => e.key === 'Enter' && addValue()} />
          <Button type="button" onClick={addValue}><Plus className="w-4 h-4" /></Button>
        </div>
        <div className="flex flex-wrap gap-2">
          {data.brandValues?.map((val: string, i: number) => (
            <Badge key={i} variant="secondary">
              {val} <X className="w-3 h-3 ml-1 cursor-pointer" onClick={() => removeValue(i)} />
            </Badge>
          ))}
        </div>
      </div>
    </div>
  );
}
