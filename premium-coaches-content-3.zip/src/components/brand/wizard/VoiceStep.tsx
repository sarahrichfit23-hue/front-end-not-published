import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';

const voiceOptions = ['Professional', 'Casual', 'Friendly', 'Authoritative', 'Playful', 'Inspiring', 'Educational', 'Empathetic', 'Bold', 'Humorous'];

export function VoiceStep({ data, onUpdate }: any) {
  const toggleVoice = (voice: string) => {
    const current = data.brandVoice || [];
    const updated = current.includes(voice) ? current.filter((v: string) => v !== voice) : [...current, voice];
    onUpdate({ brandVoice: updated });
  };

  const updateTone = (key: string, value: number) => {
    onUpdate({ toneAttributes: { ...data.toneAttributes, [key]: value } });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Define Your Brand Voice</h2>
        <p className="text-muted-foreground">How should your brand sound?</p>
      </div>

      <div>
        <Label>Select Voice Attributes (choose 3-5)</Label>
        <div className="flex flex-wrap gap-2 mt-2">
          {voiceOptions.map(voice => (
            <Badge key={voice} variant={data.brandVoice?.includes(voice) ? 'default' : 'outline'} className="cursor-pointer" onClick={() => toggleVoice(voice)}>
              {voice} {data.brandVoice?.includes(voice) && <X className="w-3 h-3 ml-1" />}
            </Badge>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <Label>Warmth Level: {data.toneAttributes?.warmth || 50}</Label>
          <Slider value={[data.toneAttributes?.warmth || 50]} onValueChange={v => updateTone('warmth', v[0])} max={100} step={1} />
          <div className="flex justify-between text-xs text-muted-foreground mt-1">
            <span>Formal</span><span>Warm & Personal</span>
          </div>
        </div>
        <div>
          <Label>Energy Level: {data.toneAttributes?.energy || 50}</Label>
          <Slider value={[data.toneAttributes?.energy || 50]} onValueChange={v => updateTone('energy', v[0])} max={100} step={1} />
          <div className="flex justify-between text-xs text-muted-foreground mt-1">
            <span>Calm</span><span>Energetic</span>
          </div>
        </div>
      </div>

      <div>
        <Label>Writing Style</Label>
        <Textarea value={data.writingStyle} onChange={e => onUpdate({ writingStyle: e.target.value })} placeholder="Describe your writing style..." rows={3} />
      </div>
    </div>
  );
}
