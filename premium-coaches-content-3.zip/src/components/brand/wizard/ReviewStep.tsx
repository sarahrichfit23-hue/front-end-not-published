import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

export function ReviewStep({ data }: any) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Review Your Brand DNA</h2>
        <p className="text-muted-foreground">Make sure everything looks good</p>
      </div>

      <Card className="p-6 space-y-4">
        <div>
          <h3 className="font-semibold mb-2">Basic Info</h3>
          <p><strong>Brand:</strong> {data.brandName || 'Not set'}</p>
          <p><strong>Niche:</strong> {data.niche || 'Not set'}</p>
          <p><strong>Industry:</strong> {data.industry || 'Not set'}</p>
        </div>

        <Separator />

        <div>
          <h3 className="font-semibold mb-2">Brand Voice</h3>
          <div className="flex flex-wrap gap-2">
            {data.brandVoice?.map((voice: string) => (
              <Badge key={voice}>{voice}</Badge>
            ))}
          </div>
          <p className="mt-2 text-sm">{data.writingStyle}</p>
        </div>

        <Separator />

        <div>
          <h3 className="font-semibold mb-2">Key Messages</h3>
          <ul className="list-disc list-inside space-y-1">
            {data.keyMessages?.map((msg: string, i: number) => (
              <li key={i} className="text-sm">{msg}</li>
            ))}
          </ul>
        </div>

        <Separator />

        <div>
          <h3 className="font-semibold mb-2">Content Pillars</h3>
          <div className="flex flex-wrap gap-2">
            {data.contentPillars?.map((pillar: string) => (
              <Badge key={pillar} variant="secondary">{pillar}</Badge>
            ))}
          </div>
        </div>

        <Separator />

        <div>
          <h3 className="font-semibold mb-2">Preferred Formats</h3>
          <div className="flex flex-wrap gap-2">
            {data.preferredFormats?.map((format: string) => (
              <Badge key={format} variant="outline">{format}</Badge>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}
