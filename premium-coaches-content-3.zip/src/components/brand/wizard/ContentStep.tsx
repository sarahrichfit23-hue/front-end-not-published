import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, X } from 'lucide-react';
import { useState } from 'react';

const formatOptions = ['Blog Posts', 'Social Media', 'Email Newsletters', 'Video Scripts', 'Podcasts', 'Infographics', 'Case Studies', 'Whitepapers'];

export function ContentStep({ data, onUpdate }: any) {
  const [newPillar, setNewPillar] = useState('');
  const [newGoal, setNewGoal] = useState('');

  const addPillar = () => {
    if (newPillar.trim()) {
      onUpdate({ contentPillars: [...(data.contentPillars || []), newPillar.trim()] });
      setNewPillar('');
    }
  };

  const removePillar = (idx: number) => {
    onUpdate({ contentPillars: data.contentPillars.filter((_: any, i: number) => i !== idx) });
  };

  const addGoal = () => {
    if (newGoal.trim()) {
      onUpdate({ contentGoals: [...(data.contentGoals || []), newGoal.trim()] });
      setNewGoal('');
    }
  };

  const removeGoal = (idx: number) => {
    onUpdate({ contentGoals: data.contentGoals.filter((_: any, i: number) => i !== idx) });
  };

  const toggleFormat = (format: string) => {
    const current = data.preferredFormats || [];
    const updated = current.includes(format) ? current.filter((f: string) => f !== format) : [...current, format];
    onUpdate({ preferredFormats: updated });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Content Preferences</h2>
        <p className="text-muted-foreground">Define your content strategy</p>
      </div>

      <div>
        <Label>Content Pillars (main topics)</Label>
        <div className="flex gap-2 mb-2">
          <Input value={newPillar} onChange={e => setNewPillar(e.target.value)} placeholder="Add a content pillar" onKeyPress={e => e.key === 'Enter' && addPillar()} />
          <Button type="button" onClick={addPillar}><Plus className="w-4 h-4" /></Button>
        </div>
        <div className="flex flex-wrap gap-2">
          {data.contentPillars?.map((pillar: string, i: number) => (
            <Badge key={i} variant="secondary">
              {pillar} <X className="w-3 h-3 ml-1 cursor-pointer" onClick={() => removePillar(i)} />
            </Badge>
          ))}
        </div>
      </div>

      <div>
        <Label>Preferred Content Formats</Label>
        <div className="grid md:grid-cols-2 gap-3 mt-2">
          {formatOptions.map(format => (
            <div key={format} className="flex items-center space-x-2">
              <Checkbox checked={data.preferredFormats?.includes(format)} onCheckedChange={() => toggleFormat(format)} id={format} />
              <label htmlFor={format} className="text-sm cursor-pointer">{format}</label>
            </div>
          ))}
        </div>
      </div>

      <div>
        <Label>Content Goals</Label>
        <div className="flex gap-2 mb-2">
          <Input value={newGoal} onChange={e => setNewGoal(e.target.value)} placeholder="e.g., Build email list" onKeyPress={e => e.key === 'Enter' && addGoal()} />
          <Button type="button" onClick={addGoal}><Plus className="w-4 h-4" /></Button>
        </div>
        <div className="flex flex-wrap gap-2">
          {data.contentGoals?.map((goal: string, i: number) => (
            <Badge key={i} variant="secondary">
              {goal} <X className="w-3 h-3 ml-1 cursor-pointer" onClick={() => removeGoal(i)} />
            </Badge>
          ))}
        </div>
      </div>
    </div>
  );
}
