import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, ArrowRight, Save } from 'lucide-react';
import { NicheStep } from './wizard/NicheStep';
import { AudienceStep } from './wizard/AudienceStep';
import { VoiceStep } from './wizard/VoiceStep';
import { MessagingStep } from './wizard/MessagingStep';
import { ContentStep } from './wizard/ContentStep';
import { ReviewStep } from './wizard/ReviewStep';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

export function BrandDNAWizard({ onComplete }: { onComplete?: () => void }) {
  const [step, setStep] = useState(1);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    brandName: '', niche: '', industry: '', targetAudience: {}, customerAvatar: '',
    brandVoice: [], toneAttributes: {}, writingStyle: '', missionStatement: '',
    valueProp: '', keyMessages: [], brandValues: [], contentPillars: [],
    topicsToAvoid: [], preferredFormats: [], contentGoals: []
  });

  const totalSteps = 6;
  const progress = (step / totalSteps) * 100;

  const updateData = (data: any) => setFormData({ ...formData, ...data });

  const handleSave = async () => {
    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Not authenticated. Please log in.');
      }

      console.log('Saving Brand DNA for user:', user.id);
      console.log('Form data:', formData);

      // Save to brand_dna table
      const { data: brandData, error: brandError } = await supabase
        .from('brand_dna')
        .insert({
          user_id: user.id,
          brand_name: formData.brandName,
          niche: formData.niche,
          industry: formData.industry,
          target_audience: formData.targetAudience,
          customer_avatar: formData.customerAvatar,
          brand_voice: formData.brandVoice,
          tone_attributes: formData.toneAttributes,
          writing_style: formData.writingStyle,
          mission_statement: formData.missionStatement,
          value_proposition: formData.valueProp,
          key_messages: formData.keyMessages,
          brand_values: formData.brandValues,
          content_pillars: formData.contentPillars,
          topics_to_avoid: formData.topicsToAvoid,
          preferred_formats: formData.preferredFormats,
          content_goals: formData.contentGoals
        })
        .select()
        .single();

      if (brandError) {
        console.error('Brand DNA save error:', brandError);
        throw brandError;
      }

      console.log('Brand DNA saved successfully:', brandData);

      // Save to content library as well for easy access
      const { data: contentData, error: contentError } = await supabase
        .from('content')
        .insert({
          user_id: user.id,
          title: `Brand DNA - ${formData.brandName || 'My Brand'}`,
          content: JSON.stringify(formData, null, 2),
          type: 'brand_dna'
        })
        .select()
        .single();

      if (contentError) {
        console.error('Content library save error:', contentError);
        throw contentError;
      }

      console.log('Content saved to library:', contentData);

      toast({ 
        title: 'Brand DNA saved successfully!', 
        description: 'Your brand profile has been saved and is ready for PDF export.',
        duration: 3000
      });
      
      // Wait a moment before completing
      setTimeout(() => {
        onComplete?.();
      }, 1500);
    } catch (err: any) {
      console.error('Save error:', err);
      toast({ 
        title: 'Error saving Brand DNA', 
        description: err.message || 'An unexpected error occurred. Please try again.',
        variant: 'destructive',
        duration: 5000
      });
    } finally {
      setSaving(false);
    }
  };




  return (
    <div className="max-w-4xl mx-auto p-6">
      <Progress value={progress} className="mb-6" />
      <Card className="p-8">
        {step === 1 && <NicheStep data={formData} onUpdate={updateData} />}
        {step === 2 && <AudienceStep data={formData} onUpdate={updateData} />}
        {step === 3 && <VoiceStep data={formData} onUpdate={updateData} />}
        {step === 4 && <MessagingStep data={formData} onUpdate={updateData} />}
        {step === 5 && <ContentStep data={formData} onUpdate={updateData} />}
        {step === 6 && <ReviewStep data={formData} />}
        
        <div className="flex justify-between mt-8">
          <Button variant="outline" onClick={() => setStep(s => s - 1)} disabled={step === 1}>
            <ArrowLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          {step < totalSteps ? (
            <Button onClick={() => setStep(s => s + 1)}>
              Next <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          ) : (
            <Button onClick={handleSave} disabled={saving}>
              <Save className="w-4 h-4 mr-2" /> {saving ? 'Saving...' : 'Save Brand DNA'}
            </Button>
          )}
        </div>
      </Card>
    </div>
  );
}
