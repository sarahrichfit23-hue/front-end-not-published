import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check } from 'lucide-react';

interface BrandTemplateCardProps {
  template: any;
  selected?: boolean;
  onSelect: () => void;
}

export function BrandTemplateCard({ template, selected, onSelect }: BrandTemplateCardProps) {
  return (
    <Card className={`p-6 cursor-pointer transition-all hover:shadow-lg ${selected ? 'ring-2 ring-primary' : ''}`} onClick={onSelect}>
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="font-semibold text-lg">{template.name}</h3>
          <p className="text-sm text-muted-foreground">{template.industry}</p>
        </div>
        {selected && (
          <div className="bg-primary text-primary-foreground rounded-full p-1">
            <Check className="w-4 h-4" />
          </div>
        )}
      </div>
      
      <div className="space-y-3 text-sm">
        <div>
          <span className="font-medium">Voice: </span>
          <div className="flex flex-wrap gap-1 mt-1">
            {template.brandVoice.map((voice: string) => (
              <Badge key={voice} variant="secondary">{voice}</Badge>
            ))}
          </div>
        </div>
        
        <p className="text-muted-foreground italic">{template.exampleBrand}</p>
      </div>
      
      <Button className="w-full mt-4" variant={selected ? 'default' : 'outline'}>
        {selected ? 'Selected' : 'Use This Template'}
      </Button>
    </Card>
  );
}
