import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { FileDown, Loader2, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { generateBrandDNAPDF, BrandDNAData } from '@/lib/brandDNAPdfGenerator';

export function BrandDNAPDFExport({ userId }: { userId: string }) {
  const [brandData, setBrandData] = useState<BrandDNAData | null>(null);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadBrandData();
  }, [userId]);

  const loadBrandData = async () => {
    try {
      const { data, error } = await supabase
        .from('brand_dna')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (error) throw error;
      setBrandData(data);
    } catch (err: any) {
      console.error('Error loading brand data:', err);
    } finally {
      setLoading(false);
    }
  };

  const exportToPDF = async () => {
    if (!brandData) {
      toast({
        title: 'No Brand DNA Found',
        description: 'Please complete the Brand DNA Wizard first.',
        variant: 'destructive'
      });
      return;
    }
    
    setExporting(true);
    try {
      console.log('Starting PDF export for brand:', brandData.brand_name);
      console.log('Brand data:', brandData);

      // Generate PDF
      const pdf = generateBrandDNAPDF(brandData);
      
      // Download immediately
      const fileName = `Brand_DNA_${brandData.brand_name.replace(/\s+/g, '_')}.pdf`;
      pdf.save(fileName);
      console.log('PDF downloaded:', fileName);

      // Save metadata to content library
      const { data: contentData, error } = await supabase
        .from('content')
        .insert({
          user_id: userId,
          title: `Brand DNA PDF - ${brandData.brand_name}`,
          content: `Complete brand identity document including voice guidelines, messaging framework, and content strategy for ${brandData.brand_name}. Generated on ${new Date().toLocaleDateString()}.`,
          type: 'brand_dna_pdf',
          is_favorite: false
        })
        .select()
        .single();

      if (error) {
        console.error('Error saving to content library:', error);
        // Don't throw - PDF was still downloaded successfully
        toast({
          title: 'PDF Downloaded',
          description: 'Your Brand DNA PDF has been downloaded. (Note: Could not save to library)',
          duration: 4000
        });
      } else {
        console.log('PDF metadata saved to library:', contentData);
        toast({
          title: 'PDF Generated Successfully!',
          description: 'Your Brand DNA PDF has been downloaded and saved to My Library.',
          duration: 4000
        });
      }
    } catch (err: any) {
      console.error('Export error:', err);
      toast({
        title: 'Export Failed',
        description: err.message || 'An unexpected error occurred. Please try again.',
        variant: 'destructive',
        duration: 5000
      });
    } finally {
      setExporting(false);
    }
  };


  if (loading) {
    return (
      <Card className="p-6">
        <div className="flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin" />
        </div>
      </Card>
    );
  }

  if (!brandData) {
    return (
      <Card className="p-6">
        <p className="text-center text-gray-500">
          No Brand DNA found. Complete the Brand DNA Wizard below to get started.
        </p>
      </Card>
    );
  }

  return (
    <Card className="p-6 bg-gradient-to-br from-indigo-50 to-purple-50 border-indigo-200">
      <div className="flex items-start gap-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold mb-2 text-gray-900">Export Brand DNA as PDF</h3>
          <p className="text-sm text-gray-600 mb-4">
            Generate a professionally formatted PDF document with your complete brand identity,
            voice guidelines, messaging framework, and content strategy.
          </p>
          <div className="flex items-center gap-2 text-sm text-gray-700">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <span className="font-medium">Brand: {brandData.brand_name}</span>
          </div>
        </div>
        <Button onClick={exportToPDF} disabled={exporting} className="bg-indigo-600 hover:bg-indigo-700">
          {exporting ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Generating...
            </>
          ) : (
            <>
              <FileDown className="w-4 h-4 mr-2" />
              Export PDF
            </>
          )}
        </Button>
      </div>
    </Card>
  );
}
