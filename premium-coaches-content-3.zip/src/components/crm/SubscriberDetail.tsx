import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { X, Save, Mail, Phone, User, Calendar, Tag, Activity, MessageSquare, Edit } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';

export function SubscriberDetail({ subscriber, onClose, onUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedData, setEditedData] = useState(subscriber);
  const [activities, setActivities] = useState([]);
  const [notes, setNotes] = useState([]);
  const [newNote, setNewNote] = useState('');
  const [newTag, setNewTag] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    if (subscriber) {
      fetchActivities();
      fetchNotes();
    }
  }, [subscriber]);

  const fetchActivities = async () => {
    try {
      const { data } = await supabase
        .from('subscriber_activities')
        .select('*')
        .eq('subscriber_id', subscriber.id)
        .order('created_at', { ascending: false })
        .limit(50);
      
      setActivities(data || []);
    } catch (error) {
      console.error('Error fetching activities:', error);
    }
  };

  const fetchNotes = async () => {
    try {
      const { data } = await supabase
        .from('subscriber_notes')
        .select('*')
        .eq('subscriber_id', subscriber.id)
        .order('created_at', { ascending: false });
      
      setNotes(data || []);
    } catch (error) {
      console.error('Error fetching notes:', error);
    }
  };

  const handleSave = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('subscribers')
        .update({
          name: editedData.name,
          email: editedData.email,
          phone: editedData.phone,
          tags: editedData.tags,
          status: editedData.status,
          updated_at: new Date().toISOString()
        })
        .eq('id', subscriber.id)
        .eq('user_id', user.id);

      if (error) throw error;

      // Log activity
      await supabase.from('subscriber_activities').insert({
        subscriber_id: subscriber.id,
        user_id: user.id,
        activity_type: 'profile_updated',
        activity_data: { changes: editedData }
      });

      toast({
        title: 'Subscriber Updated',
        description: 'Subscriber information has been updated successfully.',
      });

      setIsEditing(false);
      onUpdate?.(editedData);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update subscriber.',
        variant: 'destructive',
      });
    }
  };

  const handleAddNote = async () => {
    if (!newNote.trim()) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('subscriber_notes')
        .insert({
          subscriber_id: subscriber.id,
          user_id: user.id,
          note: newNote
        });

      if (error) throw error;

      toast({
        title: 'Note Added',
        description: 'Note has been added successfully.',
      });

      setNewNote('');
      fetchNotes();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to add note.',
        variant: 'destructive',
      });
    }
  };

  const handleAddTag = () => {
    if (!newTag.trim()) return;
    if (editedData.tags?.includes(newTag)) return;

    setEditedData({
      ...editedData,
      tags: [...(editedData.tags || []), newTag]
    });
    setNewTag('');
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setEditedData({
      ...editedData,
      tags: editedData.tags?.filter(tag => tag !== tagToRemove) || []
    });
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'opt_in': return '✅';
      case 'email_sent': return '📧';
      case 'email_opened': return '👁️';
      case 'email_clicked': return '🔗';
      case 'sms_sent': return '💬';
      case 'tag_added': return '🏷️';
      case 'status_changed': return '🔄';
      default: return '📌';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-2xl font-bold">Subscriber Details</h2>
          <div className="flex items-center gap-2">
            {isEditing ? (
              <>
                <Button onClick={handleSave} size="sm">
                  <Save className="h-4 w-4 mr-2" />
                  Save
                </Button>
                <Button onClick={() => setIsEditing(false)} variant="outline" size="sm">
                  Cancel
                </Button>
              </>
            ) : (
              <Button onClick={() => setIsEditing(true)} variant="outline" size="sm">
                <Edit className="h-4 w-4 mr-2" />
                Edit
              </Button>
            )}
            <Button onClick={onClose} variant="ghost" size="sm">
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-80px)]">
          <Tabs defaultValue="profile" className="p-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              <TabsTrigger value="activity">Activity</TabsTrigger>
              <TabsTrigger value="notes">Notes</TabsTrigger>
            </TabsList>

            <TabsContent value="profile" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Name</Label>
                      {isEditing ? (
                        <Input
                          value={editedData.name || ''}
                          onChange={(e) => setEditedData({ ...editedData, name: e.target.value })}
                        />
                      ) : (
                        <p className="text-sm mt-1">{subscriber.name || 'No name'}</p>
                      )}
                    </div>
                    <div>
                      <Label>Email</Label>
                      {isEditing ? (
                        <Input
                          type="email"
                          value={editedData.email}
                          onChange={(e) => setEditedData({ ...editedData, email: e.target.value })}
                        />
                      ) : (
                        <p className="text-sm mt-1">{subscriber.email}</p>
                      )}
                    </div>
                    <div>
                      <Label>Phone</Label>
                      {isEditing ? (
                        <Input
                          value={editedData.phone || ''}
                          onChange={(e) => setEditedData({ ...editedData, phone: e.target.value })}
                        />
                      ) : (
                        <p className="text-sm mt-1">{subscriber.phone || 'No phone'}</p>
                      )}
                    </div>
                    <div>
                      <Label>Status</Label>
                      {isEditing ? (
                        <Select
                          value={editedData.status}
                          onValueChange={(value) => setEditedData({ ...editedData, status: value })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="active">Active</SelectItem>
                            <SelectItem value="unsubscribed">Unsubscribed</SelectItem>
                            <SelectItem value="bounced">Bounced</SelectItem>
                            <SelectItem value="pending">Pending</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge className="mt-1">{subscriber.status}</Badge>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label>Tags</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {editedData.tags?.map((tag) => (
                        <Badge key={tag} variant="secondary">
                          {tag}
                          {isEditing && (
                            <button
                              onClick={() => handleRemoveTag(tag)}
                              className="ml-1 text-xs hover:text-red-500"
                            >
                              ×
                            </button>
                          )}
                        </Badge>
                      ))}
                      {isEditing && (
                        <div className="flex gap-1">
                          <Input
                            placeholder="Add tag"
                            value={newTag}
                            onChange={(e) => setNewTag(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
                            className="h-7 w-24 text-sm"
                          />
                          <Button onClick={handleAddTag} size="sm" className="h-7 px-2">
                            +
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                    <div>
                      <Label>Source</Label>
                      <p className="text-sm mt-1">{subscriber.source}</p>
                    </div>
                    <div>
                      <Label>Opt-in Date</Label>
                      <p className="text-sm mt-1">
                        {format(new Date(subscriber.opt_in_date), 'MMM d, yyyy h:mm a')}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="activity" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Activity Timeline</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {activities.map((activity) => (
                      <div key={activity.id} className="flex items-start gap-3 pb-4 border-b last:border-0">
                        <span className="text-2xl">{getActivityIcon(activity.activity_type)}</span>
                        <div className="flex-1">
                          <p className="font-medium">{activity.activity_type.replace(/_/g, ' ')}</p>
                          {activity.activity_data && (
                            <p className="text-sm text-gray-500">
                              {JSON.stringify(activity.activity_data)}
                            </p>
                          )}
                          <p className="text-xs text-gray-400 mt-1">
                            {format(new Date(activity.created_at), 'MMM d, yyyy h:mm a')}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="notes" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Notes</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-2">
                    <Textarea
                      placeholder="Add a note..."
                      value={newNote}
                      onChange={(e) => setNewNote(e.target.value)}
                      rows={3}
                    />
                    <Button onClick={handleAddNote}>Add Note</Button>
                  </div>

                  <div className="space-y-3">
                    {notes.map((note) => (
                      <div key={note.id} className="p-3 bg-gray-50 rounded-lg">
                        <p className="text-sm">{note.note}</p>
                        <p className="text-xs text-gray-400 mt-2">
                          {format(new Date(note.created_at), 'MMM d, yyyy h:mm a')}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}