import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Upload, FileText, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Progress } from '@/components/ui/progress';

export function SubscriberImport({ onImportComplete }) {
  const [file, setFile] = useState<File | null>(null);
  const [csvData, setCsvData] = useState<any[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [mapping, setMapping] = useState({
    email: '',
    name: '',
    phone: '',
    tags: ''
  });
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<any>(null);
  const { toast } = useToast();

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFile(file);
    const reader = new FileReader();
    
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const lines = text.split('\n');
      const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
      
      setHeaders(headers);
      
      // Auto-detect mapping
      const autoMapping = {
        email: headers.find(h => h.toLowerCase().includes('email')) || '',
        name: headers.find(h => h.toLowerCase().includes('name')) || '',
        phone: headers.find(h => h.toLowerCase().includes('phone')) || '',
        tags: headers.find(h => h.toLowerCase().includes('tag')) || ''
      };
      setMapping(autoMapping);
      
      // Parse preview data
      const previewData = lines.slice(1, 6).map(line => {
        const values = line.split(',').map(v => v.trim().replace(/"/g, ''));
        return headers.reduce((obj, header, index) => {
          obj[header] = values[index];
          return obj;
        }, {} as any);
      });
      setCsvData(previewData);
    };
    
    reader.readAsText(file);
  };

  const handleImport = async () => {
    if (!file || !mapping.email) {
      toast({
        title: 'Error',
        description: 'Please select a file and map the email column.',
        variant: 'destructive',
      });
      return;
    }

    setImporting(true);
    try {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const csvContent = event.target?.result as string;
        
        const { data, error } = await supabase.functions.invoke('subscriber-operations', {
          body: {
            action: 'import_csv',
            data: {
              csvContent,
              mapping: {
                email: headers.indexOf(mapping.email),
                name: mapping.name ? headers.indexOf(mapping.name) : null,
                phone: mapping.phone ? headers.indexOf(mapping.phone) : null,
                tags: mapping.tags ? headers.indexOf(mapping.tags) : null
              }
            }
          }
        });

        if (error) throw error;

        setImportResult(data);
        toast({
          title: 'Import Complete',
          description: `Successfully imported ${data.imported} subscribers.`,
        });
        
        onImportComplete?.();
      };
      
      reader.readAsText(file);
    } catch (error) {
      toast({
        title: 'Import Failed',
        description: 'Failed to import subscribers. Please check your file format.',
        variant: 'destructive',
      });
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Import Subscribers from CSV</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="csv-file">Select CSV File</Label>
            <div className="mt-2">
              <label htmlFor="csv-file" className="cursor-pointer">
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition-colors">
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <p className="mt-2 text-sm text-gray-600">
                    {file ? file.name : 'Click to upload or drag and drop'}
                  </p>
                  <p className="text-xs text-gray-500">CSV files only</p>
                </div>
                <input
                  id="csv-file"
                  type="file"
                  accept=".csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {headers.length > 0 && (
            <>
              <div className="space-y-3">
                <Label>Column Mapping</Label>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm">Email Column *</Label>
                    <Select value={mapping.email} onValueChange={(v) => setMapping({ ...mapping, email: v })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select email column" />
                      </SelectTrigger>
                      <SelectContent>
                        {headers.map(header => (
                          <SelectItem key={header} value={header}>{header}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label className="text-sm">Name Column</Label>
                    <Select value={mapping.name} onValueChange={(v) => setMapping({ ...mapping, name: v })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select name column" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">None</SelectItem>
                        {headers.map(header => (
                          <SelectItem key={header} value={header}>{header}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label className="text-sm">Phone Column</Label>
                    <Select value={mapping.phone} onValueChange={(v) => setMapping({ ...mapping, phone: v })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select phone column" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">None</SelectItem>
                        {headers.map(header => (
                          <SelectItem key={header} value={header}>{header}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label className="text-sm">Tags Column</Label>
                    <Select value={mapping.tags} onValueChange={(v) => setMapping({ ...mapping, tags: v })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select tags column" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">None</SelectItem>
                        {headers.map(header => (
                          <SelectItem key={header} value={header}>{header}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div>
                <Label>Preview</Label>
                <div className="mt-2 border rounded-lg overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-2 text-left">Email</th>
                        <th className="px-4 py-2 text-left">Name</th>
                        <th className="px-4 py-2 text-left">Phone</th>
                        <th className="px-4 py-2 text-left">Tags</th>
                      </tr>
                    </thead>
                    <tbody>
                      {csvData.map((row, i) => (
                        <tr key={i} className="border-t">
                          <td className="px-4 py-2">{mapping.email && row[mapping.email]}</td>
                          <td className="px-4 py-2">{mapping.name && row[mapping.name]}</td>
                          <td className="px-4 py-2">{mapping.phone && row[mapping.phone]}</td>
                          <td className="px-4 py-2">{mapping.tags && row[mapping.tags]}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {importResult && (
            <div className="p-4 bg-gray-50 rounded-lg space-y-2">
              <div className="flex items-center gap-2 text-green-600">
                <CheckCircle className="h-5 w-5" />
                <span>{importResult.imported} subscribers imported</span>
              </div>
              {importResult.skipped > 0 && (
                <div className="flex items-center gap-2 text-yellow-600">
                  <AlertCircle className="h-5 w-5" />
                  <span>{importResult.skipped} rows skipped</span>
                </div>
              )}
              {importResult.errors > 0 && (
                <div className="flex items-center gap-2 text-red-600">
                  <XCircle className="h-5 w-5" />
                  <span>{importResult.errors} errors</span>
                </div>
              )}
            </div>
          )}

          <Button 
            onClick={handleImport} 
            disabled={!file || !mapping.email || importing}
            className="w-full"
          >
            {importing ? 'Importing...' : 'Import Subscribers'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}