import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Search, Filter, MoreVertical, Mail, Phone, Tag, Calendar, User } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';

export function SubscriberList({ onSelectSubscriber, selectedIds, onSelectionChange }) {
  const [subscribers, setSubscribers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sourceFilter, setSourceFilter] = useState('all');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [allTags, setAllTags] = useState<string[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    fetchSubscribers();
    fetchTags();
  }, [statusFilter, sourceFilter, selectedTags]);

  const fetchSubscribers = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      let query = supabase
        .from('subscribers')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (statusFilter !== 'all') {
        query = query.eq('status', statusFilter);
      }
      if (sourceFilter !== 'all') {
        query = query.eq('source', sourceFilter);
      }
      if (selectedTags.length > 0) {
        query = query.contains('tags', selectedTags);
      }

      const { data, error } = await query;
      if (error) throw error;
      setSubscribers(data || []);
    } catch (error) {
      console.error('Error fetching subscribers:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchTags = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data } = await supabase
        .from('subscribers')
        .select('tags')
        .eq('user_id', user.id);

      const tags = new Set<string>();
      data?.forEach(sub => {
        sub.tags?.forEach(tag => tags.add(tag));
      });
      setAllTags(Array.from(tags));
    } catch (error) {
      console.error('Error fetching tags:', error);
    }
  };

  const handleStatusChange = async (subscriberId: string, newStatus: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase.functions.invoke('subscriber-operations', {
        body: {
          action: 'bulk_status',
          data: { subscriberIds: [subscriberId], status: newStatus }
        }
      });

      toast({
        title: 'Status Updated',
        description: 'Subscriber status has been updated successfully.',
      });

      fetchSubscribers();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update subscriber status.',
        variant: 'destructive',
      });
    }
  };

  const filteredSubscribers = subscribers.filter(sub =>
    searchTerm === '' || 
    sub.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sub.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'unsubscribed': return 'bg-gray-500';
      case 'bounced': return 'bg-red-500';
      case 'pending': return 'bg-yellow-500';
      default: return 'bg-gray-400';
    }
  };

  const getSourceIcon = (source: string) => {
    switch (source) {
      case 'landing_page': return '🌐';
      case 'import': return '📥';
      case 'manual': return '✏️';
      case 'api': return '🔌';
      default: return '📧';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="unsubscribed">Unsubscribed</SelectItem>
            <SelectItem value="bounced">Bounced</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
          </SelectContent>
        </Select>

        <Select value={sourceFilter} onValueChange={setSourceFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Source" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sources</SelectItem>
            <SelectItem value="landing_page">Landing Page</SelectItem>
            <SelectItem value="import">Import</SelectItem>
            <SelectItem value="manual">Manual</SelectItem>
            <SelectItem value="api">API</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12">
                <Checkbox 
                  checked={selectedIds?.length === filteredSubscribers.length}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      onSelectionChange?.(filteredSubscribers.map(s => s.id));
                    } else {
                      onSelectionChange?.([]);
                    }
                  }}
                />
              </TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Tags</TableHead>
              <TableHead>Source</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Opt-in Date</TableHead>
              <TableHead className="w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredSubscribers.map((subscriber) => (
              <TableRow 
                key={subscriber.id}
                className="cursor-pointer hover:bg-gray-50"
                onClick={() => onSelectSubscriber?.(subscriber)}
              >
                <TableCell onClick={(e) => e.stopPropagation()}>
                  <Checkbox
                    checked={selectedIds?.includes(subscriber.id)}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        onSelectionChange?.([...selectedIds, subscriber.id]);
                      } else {
                        onSelectionChange?.(selectedIds.filter(id => id !== subscriber.id));
                      }
                    }}
                  />
                </TableCell>
                <TableCell>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-gray-400" />
                      <span className="font-medium">{subscriber.name || 'No name'}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <Mail className="h-3 w-3" />
                      {subscriber.email}
                    </div>
                    {subscriber.phone && (
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <Phone className="h-3 w-3" />
                        {subscriber.phone}
                      </div>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-1">
                    {subscriber.tags?.slice(0, 3).map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                    {subscriber.tags?.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{subscriber.tags.length - 3}
                      </Badge>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <span className="text-sm">
                    {getSourceIcon(subscriber.source)} {subscriber.source}
                  </span>
                </TableCell>
                <TableCell>
                  <Badge className={`${getStatusColor(subscriber.status)} text-white`}>
                    {subscriber.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <Calendar className="h-3 w-3" />
                    {format(new Date(subscriber.opt_in_date), 'MMM d, yyyy')}
                  </div>
                </TableCell>
                <TableCell onClick={(e) => e.stopPropagation()}>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleStatusChange(subscriber.id, 'active')}>
                        Mark Active
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleStatusChange(subscriber.id, 'unsubscribed')}>
                        Unsubscribe
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleStatusChange(subscriber.id, 'bounced')}>
                        Mark Bounced
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}