import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { SubscriberList } from './SubscriberList';
import { SubscriberDetail } from './SubscriberDetail';
import { SubscriberImport } from './SubscriberImport';
import { SubscriberSegments } from './SubscriberSegments';
import { 
  Users, Upload, Download, Tag, Filter, TrendingUp, 
  UserCheck, UserX, Mail, MessageSquare, Plus
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function SubscriberDashboard() {
  const [selectedSubscriber, setSelectedSubscriber] = useState(null);
  const [selectedSubscriberIds, setSelectedSubscriberIds] = useState<string[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    unsubscribed: 0,
    bounced: 0,
    growth: 0
  });
  const [recentActivities, setRecentActivities] = useState([]);
  const { toast } = useToast();

  useEffect(() => {
    fetchStats();
    fetchRecentActivities();
  }, []);

  const fetchStats = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Get subscriber counts
      const { count: total } = await supabase
        .from('subscribers')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id);

      const { count: active } = await supabase
        .from('subscribers')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('status', 'active');

      const { count: unsubscribed } = await supabase
        .from('subscribers')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('status', 'unsubscribed');

      const { count: bounced } = await supabase
        .from('subscribers')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('status', 'bounced');

      // Calculate growth (last 30 days)
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      const { count: newSubscribers } = await supabase
        .from('subscribers')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .gte('created_at', thirtyDaysAgo.toISOString());

      setStats({
        total: total || 0,
        active: active || 0,
        unsubscribed: unsubscribed || 0,
        bounced: bounced || 0,
        growth: newSubscribers || 0
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const fetchRecentActivities = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data } = await supabase
        .from('subscriber_activities')
        .select('*, subscribers(email, name)')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10);

      setRecentActivities(data || []);
    } catch (error) {
      console.error('Error fetching activities:', error);
    }
  };

  const handleExport = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('subscriber-operations', {
        body: {
          action: 'export_csv',
          data: { filters: {} }
        }
      });

      if (error) throw error;

      // Download CSV
      const blob = new Blob([data.csv], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `subscribers-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();

      toast({
        title: 'Export Complete',
        description: 'Your subscribers have been exported successfully.',
      });
    } catch (error) {
      toast({
        title: 'Export Failed',
        description: 'Failed to export subscribers.',
        variant: 'destructive',
      });
    }
  };

  const handleBulkAction = async (action: string) => {
    if (selectedSubscriberIds.length === 0) {
      toast({
        title: 'No Selection',
        description: 'Please select subscribers first.',
        variant: 'destructive',
      });
      return;
    }

    try {
      if (action === 'tag') {
        // Show tag dialog
        const tag = prompt('Enter tag to add:');
        if (!tag) return;

        await supabase.functions.invoke('subscriber-operations', {
          body: {
            action: 'bulk_tag',
            data: {
              subscriberIds: selectedSubscriberIds,
              tags: [tag],
              operation: 'add'
            }
          }
        });

        toast({
          title: 'Tags Added',
          description: `Tag added to ${selectedSubscriberIds.length} subscribers.`,
        });
      } else if (action === 'unsubscribe') {
        await supabase.functions.invoke('subscriber-operations', {
          body: {
            action: 'bulk_status',
            data: {
              subscriberIds: selectedSubscriberIds,
              status: 'unsubscribed'
            }
          }
        });

        toast({
          title: 'Subscribers Updated',
          description: `${selectedSubscriberIds.length} subscribers unsubscribed.`,
        });
      }

      setSelectedSubscriberIds([]);
      fetchStats();
    } catch (error) {
      toast({
        title: 'Action Failed',
        description: 'Failed to perform bulk action.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Subscribers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold">{stats.total}</span>
              <Users className="h-5 w-5 text-gray-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Active</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold text-green-600">{stats.active}</span>
              <UserCheck className="h-5 w-5 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Unsubscribed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold text-gray-600">{stats.unsubscribed}</span>
              <UserX className="h-5 w-5 text-gray-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Bounced</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold text-red-600">{stats.bounced}</span>
              <Mail className="h-5 w-5 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">30-Day Growth</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold text-blue-600">+{stats.growth}</span>
              <TrendingUp className="h-5 w-5 text-blue-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="subscribers" className="space-y-4">
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="subscribers">All Subscribers</TabsTrigger>
            <TabsTrigger value="segments">Segments</TabsTrigger>
            <TabsTrigger value="import">Import</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          <div className="flex items-center gap-2">
            {selectedSubscriberIds.length > 0 && (
              <>
                <Badge variant="secondary">
                  {selectedSubscriberIds.length} selected
                </Badge>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleBulkAction('tag')}
                >
                  <Tag className="h-4 w-4 mr-2" />
                  Add Tag
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleBulkAction('unsubscribe')}
                >
                  <UserX className="h-4 w-4 mr-2" />
                  Unsubscribe
                </Button>
              </>
            )}
            <Button size="sm" variant="outline" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Subscriber
            </Button>
          </div>
        </div>

        <TabsContent value="subscribers">
          <SubscriberList
            onSelectSubscriber={setSelectedSubscriber}
            selectedIds={selectedSubscriberIds}
            onSelectionChange={setSelectedSubscriberIds}
          />
        </TabsContent>

        <TabsContent value="segments">
          <SubscriberSegments
            onSelectSegment={(segment) => {
              // Apply segment filters to list
              console.log('Selected segment:', segment);
            }}
          />
        </TabsContent>

        <TabsContent value="import">
          <SubscriberImport
            onImportComplete={() => {
              fetchStats();
            }}
          />
        </TabsContent>

        <TabsContent value="activity">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity: any) => (
                  <div key={activity.id} className="flex items-start gap-3 pb-4 border-b last:border-0">
                    <div className="flex-1">
                      <p className="font-medium">
                        {activity.subscribers?.name || activity.subscribers?.email}
                      </p>
                      <p className="text-sm text-gray-500">
                        {activity.activity_type.replace(/_/g, ' ')}
                      </p>
                      <p className="text-xs text-gray-400 mt-1">
                        {new Date(activity.created_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {selectedSubscriber && (
        <SubscriberDetail
          subscriber={selectedSubscriber}
          onClose={() => setSelectedSubscriber(null)}
          onUpdate={(updated) => {
            setSelectedSubscriber(updated);
            fetchStats();
          }}
        />
      )}
    </div>
  );
}