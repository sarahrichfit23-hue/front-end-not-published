import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/lib/supabase';
import { useApp } from '@/contexts/AppContext';
import { 
  Activity, TrendingUp, AlertTriangle, Clock, 
  Zap, Shield, Key, BarChart3, Info
} from 'lucide-react';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, Legend, ResponsiveContainer, Area, AreaChart
} from 'recharts';
import { format, subDays, startOfDay } from 'date-fns';

export const APIUsageDashboard = () => {
  const { user } = useApp();
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('day');
  const [usageData, setUsageData] = useState<any>(null);
  const [analytics, setAnalytics] = useState<any[]>([]);
  const [violations, setViolations] = useState<any[]>([]);
  const [apiKeys, setApiKeys] = useState<any[]>([]);
  const [limits, setLimits] = useState<any>(null);

  useEffect(() => {
    if (user) {
      fetchUsageData();
      fetchAPIKeys();
      fetchViolations();
    }
  }, [user, period]);

  const fetchUsageData = async () => {
    try {
      setLoading(true);
      
      // Get usage analytics
      const { data, error } = await supabase.functions.invoke('rate-limiter', {
        body: { 
          action: 'get-usage',
          userId: user?.id,
          period 
        }
      });

      if (error) throw error;
      
      setUsageData(data.quota);
      setAnalytics(data.analytics || []);

      // Get rate limits for user's tier
      const { data: userSub } = await supabase
        .from('subscriptions')
        .select('tier')
        .eq('user_id', user?.id)
        .single();

      const tier = userSub?.tier || 'free';
      
      const { data: limitsData } = await supabase
        .from('rate_limits')
        .select('*')
        .eq('tier', tier)
        .is('function_name', null)
        .single();
      
      setLimits(limitsData);
    } catch (error) {
      console.error('Error fetching usage data:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAPIKeys = async () => {
    try {
      const { data } = await supabase
        .from('api_keys')
        .select('*')
        .eq('user_id', user?.id)
        .is('revoked_at', null)
        .order('created_at', { ascending: false });
      
      setApiKeys(data || []);
    } catch (error) {
      console.error('Error fetching API keys:', error);
    }
  };

  const fetchViolations = async () => {
    try {
      const { data } = await supabase
        .from('rate_limit_violations')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })
        .limit(10);
      
      setViolations(data || []);
    } catch (error) {
      console.error('Error fetching violations:', error);
    }
  };

  const getUsagePercentage = (current: number, limit: number) => {
    return Math.min((current / limit) * 100, 100);
  };

  const formatChartData = () => {
    return analytics.map(item => ({
      date: format(new Date(item.date), 'MMM dd'),
      requests: item.total_requests,
      successful: item.successful_requests,
      failed: item.failed_requests,
      avgResponseTime: item.avg_response_time_ms
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">API Usage & Rate Limits</h2>
          <p className="text-gray-600">Monitor your API usage and manage rate limits</p>
        </div>
        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="hour">Last 24 Hours</SelectItem>
            <SelectItem value="day">Last 7 Days</SelectItem>
            <SelectItem value="week">Last 30 Days</SelectItem>
            <SelectItem value="month">Last 12 Months</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Current Usage Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">
              Requests/Minute
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {usageData?.current_minute_count || 0}
              <span className="text-sm text-gray-500 ml-1">
                / {limits?.requests_per_minute || 0}
              </span>
            </div>
            <Progress 
              value={getUsagePercentage(
                usageData?.current_minute_count || 0,
                limits?.requests_per_minute || 1
              )}
              className="mt-2"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">
              Requests/Hour
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {usageData?.current_hour_count || 0}
              <span className="text-sm text-gray-500 ml-1">
                / {limits?.requests_per_hour || 0}
              </span>
            </div>
            <Progress 
              value={getUsagePercentage(
                usageData?.current_hour_count || 0,
                limits?.requests_per_hour || 1
              )}
              className="mt-2"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">
              Requests/Day
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {usageData?.current_day_count || 0}
              <span className="text-sm text-gray-500 ml-1">
                / {limits?.requests_per_day || 0}
              </span>
            </div>
            <Progress 
              value={getUsagePercentage(
                usageData?.current_day_count || 0,
                limits?.requests_per_day || 1
              )}
              className="mt-2"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">
              Requests/Month
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {usageData?.current_month_count || 0}
              <span className="text-sm text-gray-500 ml-1">
                / {limits?.requests_per_month || 0}
              </span>
            </div>
            <Progress 
              value={getUsagePercentage(
                usageData?.current_month_count || 0,
                limits?.requests_per_month || 1
              )}
              className="mt-2"
            />
          </CardContent>
        </Card>
      </div>

      {/* Usage Chart */}
      <Card>
        <CardHeader>
          <CardTitle>API Usage Over Time</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={formatChartData()}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Area 
                type="monotone" 
                dataKey="successful" 
                stackId="1"
                stroke="#10b981" 
                fill="#10b981" 
                fillOpacity={0.6}
              />
              <Area 
                type="monotone" 
                dataKey="failed" 
                stackId="1"
                stroke="#ef4444" 
                fill="#ef4444" 
                fillOpacity={0.6}
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Rate Limit Violations */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-500" />
              Recent Rate Limit Violations
            </CardTitle>
          </CardHeader>
          <CardContent>
            {violations.length === 0 ? (
              <p className="text-gray-500">No violations recorded</p>
            ) : (
              <div className="space-y-2">
                {violations.map((violation) => (
                  <div key={violation.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <div>
                      <p className="font-medium">{violation.function_name}</p>
                      <p className="text-sm text-gray-500">
                        {violation.limit_type} limit exceeded ({violation.actual_value}/{violation.limit_value})
                      </p>
                    </div>
                    <span className="text-xs text-gray-500">
                      {format(new Date(violation.created_at), 'MMM dd, HH:mm')}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* API Keys */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Key className="w-5 h-5" />
              API Keys
            </CardTitle>
          </CardHeader>
          <CardContent>
            {apiKeys.length === 0 ? (
              <div className="text-center py-4">
                <p className="text-gray-500 mb-4">No API keys created yet</p>
                <Button>Create API Key</Button>
              </div>
            ) : (
              <div className="space-y-2">
                {apiKeys.map((key) => (
                  <div key={key.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <div>
                      <p className="font-medium">{key.name}</p>
                      <p className="text-sm text-gray-500">
                        ****{key.last_four}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {key.last_used_at && (
                        <span className="text-xs text-gray-500">
                          Last used: {format(new Date(key.last_used_at), 'MMM dd')}
                        </span>
                      )}
                      <Button variant="ghost" size="sm">Revoke</Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Rate Limits Info */}
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          Your current tier is <strong>{usageData?.tier || 'free'}</strong>. 
          Rate limits reset automatically at the specified intervals. 
          Upgrade your plan for higher limits and additional features.
        </AlertDescription>
      </Alert>
    </div>
  );
}

export default APIUsageDashboard;