import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { Mail, Code, Eye, Save } from 'lucide-react';

interface EmailTemplateEditorProps {
  brandId: string;
  brandName: string;
}

const templateTypes = [
  { value: 'welcome', label: 'Welcome Email' },
  { value: 'reset_password', label: 'Password Reset' },
  { value: 'invitation', label: 'Team Invitation' },
  { value: 'notification', label: 'Notification' }
];

export default function EmailTemplateEditor({ brandId, brandName }: EmailTemplateEditorProps) {
  const [templates, setTemplates] = useState<any[]>([]);
  const [selectedType, setSelectedType] = useState('welcome');
  const [formData, setFormData] = useState({
    subject: '',
    html_content: '',
    text_content: '',
    from_name: '',
    from_email: ''
  });
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchTemplates();
  }, [brandId]);

  const fetchTemplates = async () => {
    const { data, error } = await supabase
      .from('brand_email_templates')
      .select('*')
      .eq('brand_id', brandId);

    if (!error && data) {
      setTemplates(data);
      const current = data.find(t => t.template_type === selectedType);
      if (current) {
        setFormData({
          subject: current.subject,
          html_content: current.html_content,
          text_content: current.text_content || '',
          from_name: current.from_name || '',
          from_email: current.from_email || ''
        });
      }
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('brand_email_templates')
        .upsert({
          brand_id: brandId,
          template_type: selectedType,
          name: templateTypes.find(t => t.value === selectedType)?.label,
          ...formData,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Email template saved'
      });
      fetchTemplates();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save template',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Email Templates for {brandName}</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={selectedType} onValueChange={setSelectedType}>
          <TabsList className="mb-4">
            {templateTypes.map(type => (
              <TabsTrigger key={type.value} value={type.value}>
                {type.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {templateTypes.map(type => (
            <TabsContent key={type.value} value={type.value}>
              <div className="space-y-4">
                <div>
                  <Label>Subject</Label>
                  <Input
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="Email subject line"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>From Name</Label>
                    <Input
                      value={formData.from_name}
                      onChange={(e) => setFormData({ ...formData, from_name: e.target.value })}
                      placeholder={brandName}
                    />
                  </div>
                  <div>
                    <Label>From Email</Label>
                    <Input
                      type="email"
                      value={formData.from_email}
                      onChange={(e) => setFormData({ ...formData, from_email: e.target.value })}
                      placeholder="noreply@example.com"
                    />
                  </div>
                </div>

                <div>
                  <Label>HTML Content</Label>
                  <Textarea
                    value={formData.html_content}
                    onChange={(e) => setFormData({ ...formData, html_content: e.target.value })}
                    rows={10}
                    className="font-mono text-sm"
                    placeholder="<h1>Welcome!</h1>"
                  />
                </div>

                <div>
                  <Label>Plain Text Content</Label>
                  <Textarea
                    value={formData.text_content}
                    onChange={(e) => setFormData({ ...formData, text_content: e.target.value })}
                    rows={5}
                    placeholder="Plain text version"
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <Button variant="outline">
                    <Eye className="h-4 w-4 mr-2" />
                    Preview
                  </Button>
                  <Button onClick={handleSave} disabled={saving}>
                    <Save className="h-4 w-4 mr-2" />
                    {saving ? 'Saving...' : 'Save Template'}
                  </Button>
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
}