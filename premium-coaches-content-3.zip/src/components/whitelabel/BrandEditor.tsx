import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { Palette, Globe, Upload, Code } from 'lucide-react';

interface BrandEditorProps {
  brand?: any;
  onSave: () => void;
  onCancel: () => void;
}

export default function BrandEditor({ brand, onSave, onCancel }: BrandEditorProps) {
  const [formData, setFormData] = useState({
    name: brand?.name || '',
    slug: brand?.slug || '',
    logo_url: brand?.logo_url || '',
    favicon_url: brand?.favicon_url || '',
    primary_color: brand?.primary_color || '#3B82F6',
    secondary_color: brand?.secondary_color || '#10B981',
    accent_color: brand?.accent_color || '#8B5CF6',
    background_color: brand?.background_color || '#FFFFFF',
    text_color: brand?.text_color || '#111827',
    font_family: brand?.font_family || 'Inter',
    custom_domain: brand?.custom_domain || '',
    hide_platform_branding: brand?.hide_platform_branding || false,
    powered_by_text: brand?.powered_by_text || '',
    custom_css: brand?.custom_css || '',
    meta_title: brand?.meta_title || '',
    meta_description: brand?.meta_description || ''
  });
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('No session');

      const { data: { user } } = await supabase.auth.getUser();
      const { data: teams } = await supabase
        .from('team_members')
        .select('team_id')
        .eq('user_id', user?.id)
        .limit(1);

      if (brand) {
        const { error } = await supabase
          .from('white_label_brands')
          .update(formData)
          .eq('id', brand.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('white_label_brands')
          .insert({
            ...formData,
            team_id: teams?.[0]?.team_id,
            created_by: user?.id
          });
        if (error) throw error;
      }

      toast({
        title: 'Success',
        description: `Brand ${brand ? 'updated' : 'created'} successfully`
      });
      onSave();
    } catch (error) {
      console.error('Error saving brand:', error);
      toast({
        title: 'Error',
        description: 'Failed to save brand',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{brand ? 'Edit Brand' : 'Create Brand'}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Brand Name</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            <div>
              <Label>Slug</Label>
              <Input
                value={formData.slug}
                onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                pattern="[a-z0-9-]+"
                required
              />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Palette className="h-5 w-5" />
              Colors
            </h3>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label>Primary Color</Label>
                <div className="flex gap-2">
                  <Input
                    type="color"
                    value={formData.primary_color}
                    onChange={(e) => setFormData({ ...formData, primary_color: e.target.value })}
                    className="w-20"
                  />
                  <Input
                    value={formData.primary_color}
                    onChange={(e) => setFormData({ ...formData, primary_color: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <Label>Secondary Color</Label>
                <div className="flex gap-2">
                  <Input
                    type="color"
                    value={formData.secondary_color}
                    onChange={(e) => setFormData({ ...formData, secondary_color: e.target.value })}
                    className="w-20"
                  />
                  <Input
                    value={formData.secondary_color}
                    onChange={(e) => setFormData({ ...formData, secondary_color: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <Label>Accent Color</Label>
                <div className="flex gap-2">
                  <Input
                    type="color"
                    value={formData.accent_color}
                    onChange={(e) => setFormData({ ...formData, accent_color: e.target.value })}
                    className="w-20"
                  />
                  <Input
                    value={formData.accent_color}
                    onChange={(e) => setFormData({ ...formData, accent_color: e.target.value })}
                  />
                </div>
              </div>
            </div>
          </div>

          <div>
            <Label>Custom Domain</Label>
            <Input
              value={formData.custom_domain}
              onChange={(e) => setFormData({ ...formData, custom_domain: e.target.value })}
              placeholder="app.yourdomain.com"
            />
          </div>

          <div className="flex items-center justify-between">
            <Label>Hide Platform Branding</Label>
            <Switch
              checked={formData.hide_platform_branding}
              onCheckedChange={(checked) => 
                setFormData({ ...formData, hide_platform_branding: checked })
              }
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? 'Saving...' : 'Save Brand'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}