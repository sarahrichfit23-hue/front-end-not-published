import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Edit, Eye, Copy, Trash2, Globe, CheckCircle, 
  XCircle, ExternalLink, Settings 
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface BrandListProps {
  brands: any[];
  selectedBrand: any;
  onSelect: (brand: any) => void;
  onEdit: (brand: any) => void;
  onPreview: (brand: any) => void;
  onClone: (brand: any) => void;
  onRefresh: () => void;
}

export default function BrandList({
  brands,
  selectedBrand,
  onSelect,
  onEdit,
  onPreview,
  onClone,
  onRefresh
}: BrandListProps) {
  const { toast } = useToast();

  const handleDelete = async (brand: any) => {
    if (!confirm(`Are you sure you want to delete "${brand.name}"?`)) return;

    try {
      const { error } = await supabase
        .from('white_label_brands')
        .delete()
        .eq('id', brand.id);

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Brand deleted successfully'
      });

      onRefresh();
    } catch (error) {
      console.error('Error deleting brand:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete brand',
        variant: 'destructive'
      });
    }
  };

  const handleToggleActive = async (brand: any) => {
    try {
      const { error } = await supabase
        .from('white_label_brands')
        .update({ is_active: !brand.is_active })
        .eq('id', brand.id);

      if (error) throw error;

      toast({
        title: 'Success',
        description: `Brand ${brand.is_active ? 'deactivated' : 'activated'} successfully`
      });

      onRefresh();
    } catch (error) {
      console.error('Error toggling brand status:', error);
      toast({
        title: 'Error',
        description: 'Failed to update brand status',
        variant: 'destructive'
      });
    }
  };

  if (brands.length === 0) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <h3 className="text-lg font-semibold mb-2">No Brands Yet</h3>
          <p className="text-muted-foreground">
            Create your first white-label brand to get started
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-4">
      {brands.map((brand) => (
        <Card 
          key={brand.id}
          className={`cursor-pointer transition-all ${
            selectedBrand?.id === brand.id ? 'ring-2 ring-primary' : ''
          }`}
          onClick={() => onSelect(brand)}
        >
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                {brand.logo_url ? (
                  <img 
                    src={brand.logo_url} 
                    alt={brand.name}
                    className="h-10 w-10 rounded object-contain"
                  />
                ) : (
                  <div 
                    className="h-10 w-10 rounded flex items-center justify-center text-white font-bold"
                    style={{ backgroundColor: brand.primary_color || '#3B82F6' }}
                  >
                    {brand.name.charAt(0).toUpperCase()}
                  </div>
                )}
                <div>
                  <CardTitle className="text-lg">{brand.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">{brand.slug}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {brand.is_active ? (
                  <Badge className="bg-green-500/10 text-green-500">Active</Badge>
                ) : (
                  <Badge variant="secondary">Inactive</Badge>
                )}
                {brand.is_default && (
                  <Badge variant="outline">Default</Badge>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Domain</p>
                <div className="flex items-center gap-1">
                  {brand.custom_domain ? (
                    <>
                      <Globe className="h-3 w-3" />
                      <span className="text-sm font-medium">{brand.custom_domain}</span>
                      {brand.domain_verified ? (
                        <CheckCircle className="h-3 w-3 text-green-500" />
                      ) : (
                        <XCircle className="h-3 w-3 text-yellow-500" />
                      )}
                    </>
                  ) : (
                    <span className="text-sm text-muted-foreground">Not configured</span>
                  )}
                </div>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Colors</p>
                <div className="flex gap-1">
                  <div 
                    className="h-5 w-5 rounded border"
                    style={{ backgroundColor: brand.primary_color }}
                    title="Primary"
                  />
                  <div 
                    className="h-5 w-5 rounded border"
                    style={{ backgroundColor: brand.secondary_color }}
                    title="Secondary"
                  />
                  <div 
                    className="h-5 w-5 rounded border"
                    style={{ backgroundColor: brand.accent_color }}
                    title="Accent"
                  />
                </div>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Font</p>
                <span className="text-sm font-medium">{brand.font_family || 'Inter'}</span>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Platform Branding</p>
                <span className="text-sm">
                  {brand.hide_platform_branding ? 'Hidden' : 'Visible'}
                </span>
              </div>
            </div>

            <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onEdit(brand)}
              >
                <Edit className="h-3 w-3 mr-1" />
                Edit
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onPreview(brand)}
              >
                <Eye className="h-3 w-3 mr-1" />
                Preview
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onClone(brand)}
              >
                <Copy className="h-3 w-3 mr-1" />
                Clone
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleToggleActive(brand)}
              >
                {brand.is_active ? 'Deactivate' : 'Activate'}
              </Button>
              {brand.custom_domain && brand.domain_verified && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => window.open(`https://${brand.custom_domain}`, '_blank')}
                >
                  <ExternalLink className="h-3 w-3 mr-1" />
                  Visit
                </Button>
              )}
              <Button
                size="sm"
                variant="outline"
                className="text-red-600 hover:text-red-700"
                onClick={() => handleDelete(brand)}
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}