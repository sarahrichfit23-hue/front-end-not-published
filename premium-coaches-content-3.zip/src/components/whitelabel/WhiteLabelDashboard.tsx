import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { 
  Palette, Globe, Mail, UserPlus, Eye, Copy, 
  Settings, Plus, Building2, CheckCircle2
} from 'lucide-react';
import BrandEditor from './BrandEditor';
import BrandList from './BrandList';
import EmailTemplateEditor from './EmailTemplateEditor';
import SignupFlowEditor from './SignupFlowEditor';
import BrandPreview from './BrandPreview';

export default function WhiteLabelDashboard() {
  const [brands, setBrands] = useState<any[]>([]);
  const [selectedBrand, setSelectedBrand] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showEditor, setShowEditor] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [activeTab, setActiveTab] = useState('brands');
  const { toast } = useToast();

  useEffect(() => {
    fetchBrands();
  }, []);

  const fetchBrands = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Get user's teams
      const { data: teamMembers } = await supabase
        .from('team_members')
        .select('team_id')
        .eq('user_id', user.id);

      if (!teamMembers || teamMembers.length === 0) return;

      const teamIds = teamMembers.map(tm => tm.team_id);

      // Fetch brands for user's teams
      const { data, error } = await supabase
        .from('white_label_brands')
        .select('*')
        .in('team_id', teamIds)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setBrands(data || []);
      if (data && data.length > 0 && !selectedBrand) {
        setSelectedBrand(data[0]);
      }
    } catch (error) {
      console.error('Error fetching brands:', error);
      toast({
        title: 'Error',
        description: 'Failed to load brands',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateBrand = () => {
    setSelectedBrand(null);
    setShowEditor(true);
  };

  const handleEditBrand = (brand: any) => {
    setSelectedBrand(brand);
    setShowEditor(true);
  };

  const handlePreviewBrand = (brand: any) => {
    setSelectedBrand(brand);
    setShowPreview(true);
  };

  const handleCloneBrand = async (brand: any) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const { data, error } = await supabase.functions.invoke('white-label-operations', {
        body: {
          action: 'clone_brand',
          brandId: brand.id,
          newName: `${brand.name} (Copy)`,
          newSlug: `${brand.slug}-copy-${Date.now()}`
        }
      });

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Brand cloned successfully'
      });

      fetchBrands();
    } catch (error) {
      console.error('Error cloning brand:', error);
      toast({
        title: 'Error',
        description: 'Failed to clone brand',
        variant: 'destructive'
      });
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>;
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">White Label Configuration</h1>
          <p className="text-muted-foreground mt-2">
            Customize your platform with your own branding
          </p>
        </div>
        <Button onClick={handleCreateBrand}>
          <Plus className="h-4 w-4 mr-2" />
          Create Brand
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Brands</p>
                <p className="text-2xl font-bold">{brands.length}</p>
              </div>
              <Building2 className="h-8 w-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Brands</p>
                <p className="text-2xl font-bold">
                  {brands.filter(b => b.is_active).length}
                </p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-green-500 opacity-20" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Custom Domains</p>
                <p className="text-2xl font-bold">
                  {brands.filter(b => b.custom_domain).length}
                </p>
              </div>
              <Globe className="h-8 w-8 text-blue-500 opacity-20" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Verified Domains</p>
                <p className="text-2xl font-bold">
                  {brands.filter(b => b.domain_verified).length}
                </p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="brands">
            <Building2 className="h-4 w-4 mr-2" />
            Brands
          </TabsTrigger>
          <TabsTrigger value="branding">
            <Palette className="h-4 w-4 mr-2" />
            Branding
          </TabsTrigger>
          <TabsTrigger value="emails">
            <Mail className="h-4 w-4 mr-2" />
            Email Templates
          </TabsTrigger>
          <TabsTrigger value="signup">
            <UserPlus className="h-4 w-4 mr-2" />
            Signup Flows
          </TabsTrigger>
        </TabsList>

        <TabsContent value="brands">
          <BrandList
            brands={brands}
            selectedBrand={selectedBrand}
            onSelect={setSelectedBrand}
            onEdit={handleEditBrand}
            onPreview={handlePreviewBrand}
            onClone={handleCloneBrand}
            onRefresh={fetchBrands}
          />
        </TabsContent>

        <TabsContent value="branding">
          {selectedBrand ? (
            <BrandEditor
              brand={selectedBrand}
              onSave={fetchBrands}
              onCancel={() => setShowEditor(false)}
            />
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Building2 className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">No Brand Selected</h3>
                <p className="text-muted-foreground mb-4">
                  Select a brand to customize its branding
                </p>
                <Button onClick={handleCreateBrand}>Create Brand</Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="emails">
          {selectedBrand ? (
            <EmailTemplateEditor
              brandId={selectedBrand.id}
              brandName={selectedBrand.name}
            />
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Mail className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">No Brand Selected</h3>
                <p className="text-muted-foreground">
                  Select a brand to manage email templates
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="signup">
          {selectedBrand ? (
            <SignupFlowEditor
              brandId={selectedBrand.id}
              brandName={selectedBrand.name}
            />
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <UserPlus className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">No Brand Selected</h3>
                <p className="text-muted-foreground">
                  Select a brand to configure signup flows
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {showEditor && (
        <BrandEditor
          brand={selectedBrand}
          onSave={() => {
            fetchBrands();
            setShowEditor(false);
          }}
          onCancel={() => setShowEditor(false)}
        />
      )}

      {showPreview && selectedBrand && (
        <BrandPreview
          brand={selectedBrand}
          onClose={() => setShowPreview(false)}
        />
      )}
    </div>
  );
}