import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

interface BrandPreviewProps {
  brand: any;
  onClose: () => void;
}

export default function BrandPreview({ brand, onClose }: BrandPreviewProps) {
  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[80vh]">
        <DialogHeader>
          <DialogTitle>Preview: {brand.name}</DialogTitle>
        </DialogHeader>
        
        <div className="relative h-full">
          <div 
            className="absolute inset-0 overflow-auto rounded-lg border"
            style={{
              backgroundColor: brand.background_color,
              color: brand.text_color,
              fontFamily: brand.font_family
            }}
          >
            {/* Preview Header */}
            <header 
              className="p-4 border-b"
              style={{ backgroundColor: brand.primary_color }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {brand.logo_url && (
                    <img src={brand.logo_url} alt={brand.name} className="h-8" />
                  )}
                  <h1 className="text-xl font-bold text-white">{brand.name}</h1>
                </div>
                <nav className="flex gap-4">
                  <Button variant="ghost" className="text-white">Features</Button>
                  <Button variant="ghost" className="text-white">Pricing</Button>
                  <Button 
                    style={{ backgroundColor: brand.secondary_color }}
                    className="text-white"
                  >
                    Sign Up
                  </Button>
                </nav>
              </div>
            </header>

            {/* Preview Content */}
            <main className="p-8">
              <div className="max-w-4xl mx-auto space-y-8">
                <section className="text-center py-12">
                  <h2 className="text-4xl font-bold mb-4">Welcome to {brand.name}</h2>
                  <p className="text-xl mb-8">Your custom branded platform</p>
                  <div className="flex gap-4 justify-center">
                    <Button 
                      size="lg"
                      style={{ backgroundColor: brand.primary_color }}
                      className="text-white"
                    >
                      Get Started
                    </Button>
                    <Button 
                      size="lg" 
                      variant="outline"
                      style={{ borderColor: brand.primary_color, color: brand.primary_color }}
                    >
                      Learn More
                    </Button>
                  </div>
                </section>

                <section className="grid grid-cols-3 gap-6">
                  {[1, 2, 3].map(i => (
                    <div 
                      key={i}
                      className="p-6 rounded-lg border"
                      style={{ borderColor: brand.accent_color }}
                    >
                      <div 
                        className="h-12 w-12 rounded-lg mb-4"
                        style={{ backgroundColor: brand.accent_color }}
                      />
                      <h3 className="font-semibold mb-2">Feature {i}</h3>
                      <p className="text-sm opacity-80">
                        This is how your branded content will appear to users.
                      </p>
                    </div>
                  ))}
                </section>
              </div>
            </main>

            {/* Preview Footer */}
            {!brand.hide_platform_branding && (
              <footer className="p-4 border-t text-center text-sm opacity-60">
                {brand.powered_by_text || 'Powered by Platform'}
              </footer>
            )}
          </div>

          {/* Custom CSS Preview */}
          {brand.custom_css && (
            <style dangerouslySetInnerHTML={{ __html: brand.custom_css }} />
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}