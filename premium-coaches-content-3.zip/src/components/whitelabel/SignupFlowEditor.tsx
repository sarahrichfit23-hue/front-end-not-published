import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { UserPlus, Mail, Shield, Globe } from 'lucide-react';

interface SignupFlowEditorProps {
  brandId: string;
  brandName: string;
}

export default function SignupFlowEditor({ brandId, brandName }: SignupFlowEditorProps) {
  const [flowData, setFlowData] = useState({
    name: 'Default Signup Flow',
    allow_email_signup: true,
    allow_google_signup: true,
    allow_github_signup: false,
    require_email_verification: true,
    require_terms_acceptance: true,
    require_invitation: false,
    redirect_after_signup: '/dashboard',
    allowed_email_domains: [] as string[],
    blocked_email_domains: [] as string[]
  });
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchFlow();
  }, [brandId]);

  const fetchFlow = async () => {
    const { data } = await supabase
      .from('brand_signup_flows')
      .select('*')
      .eq('brand_id', brandId)
      .single();

    if (data) {
      setFlowData(data);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('brand_signup_flows')
        .upsert({
          brand_id: brandId,
          ...flowData,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Signup flow saved'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save signup flow',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Signup Flow Configuration for {brandName}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h3 className="text-lg font-semibold mb-4">Authentication Methods</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <Label>Email Signup</Label>
              </div>
              <Switch
                checked={flowData.allow_email_signup}
                onCheckedChange={(checked) => 
                  setFlowData({ ...flowData, allow_email_signup: checked })
                }
              />
            </div>
            <div className="flex items-center justify-between">
              <Label>Google OAuth</Label>
              <Switch
                checked={flowData.allow_google_signup}
                onCheckedChange={(checked) => 
                  setFlowData({ ...flowData, allow_google_signup: checked })
                }
              />
            </div>
            <div className="flex items-center justify-between">
              <Label>GitHub OAuth</Label>
              <Switch
                checked={flowData.allow_github_signup}
                onCheckedChange={(checked) => 
                  setFlowData({ ...flowData, allow_github_signup: checked })
                }
              />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-4">Requirements</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Email Verification</Label>
              <Switch
                checked={flowData.require_email_verification}
                onCheckedChange={(checked) => 
                  setFlowData({ ...flowData, require_email_verification: checked })
                }
              />
            </div>
            <div className="flex items-center justify-between">
              <Label>Terms Acceptance</Label>
              <Switch
                checked={flowData.require_terms_acceptance}
                onCheckedChange={(checked) => 
                  setFlowData({ ...flowData, require_terms_acceptance: checked })
                }
              />
            </div>
            <div className="flex items-center justify-between">
              <Label>Invitation Required</Label>
              <Switch
                checked={flowData.require_invitation}
                onCheckedChange={(checked) => 
                  setFlowData({ ...flowData, require_invitation: checked })
                }
              />
            </div>
          </div>
        </div>

        <div>
          <Label>Redirect After Signup</Label>
          <Input
            value={flowData.redirect_after_signup}
            onChange={(e) => setFlowData({ ...flowData, redirect_after_signup: e.target.value })}
            placeholder="/dashboard"
          />
        </div>

        <div className="flex justify-end">
          <Button onClick={handleSave} disabled={saving}>
            {saving ? 'Saving...' : 'Save Configuration'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}