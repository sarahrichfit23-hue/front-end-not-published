import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Phone, Key, AlertCircle, CheckCircle, Settings, CreditCard, Shield } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

export function TwilioSettings() {
  const [settings, setSettings] = useState({
    accountSid: '',
    authToken: '',
    phoneNumber: '',
    useCentralAccount: true,
    monthlyLimit: 1000,
    autoReplyEnabled: false,
    complianceMessage: 'Reply STOP to unsubscribe'
  });
  const [loading, setLoading] = useState(false);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const { data, error } = await supabase
        .from('twilio_accounts')
        .select('*')
        .eq('user_id', user.user.id)
        .single();

      if (data) {
        setSettings({
          accountSid: data.account_sid || '',
          authToken: '', // Never show stored token
          phoneNumber: data.phone_number || '',
          useCentralAccount: data.is_central_account,
          monthlyLimit: data.monthly_limit,
          autoReplyEnabled: false,
          complianceMessage: 'Reply STOP to unsubscribe'
        });
        setIsConnected(!!data.account_sid);
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
    }
  };

  const handleSaveSettings = async () => {
    setLoading(true);
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const { error } = await supabase
        .from('twilio_accounts')
        .upsert({
          user_id: user.user.id,
          account_sid: settings.accountSid,
          auth_token: settings.authToken || undefined, // Only update if provided
          phone_number: settings.phoneNumber,
          is_central_account: settings.useCentralAccount,
          monthly_limit: settings.monthlyLimit,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      toast.success('Twilio settings saved successfully');
      setIsConnected(true);
    } catch (error) {
      toast.error('Failed to save settings');
    } finally {
      setLoading(false);
    }
  };

  const testConnection = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('send-sms', {
        body: {
          action: 'validate_number',
          data: { phoneNumber: settings.phoneNumber }
        }
      });

      if (error) throw error;

      if (data.isValid) {
        toast.success('Connection test successful!');
      } else {
        toast.error('Invalid phone number format');
      }
    } catch (error) {
      toast.error('Connection test failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          {settings.useCentralAccount 
            ? "You're using the central Twilio account. Usage will be tracked and billed accordingly."
            : "Connect your own Twilio account to send SMS messages. You'll be billed directly by Twilio."}
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="connection">
        <TabsList className="grid grid-cols-3 w-full">
          <TabsTrigger value="connection">
            <Phone className="h-4 w-4 mr-2" />
            Connection
          </TabsTrigger>
          <TabsTrigger value="compliance">
            <Shield className="h-4 w-4 mr-2" />
            Compliance
          </TabsTrigger>
          <TabsTrigger value="billing">
            <CreditCard className="h-4 w-4 mr-2" />
            Billing
          </TabsTrigger>
        </TabsList>

        <TabsContent value="connection">
          <Card>
            <CardHeader>
              <CardTitle>Twilio Connection</CardTitle>
              <CardDescription>
                Configure your Twilio account settings for SMS messaging
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="central-account">Use Central Account</Label>
                <Switch
                  id="central-account"
                  checked={settings.useCentralAccount}
                  onCheckedChange={(checked) => setSettings({...settings, useCentralAccount: checked})}
                />
              </div>

              {!settings.useCentralAccount && (
                <>
                  <div>
                    <Label htmlFor="account-sid">Account SID</Label>
                    <Input
                      id="account-sid"
                      placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                      value={settings.accountSid}
                      onChange={(e) => setSettings({...settings, accountSid: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="auth-token">Auth Token</Label>
                    <Input
                      id="auth-token"
                      type="password"
                      placeholder="Enter your Twilio Auth Token"
                      value={settings.authToken}
                      onChange={(e) => setSettings({...settings, authToken: e.target.value})}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Your auth token is encrypted and never displayed after saving
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="phone-number">Twilio Phone Number</Label>
                    <Input
                      id="phone-number"
                      placeholder="+1234567890"
                      value={settings.phoneNumber}
                      onChange={(e) => setSettings({...settings, phoneNumber: e.target.value})}
                    />
                  </div>
                </>
              )}

              <div className="flex gap-2">
                <Button onClick={handleSaveSettings} disabled={loading}>
                  <Key className="h-4 w-4 mr-2" />
                  Save Settings
                </Button>
                <Button onClick={testConnection} variant="outline" disabled={loading || !isConnected}>
                  Test Connection
                </Button>
              </div>

              {isConnected && (
                <Alert>
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <AlertDescription>
                    Twilio account connected successfully
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="compliance">
          <Card>
            <CardHeader>
              <CardTitle>Compliance Settings</CardTitle>
              <CardDescription>
                Configure compliance and opt-out handling
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="auto-reply">Auto-reply to STOP messages</Label>
                <Switch
                  id="auto-reply"
                  checked={settings.autoReplyEnabled}
                  onCheckedChange={(checked) => setSettings({...settings, autoReplyEnabled: checked})}
                />
              </div>

              <div>
                <Label htmlFor="compliance-message">Compliance Message</Label>
                <Input
                  id="compliance-message"
                  value={settings.complianceMessage}
                  onChange={(e) => setSettings({...settings, complianceMessage: e.target.value})}
                />
                <p className="text-xs text-gray-500 mt-1">
                  This message is automatically appended to your first message to new subscribers
                </p>
              </div>

              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  <strong>Compliance Requirements:</strong>
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li>Always obtain explicit consent before sending SMS</li>
                    <li>Include opt-out instructions in initial messages</li>
                    <li>Honor STOP requests immediately</li>
                    <li>Maintain records of consent and opt-outs</li>
                  </ul>
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing">
          <Card>
            <CardHeader>
              <CardTitle>Usage & Billing</CardTitle>
              <CardDescription>
                Monitor your SMS usage and costs
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="monthly-limit">Monthly Message Limit</Label>
                <Input
                  id="monthly-limit"
                  type="number"
                  value={settings.monthlyLimit}
                  onChange={(e) => setSettings({...settings, monthlyLimit: parseInt(e.target.value)})}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Set a limit to prevent unexpected charges
                </p>
              </div>

              <div className="p-4 bg-gray-50 rounded-lg space-y-2">
                <h4 className="font-medium">Pricing Information</h4>
                <div className="text-sm space-y-1">
                  <div className="flex justify-between">
                    <span>Outbound SMS (US):</span>
                    <span>$0.0079 per message</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Inbound SMS:</span>
                    <span>$0.0075 per message</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Phone Number:</span>
                    <span>$1.00 per month</span>
                  </div>
                </div>
                <p className="text-xs text-gray-600 mt-2">
                  * Prices shown are estimates. Actual costs may vary by destination.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}