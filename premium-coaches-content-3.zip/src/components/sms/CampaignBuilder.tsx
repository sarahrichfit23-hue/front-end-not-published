import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Send, Clock, Users, DollarSign, CalendarIcon, Hash } from 'lucide-react';
import { format } from 'date-fns';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

export function CampaignBuilder() {
  const [campaigns, setCampaigns] = useState([]);
  const [subscribers, setSubscribers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [campaign, setCampaign] = useState({
    name: '',
    message: '',
    segment_filters: {},
    scheduled_at: null,
    status: 'draft'
  });
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [charCount, setCharCount] = useState(0);
  const [segmentCount, setSegmentCount] = useState(0);

  useEffect(() => {
    fetchCampaigns();
    fetchSubscribers();
  }, []);

  useEffect(() => {
    setCharCount(campaign.message.length);
    calculateSegmentCount();
  }, [campaign.message, selectedTags]);

  const fetchCampaigns = async () => {
    try {
      const { data, error } = await supabase
        .from('sms_campaigns')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCampaigns(data || []);
    } catch (error) {
      toast.error('Failed to load campaigns');
    }
  };

  const fetchSubscribers = async () => {
    try {
      const { data, error } = await supabase
        .from('sms_subscribers')
        .select('*')
        .eq('status', 'active');

      if (error) throw error;
      setSubscribers(data || []);
    } catch (error) {
      toast.error('Failed to load subscribers');
    }
  };

  const calculateSegmentCount = () => {
    let count = subscribers.length;
    if (selectedTags.length > 0) {
      count = subscribers.filter(sub => 
        selectedTags.some(tag => sub.tags?.includes(tag))
      ).length;
    }
    setSegmentCount(count);
  };

  const handleSendCampaign = async () => {
    if (!campaign.name || !campaign.message) {
      toast.error('Please fill in all required fields');
      return;
    }

    setLoading(true);
    try {
      // Create campaign record
      const { data: newCampaign, error: campaignError } = await supabase
        .from('sms_campaigns')
        .insert({
          ...campaign,
          segment_filters: { tags: selectedTags },
          total_recipients: segmentCount,
          status: campaign.scheduled_at ? 'scheduled' : 'sending'
        })
        .select()
        .single();

      if (campaignError) throw campaignError;

      // Get targeted subscribers
      let targetSubscribers = subscribers;
      if (selectedTags.length > 0) {
        targetSubscribers = subscribers.filter(sub => 
          selectedTags.some(tag => sub.tags?.includes(tag))
        );
      }

      // Send messages via edge function
      const { data, error } = await supabase.functions.invoke('send-sms', {
        body: {
          action: 'send_campaign',
          data: {
            campaignId: newCampaign.id,
            recipients: targetSubscribers,
            message: campaign.message,
            userId: (await supabase.auth.getUser()).data.user?.id
          }
        }
      });

      if (error) throw error;

      toast.success(`Campaign sent to ${data.sent} recipients`);
      
      // Update campaign status
      await supabase
        .from('sms_campaigns')
        .update({
          status: 'sent',
          sent_at: new Date().toISOString(),
          messages_sent: data.sent
        })
        .eq('id', newCampaign.id);

      // Reset form
      setCampaign({
        name: '',
        message: '',
        segment_filters: {},
        scheduled_at: null,
        status: 'draft'
      });
      setSelectedTags([]);
      fetchCampaigns();
    } catch (error) {
      toast.error('Failed to send campaign');
    } finally {
      setLoading(false);
    }
  };

  const insertVariable = (variable: string) => {
    const cursorPos = (document.getElementById('message-input') as HTMLTextAreaElement)?.selectionStart || campaign.message.length;
    const newMessage = 
      campaign.message.slice(0, cursorPos) + 
      `{${variable}}` + 
      campaign.message.slice(cursorPos);
    setCampaign({ ...campaign, message: newMessage });
  };

  const estimateCost = () => {
    const messagesPerSegment = Math.ceil(charCount / 160);
    const totalMessages = segmentCount * messagesPerSegment;
    return (totalMessages * 0.0079).toFixed(2); // Twilio pricing estimate
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Create SMS Campaign</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="campaign-name">Campaign Name</Label>
            <Input
              id="campaign-name"
              placeholder="Enter campaign name"
              value={campaign.name}
              onChange={(e) => setCampaign({...campaign, name: e.target.value})}
            />
          </div>

          <div>
            <Label htmlFor="message-input">Message</Label>
            <div className="space-y-2">
              <div className="flex gap-2 mb-2">
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => insertVariable('first_name')}
                >
                  {'{First Name}'}
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => insertVariable('last_name')}
                >
                  {'{Last Name}'}
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => insertVariable('phone')}
                >
                  {'{Phone}'}
                </Button>
              </div>
              <Textarea
                id="message-input"
                placeholder="Type your message here..."
                value={campaign.message}
                onChange={(e) => setCampaign({...campaign, message: e.target.value})}
                rows={4}
              />
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>{charCount} / 160 characters</span>
                <span>{Math.ceil(charCount / 160)} segment(s)</span>
              </div>
            </div>
          </div>

          <div>
            <Label>Target Audience</Label>
            <Select onValueChange={(value) => setSelectedTags([value])}>
              <SelectTrigger>
                <SelectValue placeholder="Select tags to target" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subscribers</SelectItem>
                <SelectItem value="vip">VIP</SelectItem>
                <SelectItem value="new">New</SelectItem>
                <SelectItem value="active">Active</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Schedule (Optional)</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {campaign.scheduled_at ? format(new Date(campaign.scheduled_at), 'PPP') : 'Send immediately'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={campaign.scheduled_at ? new Date(campaign.scheduled_at) : undefined}
                  onSelect={(date) => setCampaign({...campaign, scheduled_at: date?.toISOString() || null})}
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="grid grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
            <div className="text-center">
              <Users className="h-5 w-5 mx-auto mb-1 text-gray-600" />
              <div className="text-2xl font-bold">{segmentCount}</div>
              <div className="text-xs text-gray-600">Recipients</div>
            </div>
            <div className="text-center">
              <Hash className="h-5 w-5 mx-auto mb-1 text-gray-600" />
              <div className="text-2xl font-bold">{Math.ceil(charCount / 160)}</div>
              <div className="text-xs text-gray-600">Segments</div>
            </div>
            <div className="text-center">
              <DollarSign className="h-5 w-5 mx-auto mb-1 text-gray-600" />
              <div className="text-2xl font-bold">${estimateCost()}</div>
              <div className="text-xs text-gray-600">Est. Cost</div>
            </div>
          </div>

          <Button 
            onClick={handleSendCampaign} 
            className="w-full"
            disabled={loading || !campaign.name || !campaign.message}
          >
            {loading ? (
              'Sending...'
            ) : campaign.scheduled_at ? (
              <>
                <Clock className="h-4 w-4 mr-2" />
                Schedule Campaign
              </>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Send Campaign Now
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Campaigns</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {campaigns.slice(0, 5).map((camp) => (
              <div key={camp.id} className="flex justify-between items-center p-3 border rounded-lg">
                <div>
                  <div className="font-medium">{camp.name}</div>
                  <div className="text-sm text-gray-600">
                    {camp.total_recipients} recipients • {new Date(camp.created_at).toLocaleDateString()}
                  </div>
                </div>
                <Badge variant={camp.status === 'sent' ? 'default' : 'secondary'}>
                  {camp.status}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}