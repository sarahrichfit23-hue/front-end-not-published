import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { SubscriberManager } from './SubscriberManager';
import { CampaignBuilder } from './CampaignBuilder';
import { WorkflowBuilder } from './WorkflowBuilder';
import { SMSAnalytics } from './SMSAnalytics';
import { TwilioSettings } from './TwilioSettings';
import { MessageSquare, Users, GitBranch, BarChart3, Settings, Send, TrendingUp, DollarSign } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

export function SMSDashboard() {
  const [stats, setStats] = useState({
    totalSubscribers: 0,
    activeCampaigns: 0,
    messagesThisMonth: 0,
    monthlySpend: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      // Get subscriber count
      const { count: subscriberCount } = await supabase
        .from('sms_subscribers')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active');

      // Get active campaigns
      const { count: campaignCount } = await supabase
        .from('sms_campaigns')
        .select('*', { count: 'exact', head: true })
        .in('status', ['scheduled', 'sending']);

      // Get this month's messages
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);

      const { data: analytics } = await supabase
        .from('sms_analytics')
        .select('messages_sent, total_cost')
        .gte('date', startOfMonth.toISOString())
        .eq('user_id', user.user.id);

      const totalMessages = analytics?.reduce((sum, day) => sum + (day.messages_sent || 0), 0) || 0;
      const totalCost = analytics?.reduce((sum, day) => sum + parseFloat(day.total_cost || '0'), 0) || 0;

      setStats({
        totalSubscribers: subscriberCount || 0,
        activeCampaigns: campaignCount || 0,
        messagesThisMonth: totalMessages,
        monthlySpend: totalCost
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">SMS Campaign System</h1>
        <p className="text-gray-600 mt-2">Manage subscribers, send campaigns, and automate SMS workflows</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Subscribers</p>
                <p className="text-2xl font-bold">{stats.totalSubscribers}</p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Campaigns</p>
                <p className="text-2xl font-bold">{stats.activeCampaigns}</p>
              </div>
              <Send className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Messages This Month</p>
                <p className="text-2xl font-bold">{stats.messagesThisMonth}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Monthly Spend</p>
                <p className="text-2xl font-bold">${stats.monthlySpend.toFixed(2)}</p>
              </div>
              <DollarSign className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="subscribers" className="space-y-4">
        <TabsList className="grid grid-cols-5 w-full">
          <TabsTrigger value="subscribers">
            <Users className="h-4 w-4 mr-2" />
            Subscribers
          </TabsTrigger>
          <TabsTrigger value="campaigns">
            <MessageSquare className="h-4 w-4 mr-2" />
            Campaigns
          </TabsTrigger>
          <TabsTrigger value="workflows">
            <GitBranch className="h-4 w-4 mr-2" />
            Workflows
          </TabsTrigger>
          <TabsTrigger value="analytics">
            <BarChart3 className="h-4 w-4 mr-2" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="settings">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="subscribers">
          <SubscriberManager />
        </TabsContent>

        <TabsContent value="campaigns">
          <CampaignBuilder />
        </TabsContent>

        <TabsContent value="workflows">
          <WorkflowBuilder />
        </TabsContent>

        <TabsContent value="analytics">
          <SMSAnalytics />
        </TabsContent>

        <TabsContent value="settings">
          <TwilioSettings />
        </TabsContent>
      </Tabs>
    </div>
  );
}