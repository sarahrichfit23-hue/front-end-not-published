import { useState, useEffect, useCallback } from 'react';
import ReactFlow, {
  Node,
  Edge,
  addEdge,
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  Connection
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { MessageSquare, Clock, Filter, GitBranch, Play, Pause, Save } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

const nodeTypes = {
  trigger: ({ data }: any) => (
    <div className="px-4 py-2 shadow-md rounded-md bg-green-500 text-white">
      <div className="font-bold">Trigger</div>
      <div className="text-sm">{data.label}</div>
    </div>
  ),
  message: ({ data }: any) => (
    <div className="px-4 py-2 shadow-md rounded-md bg-blue-500 text-white">
      <MessageSquare className="h-4 w-4 mb-1" />
      <div className="text-sm">{data.label}</div>
    </div>
  ),
  delay: ({ data }: any) => (
    <div className="px-4 py-2 shadow-md rounded-md bg-yellow-500 text-white">
      <Clock className="h-4 w-4 mb-1" />
      <div className="text-sm">{data.label}</div>
    </div>
  ),
  condition: ({ data }: any) => (
    <div className="px-4 py-2 shadow-md rounded-md bg-purple-500 text-white">
      <Filter className="h-4 w-4 mb-1" />
      <div className="text-sm">{data.label}</div>
    </div>
  )
};

export function WorkflowBuilder() {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [workflows, setWorkflows] = useState([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState<any>(null);
  const [showNodeDialog, setShowNodeDialog] = useState(false);
  const [nodeToAdd, setNodeToAdd] = useState<any>(null);
  const [workflowName, setWorkflowName] = useState('');

  useEffect(() => {
    fetchWorkflows();
  }, []);

  const fetchWorkflows = async () => {
    try {
      const { data, error } = await supabase
        .from('sms_workflows')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setWorkflows(data || []);
    } catch (error) {
      toast.error('Failed to load workflows');
    }
  };

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const addNode = (type: string) => {
    const newNode: Node = {
      id: `${type}_${Date.now()}`,
      type,
      position: { x: 250, y: nodes.length * 100 + 50 },
      data: { label: `New ${type}` }
    };
    setNodes((nds) => [...nds, newNode]);
    setNodeToAdd(newNode);
    setShowNodeDialog(true);
  };

  const saveWorkflow = async () => {
    if (!workflowName) {
      toast.error('Please enter a workflow name');
      return;
    }

    try {
      const workflowData = {
        nodes,
        edges,
        steps: nodes.map((node, index) => ({
          id: node.id,
          type: node.type,
          data: node.data,
          position: index
        }))
      };

      if (selectedWorkflow) {
        const { error } = await supabase
          .from('sms_workflows')
          .update({
            name: workflowName,
            workflow_data: workflowData,
            updated_at: new Date().toISOString()
          })
          .eq('id', selectedWorkflow.id);

        if (error) throw error;
        toast.success('Workflow updated successfully');
      } else {
        const { error } = await supabase
          .from('sms_workflows')
          .insert({
            name: workflowName,
            trigger_type: 'subscriber_added',
            workflow_data: workflowData,
            is_active: false
          });

        if (error) throw error;
        toast.success('Workflow created successfully');
      }

      fetchWorkflows();
    } catch (error) {
      toast.error('Failed to save workflow');
    }
  };

  const loadWorkflow = (workflow: any) => {
    setSelectedWorkflow(workflow);
    setWorkflowName(workflow.name);
    if (workflow.workflow_data) {
      setNodes(workflow.workflow_data.nodes || []);
      setEdges(workflow.workflow_data.edges || []);
    }
  };

  const toggleWorkflowStatus = async (workflow: any) => {
    try {
      const { error } = await supabase
        .from('sms_workflows')
        .update({ is_active: !workflow.is_active })
        .eq('id', workflow.id);

      if (error) throw error;
      toast.success(`Workflow ${workflow.is_active ? 'paused' : 'activated'}`);
      fetchWorkflows();
    } catch (error) {
      toast.error('Failed to update workflow status');
    }
  };

  return (
    <div className="grid grid-cols-4 gap-4 h-[600px]">
      <div className="col-span-1 space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Add Nodes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button
              onClick={() => addNode('trigger')}
              variant="outline"
              className="w-full justify-start"
              size="sm"
            >
              <GitBranch className="h-4 w-4 mr-2" />
              Trigger
            </Button>
            <Button
              onClick={() => addNode('message')}
              variant="outline"
              className="w-full justify-start"
              size="sm"
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Send Message
            </Button>
            <Button
              onClick={() => addNode('delay')}
              variant="outline"
              className="w-full justify-start"
              size="sm"
            >
              <Clock className="h-4 w-4 mr-2" />
              Delay
            </Button>
            <Button
              onClick={() => addNode('condition')}
              variant="outline"
              className="w-full justify-start"
              size="sm"
            >
              <Filter className="h-4 w-4 mr-2" />
              Condition
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Workflows</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {workflows.map((workflow) => (
              <div key={workflow.id} className="p-2 border rounded">
                <div className="flex justify-between items-center">
                  <button
                    onClick={() => loadWorkflow(workflow)}
                    className="text-sm font-medium hover:underline"
                  >
                    {workflow.name}
                  </button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => toggleWorkflowStatus(workflow)}
                  >
                    {workflow.is_active ? (
                      <Pause className="h-3 w-3" />
                    ) : (
                      <Play className="h-3 w-3" />
                    )}
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="col-span-3">
        <Card className="h-full">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Input
                  placeholder="Workflow Name"
                  value={workflowName}
                  onChange={(e) => setWorkflowName(e.target.value)}
                  className="w-64"
                />
              </div>
              <Button onClick={saveWorkflow} size="sm">
                <Save className="h-4 w-4 mr-2" />
                Save Workflow
              </Button>
            </div>
          </CardHeader>
          <CardContent className="h-[500px]">
            <ReactFlow
              nodes={nodes}
              edges={edges}
              onNodesChange={onNodesChange}
              onEdgesChange={onEdgesChange}
              onConnect={onConnect}
              nodeTypes={nodeTypes}
              fitView
            >
              <Background />
              <Controls />
              <MiniMap />
            </ReactFlow>
          </CardContent>
        </Card>
      </div>

      <Dialog open={showNodeDialog} onOpenChange={setShowNodeDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Configure Node</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {nodeToAdd?.type === 'message' && (
              <Textarea
                placeholder="Enter message text..."
                rows={4}
                onChange={(e) => {
                  const updatedNode = { ...nodeToAdd, data: { ...nodeToAdd.data, label: e.target.value } };
                  setNodes((nds) => nds.map((n) => n.id === nodeToAdd.id ? updatedNode : n));
                }}
              />
            )}
            {nodeToAdd?.type === 'delay' && (
              <div className="space-y-2">
                <Label>Delay Duration</Label>
                <div className="flex gap-2">
                  <Input type="number" placeholder="Value" />
                  <Select>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Unit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="minutes">Minutes</SelectItem>
                      <SelectItem value="hours">Hours</SelectItem>
                      <SelectItem value="days">Days</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
            <Button onClick={() => setShowNodeDialog(false)} className="w-full">
              Save Node
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}