import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Upload, Download, Plus, Search, Filter, UserPlus, Tags } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

export function SubscriberManager() {
  const [subscribers, setSubscribers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [newSubscriber, setNewSubscriber] = useState({
    phone_number: '',
    first_name: '',
    last_name: '',
    email: '',
    tags: []
  });

  useEffect(() => {
    fetchSubscribers();
  }, []);

  const fetchSubscribers = async () => {
    try {
      const { data, error } = await supabase
        .from('sms_subscribers')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSubscribers(data || []);
    } catch (error) {
      toast.error('Failed to load subscribers');
    } finally {
      setLoading(false);
    }
  };

  const handleAddSubscriber = async () => {
    try {
      const { error } = await supabase
        .from('sms_subscribers')
        .insert({
          ...newSubscriber,
          opt_in_method: 'manual',
          opt_in_date: new Date().toISOString()
        });

      if (error) throw error;
      
      toast.success('Subscriber added successfully');
      setShowAddDialog(false);
      fetchSubscribers();
      setNewSubscriber({ phone_number: '', first_name: '', last_name: '', email: '', tags: [] });
    } catch (error) {
      toast.error('Failed to add subscriber');
    }
  };

  const handleImportCSV = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const text = e.target?.result as string;
        const lines = text.split('\n');
        const headers = lines[0].split(',').map(h => h.trim());
        
        const subscribers = lines.slice(1).filter(line => line.trim()).map(line => {
          const values = line.split(',');
          const subscriber: any = {};
          headers.forEach((header, index) => {
            subscriber[header.toLowerCase().replace(' ', '_')] = values[index]?.trim();
          });
          return {
            ...subscriber,
            opt_in_method: 'import',
            opt_in_date: new Date().toISOString()
          };
        });

        const { error } = await supabase
          .from('sms_subscribers')
          .insert(subscribers);

        if (error) throw error;
        
        toast.success(`Imported ${subscribers.length} subscribers`);
        fetchSubscribers();
      } catch (error) {
        toast.error('Failed to import CSV');
      }
    };
    reader.readAsText(file);
  };

  const handleExportCSV = () => {
    const csv = [
      ['Phone Number', 'First Name', 'Last Name', 'Email', 'Tags', 'Status', 'Opt-in Date'],
      ...subscribers.map(sub => [
        sub.phone_number,
        sub.first_name || '',
        sub.last_name || '',
        sub.email || '',
        (sub.tags || []).join(';'),
        sub.status,
        sub.opt_in_date
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `subscribers_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const filteredSubscribers = subscribers.filter(sub => {
    const matchesSearch = !searchTerm || 
      sub.phone_number?.includes(searchTerm) ||
      sub.first_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sub.last_name?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesTags = selectedTags.length === 0 ||
      selectedTags.some(tag => sub.tags?.includes(tag));
    
    return matchesSearch && matchesTags;
  });

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>SMS Subscribers</CardTitle>
          <div className="flex gap-2">
            <Button onClick={() => setShowAddDialog(true)} size="sm">
              <UserPlus className="h-4 w-4 mr-2" />
              Add Subscriber
            </Button>
            <label htmlFor="csv-upload">
              <Button size="sm" asChild>
                <span>
                  <Upload className="h-4 w-4 mr-2" />
                  Import CSV
                </span>
              </Button>
            </label>
            <input
              id="csv-upload"
              type="file"
              accept=".csv"
              className="hidden"
              onChange={handleImportCSV}
            />
            <Button onClick={handleExportCSV} variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex gap-4 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search subscribers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Phone Number</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Tags</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Opt-in Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredSubscribers.map((subscriber) => (
              <TableRow key={subscriber.id}>
                <TableCell>{subscriber.phone_number}</TableCell>
                <TableCell>
                  {subscriber.first_name} {subscriber.last_name}
                </TableCell>
                <TableCell>
                  <div className="flex gap-1 flex-wrap">
                    {(subscriber.tags || []).map((tag, i) => (
                      <Badge key={i} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant={subscriber.status === 'active' ? 'default' : 'secondary'}>
                    {subscriber.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  {new Date(subscriber.opt_in_date).toLocaleDateString()}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Subscriber</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Input
                placeholder="Phone Number"
                value={newSubscriber.phone_number}
                onChange={(e) => setNewSubscriber({...newSubscriber, phone_number: e.target.value})}
              />
              <Input
                placeholder="First Name"
                value={newSubscriber.first_name}
                onChange={(e) => setNewSubscriber({...newSubscriber, first_name: e.target.value})}
              />
              <Input
                placeholder="Last Name"
                value={newSubscriber.last_name}
                onChange={(e) => setNewSubscriber({...newSubscriber, last_name: e.target.value})}
              />
              <Input
                placeholder="Email"
                type="email"
                value={newSubscriber.email}
                onChange={(e) => setNewSubscriber({...newSubscriber, email: e.target.value})}
              />
              <Input
                placeholder="Tags (comma separated)"
                onChange={(e) => setNewSubscriber({...newSubscriber, tags: e.target.value.split(',').map(t => t.trim())})}
              />
              <Button onClick={handleAddSubscriber} className="w-full">
                Add Subscriber
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}