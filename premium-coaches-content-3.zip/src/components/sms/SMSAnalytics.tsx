import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Send, Reply, UserX, DollarSign } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { format, subDays, startOfMonth, endOfMonth } from 'date-fns';

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

export function SMSAnalytics() {
  const [timeRange, setTimeRange] = useState('7days');
  const [analyticsData, setAnalyticsData] = useState<any[]>([]);
  const [campaignStats, setCampaignStats] = useState<any[]>([]);
  const [metrics, setMetrics] = useState({
    deliveryRate: 0,
    responseRate: 0,
    optOutRate: 0,
    avgCostPerMessage: 0
  });

  useEffect(() => {
    fetchAnalytics();
  }, [timeRange]);

  const fetchAnalytics = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      let startDate = new Date();
      if (timeRange === '7days') {
        startDate = subDays(new Date(), 7);
      } else if (timeRange === '30days') {
        startDate = subDays(new Date(), 30);
      } else if (timeRange === 'month') {
        startDate = startOfMonth(new Date());
      }

      // Fetch daily analytics
      const { data: analytics, error } = await supabase
        .from('sms_analytics')
        .select('*')
        .gte('date', startDate.toISOString())
        .eq('user_id', user.user.id)
        .order('date', { ascending: true });

      if (error) throw error;

      // Process data for charts
      const processedData = analytics?.map(day => ({
        date: format(new Date(day.date), 'MMM dd'),
        sent: day.messages_sent || 0,
        delivered: day.messages_delivered || 0,
        failed: day.messages_failed || 0,
        replies: day.replies_received || 0,
        optOuts: day.opt_outs || 0,
        cost: parseFloat(day.total_cost || '0')
      })) || [];

      setAnalyticsData(processedData);

      // Calculate metrics
      const totals = processedData.reduce((acc, day) => ({
        sent: acc.sent + day.sent,
        delivered: acc.delivered + day.delivered,
        replies: acc.replies + day.replies,
        optOuts: acc.optOuts + day.optOuts,
        cost: acc.cost + day.cost
      }), { sent: 0, delivered: 0, replies: 0, optOuts: 0, cost: 0 });

      setMetrics({
        deliveryRate: totals.sent > 0 ? (totals.delivered / totals.sent) * 100 : 0,
        responseRate: totals.delivered > 0 ? (totals.replies / totals.delivered) * 100 : 0,
        optOutRate: totals.delivered > 0 ? (totals.optOuts / totals.delivered) * 100 : 0,
        avgCostPerMessage: totals.sent > 0 ? totals.cost / totals.sent : 0
      });

      // Fetch campaign performance
      const { data: campaigns } = await supabase
        .from('sms_campaigns')
        .select('*')
        .eq('status', 'sent')
        .gte('sent_at', startDate.toISOString())
        .eq('user_id', user.user.id)
        .order('sent_at', { ascending: false })
        .limit(5);

      setCampaignStats(campaigns || []);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">SMS Analytics</h2>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7days">Last 7 Days</SelectItem>
            <SelectItem value="30days">Last 30 Days</SelectItem>
            <SelectItem value="month">This Month</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Delivery Rate</p>
                <p className="text-2xl font-bold">{metrics.deliveryRate.toFixed(1)}%</p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Response Rate</p>
                <p className="text-2xl font-bold">{metrics.responseRate.toFixed(1)}%</p>
              </div>
              <Reply className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Opt-out Rate</p>
                <p className="text-2xl font-bold">{metrics.optOutRate.toFixed(1)}%</p>
              </div>
              <UserX className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Avg Cost/Message</p>
                <p className="text-2xl font-bold">${metrics.avgCostPerMessage.toFixed(3)}</p>
              </div>
              <DollarSign className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Message Volume</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={analyticsData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="sent" stroke="#3B82F6" name="Sent" />
                <Line type="monotone" dataKey="delivered" stroke="#10B981" name="Delivered" />
                <Line type="monotone" dataKey="failed" stroke="#EF4444" name="Failed" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Engagement Metrics</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={analyticsData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="replies" fill="#3B82F6" name="Replies" />
                <Bar dataKey="optOuts" fill="#EF4444" name="Opt-outs" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Top Performing Campaigns</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {campaignStats.map((campaign) => (
              <div key={campaign.id} className="flex justify-between items-center p-3 border rounded-lg">
                <div>
                  <div className="font-medium">{campaign.name}</div>
                  <div className="text-sm text-gray-600">
                    Sent: {campaign.messages_sent} • Delivered: {campaign.messages_delivered} • 
                    Cost: ${parseFloat(campaign.actual_cost || '0').toFixed(2)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold">
                    {campaign.messages_sent > 0 
                      ? ((campaign.messages_delivered / campaign.messages_sent) * 100).toFixed(1)
                      : 0}%
                  </div>
                  <div className="text-xs text-gray-600">Delivery Rate</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}